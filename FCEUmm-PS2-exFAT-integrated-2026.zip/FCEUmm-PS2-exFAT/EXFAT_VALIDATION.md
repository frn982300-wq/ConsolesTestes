FCEUmm PS2 0.3.3 / exFAT experiment (2026)

Source package for GitHub Actions.

Proven directly from user's FCEUmm source and IRX driver uploads.
Two embedded IOP modules:
- irx/exfat/usbd.irx: internally named bdm (first to load)
- irx/exfat/usbhdfsd.irx: internally named usbd (second to load)
This follows the BDM Assault two-driver arrangement.

Source adaptations:
- NEWLIB_PORT_AWARE for the legacy fio/fileXio APIs
- browser.c io_dirent_t compatibility
- cnfsettings.c: stdlib, fileio, flags and Boolean declarations
- main.c: JPEG loader replaced by gsKit JPEG, malloc.h for memalign
- ps2font.c: stdlib.h
- menu.c: string.h
- init.c: add fileXioInit + diagnostic output from module loading
- Makefile.ps2: use user-supplied binary IRX modules, -fcommon for legacy C, disable packing

Important: cross-compilation and real USB access are not verified. A successful
ELF build does not establish exFAT compatibility. Back up the USB device and
use a spare drive for testing. Do not write to important partitions.

Sources:
https://github.com/israpps/BDMAssault
https://github.com/ps2dev/ps2sdk
https://github.com/ps2dev/gsKit

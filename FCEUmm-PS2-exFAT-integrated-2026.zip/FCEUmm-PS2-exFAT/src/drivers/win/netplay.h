extern CFGSTRUCT NetplayConfig[];

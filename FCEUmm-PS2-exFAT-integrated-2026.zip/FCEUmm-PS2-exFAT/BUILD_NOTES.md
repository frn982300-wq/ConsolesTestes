# FCEUmm-PS2 0.3.3 - experimental exFAT USB driver integration

This is a modified version of the source ZIP supplied by the user. It has not been successfully compiled or tested on a real PlayStation 2 in this environment.

## Changes

- Bundled the two provided binary IRX drivers under `src/drivers/ps2/irx/exfat/`.
- Altered the `Makefile.ps2` `bin2c` recipes so the two user-provided drivers are embedded in the ELF rather than toolchain-provided drivers.
- Kept the original module load order in `src/drivers/ps2/init.c`, with diagnostic logging for each USB module.
- Added missing C headers in `src/drivers/ps2/browser.c`.
- Made PS2 ELF packing optional (`NOT_PACKED=1` by default).
- Added a GitHub Actions build for the modified source ZIP, with build-log artifact upload.

## Important caveats

- An ELF build succeeding does not prove runtime USB or exFAT support. Test on real hardware with a backup of your USB media.
- Internal IOP module names differ from file names: the supplied `usbd.irx` is internally `bdm` (FATFS / exFAT); `usbhdfsd.irx` is internally `usbd` (USB stack / mass storage).
- The existing browser uses `mass:/`. Actual mount, enumeration, and reading must be verified.
- The binary driver source, provenance, licensing and compatibility with the IOP module set have not been verified.
- This 2018 PS2 code may still require updates for the current PS2DEV toolchain. Build logs are preserved to identify the first real error.

## GitHub Actions use (ZIP workflow)

Place `FCEUmm-PS2-exFAT-source.zip` in the root of a GitHub repository (main branch). Place the separate `build-ps2.yml` in `.github/workflows/build-ps2.yml`, commit, then run GitHub Actions. The workflow extracts the ZIP and compiles with `make -f Makefile.ps2 NOT_PACKED=1 -j1`.

No ROMs are included in this package.

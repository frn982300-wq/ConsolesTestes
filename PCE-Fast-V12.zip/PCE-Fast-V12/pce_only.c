          /*
           * PCE Fast PS2 - experimental single-core Libretro frontend.
           * Based on the Beetle PCE Fast libretro core used by SNESticle Aurora.
           * This frontend is new; the core is built from its original source.
           * No ROM or firmware bundled. Uses the previously tested V10/V11 exFAT driver pair.
           * Native PS2 libvorbisfile optional; fallback supports cartridges only.
           */
          /* POSIX types are supplied through the explicit PS2 toolchain newlib header in EE_CFLAGS. */
          #include <gsKit.h>
          #include <dmaKit.h>
          #include <libpad.h>
          #include <sifrpc.h>
          #include <loadfile.h>
          #include <sbv_patches.h>
          #include <iopheap.h>
          #include <fileXio_rpc.h>
          #include <io_common.h>
          #include <iox_stat.h>
          #include <libretro.h>
          #include <audsrv.h>
          #include <stdio.h>
          #include <stdlib.h>
          #include <string.h>
          #include <ctype.h>
          #include <stdint.h>
          #include <zlib.h>
          /* Some PS2SDK/newlib headers do not expose snprintf under the current
             feature macros. Declare its standard signature explicitly. */
          extern int snprintf(char *str, size_t size, const char *format, ...);

          #define MAX_FILES 128
          #define MAX_PATH 512
          #define ROM_LIMIT (8u * 1024u * 1024u)
          #define TEX_SIZE 512
          /* Diagnostic overlay intentionally enabled for this test; disable after troubleshooting. */
          #define PCE_SHOW_DIAGNOSTICS 1

          extern unsigned char usbd_irx[], usbhdfsd_irx[], iomanx_irx[], filexio_irx[], audsrv_irx[];
          extern unsigned int size_usbd_irx, size_usbhdfsd_irx, size_iomanx_irx, size_filexio_irx, size_audsrv_irx;

          typedef struct { char name[256]; int dir; } Entry;
          static Entry entries[MAX_FILES];
          static int nentries, selected, screen, status_code;
          static char folder[MAX_PATH] = "mass:/";
          static char game_path[MAX_PATH];
          static char game_core_path[MAX_PATH]; /* .pce member name for ZIPs; used by Libretro. */
          /* ZIP temporary path and diagnostic fields used by the load-debug overlay. */
          static char zip_temp_path[MAX_PATH];
          static char last_temp_path[MAX_PATH];
          static char last_valid_extensions[256];
          static char last_rom_name[MAX_PATH];
          static char core_last_log[192];
          static unsigned long last_rom_size;
          static unsigned char last_rom_head[8];
          static int last_need_fullpath = -1;
          static unsigned char *game_data;
          static size_t game_size;
          static char pad_buf[256] __attribute__((aligned(64)));
          static struct padButtonStatus pad_info;
          static unsigned int buttons_now, buttons_prev, buttons_edge;
          /* Hold-to-fire turbo: about 15 pulses/second at the PCE Fast ~60 Hz frame rate. */
          #define PCE_TURBO_PERIOD_FRAMES 4u
          #define PCE_TURBO_ON_FRAMES 2u
          static unsigned int turbo_i_counter, turbo_ii_counter;
          static int turbo_i_active, turbo_ii_active;
          /* The frontend advances Turbo once per emulated frame. If the core
             also calls input_poll(), the guard prevents a second advance. */
          static int turbo_updated_this_frame;
          static iox_dirent_t dirent_buf __attribute__((aligned(64)));
          static iox_stat_t stat_buf __attribute__((aligned(64)));
          static unsigned char readbuf[16384] __attribute__((aligned(64)));
          /* Store the core's native GS PSMCT16 pixels directly: half the memory and upload bandwidth of CT32. */
          static uint16_t pixels16[TEX_SIZE * TEX_SIZE] __attribute__((aligned(64)));
          static GSTEXTURE tex;
/* 200x200 PNG covers are uploaded into a separate 256x256 PSMCT16 texture. */
#define COVER_TEX_SIZE 256
#define COVER_PNG_MAX_BYTES (2u * 1024u * 1024u)
static uint16_t cover_pixels[COVER_TEX_SIZE * COVER_TEX_SIZE] __attribute__((aligned(64)));
static GSTEXTURE cover_tex;
static iox_stat_t cover_stat_buf __attribute__((aligned(64)));
static int cover_tex_ready, cover_loaded, cover_error;
static char cover_key[MAX_PATH];
static char cover_debug[96] = "NO COVER CHECK";
/* Optional user-selected 640x480 PNG background loaded once from USB. */
#define BACKGROUND_TEX_W 1024
#define BACKGROUND_TEX_H 512
#define BACKGROUND_PNG_MAX_BYTES (4u * 1024u * 1024u)
static uint16_t background_pixels[BACKGROUND_TEX_W * BACKGROUND_TEX_H] __attribute__((aligned(64)));
static GSTEXTURE background_tex;
static iox_stat_t background_stat_buf __attribute__((aligned(64)));
static int background_tex_ready, background_loaded, background_checked, background_error;
static void load_background(void);
static void draw_background(void);
          static GSGLOBAL *gs;
          static int video_received, video_frame_updated, pixel_format = RETRO_PIXEL_FORMAT_0RGB1555;
          static unsigned frame_w = 256, frame_h = 224;
          static int core_initialized, core_loaded;
          static int usb_initialized, iop_prepared;
          static int pad_ready;
          /* Port-open status is not proof of live input. */
          static int pad_read_ok, pad_state_value = -1, pad_read_len;
          static unsigned int pad_raw_buttons = 0xffffu;
          static int pad_init_result, pad_open_result;
          #if PCE_SHOW_DIAGNOSTICS
          static unsigned int input_active_mask, input_query_mask;
          static unsigned int input_mask_query_count;
          static unsigned int input_poll_count, input_state_count;
          static int input_last_port = -1, input_last_device = -1;
          static int input_last_id = -1, input_last_value;
          static unsigned int input_a_queries, input_b_queries;
          static int input_a_value, input_b_value;
          #endif
          static int audio_module_loaded, audio_rpc_ready, audio_ready, audio_error;
          static unsigned audio_rate = 44100;

          /* Save states use the core's native Libretro serialization API and USB storage. */
          #define PCE_STATE_SLOTS 5
          #define PCE_STATE_MAX_BYTES (16u * 1024u * 1024u)
          #define PCE_STATE_VERSION 1u
          typedef struct {
            char magic[8];
            uint32_t version;
            uint32_t game_hash;
            uint32_t payload_size;
            uint32_t payload_hash;
            uint32_t turbo_i_counter;
            uint32_t turbo_ii_counter;
          } PCEStateHeader;
          static int state_menu_selected = 0;
          static char state_message[64] = "";
          static int state_message_frames;

          /* Generated from the supplied Pc Engine Cheats.zip; supported byte-write codes only. */
          typedef struct { const char *game_key; const char *desc; const char *code; int enabled; } PCECheat;
          static PCECheat pce_cheat_db[] = {
            {"1941COUNTERATTACKJAPAN", "Infinite Energy", "1f0820:03", 0},
            {"1943KAIJAPAN", "Infinite Energy", "1f1548:64", 0},
            {"1943KAIJAPAN", "Infinite Energy (Player 2)", "1f1549:40", 0},
            {"1943KAIJAPAN", "Infinite Rolls", "1f155a:02", 0},
            {"1943KAIJAPAN", "Infinite Weapon Time (Player 1)", "1f1551:99", 0},
            {"1943KAIJAPAN", "Infinite Weapon Time (Player 2)", "1f1552:99", 0},
            {"3IN1DUODEMOCDSCDUSA", "Have E Red Shot (Gate of Thunder)", "1f0687:01", 0},
            {"3IN1DUODEMOCDSCDUSA", "Have S Green Shot (Gate of Thunder)", "1f0686:01", 0},
            {"3IN1DUODEMOCDSCDUSA", "Infinite Health (Bonk's Adventure)", "1f0cc4:0f", 0},
            {"3IN1DUODEMOCDSCDUSA", "Infinite Health (Bonk's Revenge)", "1f0a4e:0f", 0},
            {"3IN1DUODEMOCDSCDUSA", "Infinite Lives (Bonk's Adventure)", "1f0cc1:09", 0},
            {"3IN1DUODEMOCDSCDUSA", "Infinite Lives (Bonk's Revenge)", "1f0a0f:09", 0},
            {"3IN1DUODEMOCDSCDUSA", "Infinite Lives (Gate of Thunder)", "1f0681:04", 0},
            {"3IN1DUODEMOCDSCDUSA", "Invincibility (Bonk's Adventure)", "1f0b13:67", 0},
            {"3IN1DUODEMOCDSCDUSA", "Invincibility (Bonk's Revenge)", "1f0a61:14", 0},
            {"4IN1SUPERCDSCDUSA", "Have E Red Shot (Gate of Thunder)", "1f0687:01", 0},
            {"4IN1SUPERCDSCDUSA", "Have S Green Shot (Gate of Thunder)", "1f0686:01", 0},
            {"4IN1SUPERCDSCDUSA", "Infinite Health (Bonk's Adventure)", "1f0cc4:0f", 0},
            {"4IN1SUPERCDSCDUSA", "Infinite Health (Bonk's Revenge)", "1f0a4e:0f", 0},
            {"4IN1SUPERCDSCDUSA", "Infinite Lives (Bonk's Adventure)", "1f0cc1:09", 0},
            {"4IN1SUPERCDSCDUSA", "Infinite Lives (Bonk's Revenge)", "1f0a0f:09", 0},
            {"4IN1SUPERCDSCDUSA", "Infinite Lives (Gate of Thunder)", "1f0681:04", 0},
            {"4IN1SUPERCDSCDUSA", "Infinite Time (Bomberman)", "1f0d8e:00", 0},
            {"4IN1SUPERCDSCDUSA", "Invincibility (Bonk's Adventure)", "1f0b13:67", 0},
            {"4IN1SUPERCDSCDUSA", "Invincibility (Bonk's Revenge)", "1f0a61:14", 0},
            {"4IN1SUPERCDSCDUSA", "P1 Infinite Lives (Bomberman)", "1f0438:09", 0},
            {"4IN1SUPERCDSCDUSA", "P1 Invincible (Bomberman)", "1f043a:00", 0},
            {"ADVENTUREISLANDJAPAN", "Aqua Shield", "1f13f9:01", 0},
            {"ADVENTUREISLANDJAPAN", "Crystal Armor", "1f1400:01", 0},
            {"ADVENTUREISLANDJAPAN", "Crystal Shield", "1f13f6:01", 0},
            {"ADVENTUREISLANDJAPAN", "Crystal Sword", "1f13ec:01", 0},
            {"ADVENTUREISLANDJAPAN", "Dancing Shield", "1f13f8:01", 0},
            {"ADVENTUREISLANDJAPAN", "Dragon Mail", "1f1403:01", 0},
            {"ADVENTUREISLANDJAPAN", "Goblin Mail", "1f1401:01", 0},
            {"ADVENTUREISLANDJAPAN", "Hades Armor", "1f1405:01", 0},
            {"ADVENTUREISLANDJAPAN", "Heavenly Shield", "1f13fb:01", 0},
            {"ADVENTUREISLANDJAPAN", "Infinite Energy", "1f141a:28", 0},
            {"ADVENTUREISLANDJAPAN", "Infinite Gold", "1f1422:09", 0},
            {"ADVENTUREISLANDJAPAN", "Ivory Armor", "1f13fd:01", 0},
            {"ADVENTUREISLANDJAPAN", "Ivory Shield", "1f13f3:01", 0},
            {"ADVENTUREISLANDJAPAN", "Ivory Sword", "1f13e9:01", 0},
            {"ADVENTUREISLANDJAPAN", "Knight Shield", "1f13f7:01", 0},
            {"ADVENTUREISLANDJAPAN", "Legendary Armor", "1f13fc:01", 0},
            {"ADVENTUREISLANDJAPAN", "Legendary Shield", "1f13f2:01", 0},
            {"ADVENTUREISLANDJAPAN", "Legendary Sword", "1f13e8:01", 0},
            {"ADVENTUREISLANDJAPAN", "Lucky Sword", "1f13ef:01", 0},
            {"ADVENTUREISLANDJAPAN", "Magical Saber", "1f13ee:01", 0},
            {"ADVENTUREISLANDJAPAN", "Master Shield", "1f13fa:01", 0},
            {"ADVENTUREISLANDJAPAN", "Max Gold", "1f141d:09+1f141e:09+1f141f:09+1f1420:09+1f1421:09", 0},
            {"ADVENTUREISLANDJAPAN", "Mithril Armor", "1f13fe:01", 0},
            {"ADVENTUREISLANDJAPAN", "Mithril Shield", "1f13f4:01", 0},
            {"ADVENTUREISLANDJAPAN", "Mithril Sword", "1f13ea:01", 0},
            {"ADVENTUREISLANDJAPAN", "Muramasa Blade", "1f13f0:01", 0},
            {"ADVENTUREISLANDJAPAN", "Prince Armor", "1f1404:01", 0},
            {"ADVENTUREISLANDJAPAN", "Samurai Armor", "1f1402:01", 0},
            {"ADVENTUREISLANDJAPAN", "Shogun Blade", "1f13eb:01", 0},
            {"ADVENTUREISLANDJAPAN", "Shogun Lemellar", "1f13ff:01", 0},
            {"ADVENTUREISLANDJAPAN", "Shogun Shield", "1f13f5:01", 0},
            {"ADVENTUREISLANDJAPAN", "Tasmanian Sword", "1f13f1:01", 0},
            {"ADVENTUREISLANDJAPAN", "Thunder Saber", "1f13ed:01", 0},
            {"ADVENTUREISLANDJAPAN", "Unlimited Arrows", "1f1408:63", 0},
            {"ADVENTUREISLANDJAPAN", "Unlimited Boomerang", "1f1409:63", 0},
            {"ADVENTUREISLANDJAPAN", "Unlimited Fireballs", "1f1406:63", 0},
            {"ADVENTUREISLANDJAPAN", "Unlimited Lightning", "1f140a:63", 0},
            {"ADVENTUREISLANDJAPAN", "Unlimited Whirlwind", "1f1407:63", 0},
            {"ADVENTURESOFMRHELI", "Infinite Energy", "1f1804:0a", 0},
            {"AEROBLASTERSJAPAN", "Player 1 Invincibility", "1f0584:01", 0},
            {"AEROBLASTERSJAPAN", "Player 2 Invincibility", "1f0585:01", 0},
            {"AEROBLASTERSUSA", "Infinite Lives", "1f1bd1:02", 0},
            {"AEROBLASTERSUSA", "Invincibility", "1f0584:01", 0},
            {"AEROBLASTERSUSA", "P1 Invincible", "1f0584:01", 0},
            {"AEROBLASTERSUSA", "P1 Unlimited Lives", "1f1bd1:09", 0},
            {"AEROBLASTERSUSA", "P2 Invincible", "1f0585:01", 0},
            {"AEROBLASTERSUSA", "P2 Unlimited Lives", "1f1bd2:09", 0},
            {"AEROBLASTERSUSA", "Unlimited Credits", "1f0000:09", 0},
            {"AFTERBURNERII", "Infinite Lives up to 3", "1f18b3:03", 0},
            {"AFTERBURNERII", "Infinite Missiles up to 9", "1f18b4:09", 0},
            {"AFTERBURNERIIJAPAN", "Enemies Never Shoot", "1f0025:19", 0},
            {"AFTERBURNERIIJAPAN", "Infinite Lives", "1f10b3:03", 0},
            {"AFTERBURNERIIJAPAN", "Infinite Missiles", "1f10b4:50", 0},
            {"AICHOUANIKISCDJAPAN", "Infinite Energy", "1f0079:48", 0},
            {"AICHOUANIKISCDJAPAN", "Infinite Time", "1f0078:87", 0},
            {"AICHOUANIKISCDJAPAN", "Invincibility", "1f123d:01", 0},
            {"AIRZONK", "Infinite Lives", "1f08b2:09", 0},
            {"AIRZONKUSA", "Infinite Lives", "1f00b2:0a", 0},
            {"AIRZONKUSA", "Invincibility", "1f1a82:00+1f1a81:01", 0},
            {"AKUMAJOUDRACULAXCHINORONDOSCDJAPAN", "Have 9999 Credits", "1f0096:99+1f0097:99", 0},
            {"AKUMAJOUDRACULAXCHINORONDOSCDJAPAN", "Infinite Health (disable at end of round)", "1f0098:70", 0},
            {"AKUMAJOUDRACULAXCHINORONDOSCDJAPAN", "Infinite Hearts (disable at end of round)", "1f0094:99", 0},
            {"AKUMAJOUDRACULAXCHINORONDOSCDJAPAN", "Infinite Lives", "1f008d:09", 0},
            {"AKUMAJOUDRACULAXCHINORONDOSCDJAPAN", "Invincibility", "1f1460:01", 0},
            {"AKUMAJOUDRACULAXCHINORONDOSCDJPN", "Unlimited Health (Disable at end of stage for score)", "1f0098:5c", 0},
            {"ALDYNESJAPAN", "Infinite Helpers", "1f1068:04", 0},
            {"ALDYNESJAPAN", "Infinite Lives", "1f0222:02", 0},
            {"ALDYNESJAPAN", "Invincibility", "1f07e0:01", 0},
            {"ALIENCRUSH", "Infinite Balls", "1f0846:09", 0},
            {"ALIENCRUSHJAPAN", "Infinite Balls", "1f0046:03", 0},
            {"ALIENCRUSHUSA", "Infinite Balls", "1f0046:03", 0},
            {"ANDREPANZAKICKBOXINGUSA", "CPU/Player 2 No Health", "1f0219:ff", 0},
            {"ANDREPANZAKICKBOXINGUSA", "Freeze Timer", "1f0d26:09", 0},
            {"ANDREPANZAKICKBOXINGUSA", "Infinite Health", "1f0218:ff", 0},
            {"ANESANSCDJAPAN", "1-Hit Kill Bosses and Enemies", "1f09f0:25+1f09f1:25+1f09f2:25", 0},
            {"ANESANSCDJAPAN", "Infinite Health", "1f09ee:32", 0},
            {"ANESANSCDJAPAN", "Infinite Money", "1f06cf:15+1f06d0:15+1f06d1:15", 0},
            {"ANKOKODENSETSUL", "Energy up to 6", "1f190e:06", 0},
            {"ANKOKODENSETSUL", "Magic Weapon up to 9", "1f1912:09", 0},
            {"AOIBLINKJAPAN", "Infinite Energy", "1f1c53:48", 0},
            {"AOIBLINKJAPAN", "Infinite Lives", "1f1c47:03", 0},
            {"AOIBLINKJAPAN", "Invincibility", "1f0f12:01", 0},
            {"APPAREGATEBALLJAPAN", "Quick Game Time", "1f09a7:60", 0},
            {"ARMEDFJAPAN", "Infinite Lives", "1f001d:03", 0},
            {"ARMEDFJAPAN", "Invincible", "1f020a:c5", 0},
            {"ARMEDFJAPAN", "Unlimited F Types", "1f002c:03", 0},
            {"ATOMICROBOKIDSPECIAL", "Infinite Energy", "1f179d:0e", 0},
            {"ATOMICROBOKIDSPECIAL", "Infinite Lives 3 up to 99", "1f0a11:03", 0},
            {"ATOMICROBOKIDSPECIALJAPAN", "Infinite Energy", "1f0f9d:14", 0},
            {"ATOMICROBOKIDSPECIALJAPAN", "Infinite Lives", "1f0211:03", 0},
            {"ATOMICROBOKIDSPECIALJAPAN", "Invincibility", "1f0f9f:02", 0},
            {"AVENGERCDJAPAN", "Infinite Energy", "1f057f:05", 0},
            {"AVENGERCDJAPAN", "Infinite Special Weapon", "1f001d:02", 0},
            {"BABYJOSCDJAPAN", "Have Max Milk", "1f0c28:25+1f0c29:25", 0},
            {"BABYJOSCDJAPAN", "Have Rattle and Unlimited Ammo", "1f0c2a:96+1f0c2b:96", 0},
            {"BABYJOSCDJAPAN", "Invincibility", "1f0c2c:25+1f0c2d:25", 0},
            {"BAKUSHOUYOSHIMOTONOSHINKIGEKISCDJAPAN", "Infinite Health", "1f03e0:18", 0},
            {"BAKUSHOUYOSHIMOTONOSHINKIGEKISCDJAPAN", "Infinite Lives", "1f0100:09", 0},
            {"BAKUSHOUYOSHIMOTONOSHINKIGEKISCDJAPAN", "Invincibility", "1f03a0:20", 0},
            {"BALLISTIXUSA", "CPU Never Scores", "1f06dd:00", 0},
            {"BARIBARIDENSETSUJAPAN", "Always First Place", "1f0a84:01+1f0a85:01+1f0ca7:01", 0},
            {"BARIBARIDENSETSUJAPAN", "Instant Win/Last Lap", "1f0a86:01", 0},
            {"BARIBARIDENSETSUJAPAN", "Low Lap Time", "1f105b:01", 0},
            {"BARUNBA", "Infinite Lives", "1f0e82:05", 0},
            {"BARUNBAJAPAN", "Infinite Energy", "1f0682:05", 0},
            {"BARUNBAJAPAN", "Invulnerability", "1f06a3:3a", 0},
            {"BATMAN", "Items to Collect X. Set to 1 and pick up item to fin", "1f1bab:01", 0},
            {"BATMAN", "Time (Seconds) 0 up to 60", "1f1ba7:3c", 0},
            {"BATMANJAPAN", "Freeze Time", "1f13a7:09", 0},
            {"BATMANJAPAN", "Infinite Lives", "1f13aa:02", 0},
            {"BATMANJAPAN", "Invincibility", "1f0087:00", 0},
            {"BATMANJAPAN", "Stage Select", "1f0058:00", 0},
            {"BATTLELODERUNNERJAPAN", "Infinite Lives", "1f0972:02", 0},
            {"BATTLELODERUNNERJAPAN", "Invincibility Against Enemies", "1f0c7b:00", 0},
            {"BATTLEROYALEUSA", "Infinite Time", "1f1218:00", 0},
            {"BEBALLJAPAN", "Infinite Lives", "1f0912:09", 0},
            {"BEBALLJAPAN", "Infinite Time", "1f088c:09", 0},
            {"BENKEIGAIDENJAPAN", "Infinite Gold", "1f00b7:ff+1f00b8:ff", 0},
            {"BENKEIGAIDENJAPAN", "Stats Current Health", "1f0201:ff", 0},
            {"BENKEIGAIDENJAPAN", "Stats Max Health", "1f02c3:ff", 0},
            {"BIKKURIMANWORLDJAPAN", "Have Best Boots", "1f129d:03", 0},
            {"BIKKURIMANWORLDJAPAN", "Have Best Sword", "1f1292:05+1f1293:01", 0},
            {"BIKKURIMANWORLDJAPAN", "Have Shield", "1f1299:01", 0},
            {"BIKKURIMANWORLDJAPAN", "Have Tunic", "1f129c:01", 0},
            {"BIKKURIMANWORLDJAPAN", "Infinite Money", "1f1295:09+1f1296:09+1f1297:09", 0},
            {"BIKKURIMANWORLDJAPAN", "Infinite Time", "1f1399:fb", 0},
            {"BIKKURIMANWORLDJAPAN", "Invulnerability", "1f1746:01", 0},
            {"BIKKURIMANWORLDJAPAN", "Invulnerable to Enemy Damage", "1f1706:74", 0},
            {"BLACKHOLEASSAULTSCDJAPAN", "Infinite Time", "1f06f0:76", 0},
            {"BLACKHOLEASSAULTSCDJAPAN", "P1 Infinite Energy", "1f0961:23", 0},
            {"BLACKHOLEASSAULTSCDJAPAN", "P2 Infinite Energy", "1f096a:46", 0},
            {"BLACKHOLEASSAULTSCDJAPAN", "P2 Special Doesn't Count Up", "1f096a:00", 0},
            {"BLACKHOLEASSAULTSCDJAPAN", "Quickly Kill The Computer", "1f0962:00+1f096b:00", 0},
            {"BLAZINGLAZERS", "Infinite Lives", "1f0b7d:03", 0},
            {"BLAZINGLAZERS", "Infinite Smart Bombs", "1f0b81:03", 0},
            {"BLAZINGLAZERSUSA", "Infinite Bombs", "1f0381:03", 0},
            {"BLAZINGLAZERSUSA", "Infinite Lives", "1f037d:02", 0},
            {"BLAZINGLAZERSUSA", "Invincibility", "1f1310:02", 0},
            {"BLOODGEARSCDJAPAN", "Gun Never Overheats", "1f1e25:00", 0},
            {"BLOODGEARSCDJAPAN", "Infinite Energy", "1f1ee9:80", 0},
            {"BLOODGEARSCDJAPAN", "Infinite Flying", "1f1a66:92", 0},
            {"BLOODGEARSCDJAPAN", "Infinite M2 Seeking Missiles", "1f1bb2:20", 0},
            {"BLOODGEARSCDJAPAN", "Infinite Machine Gun", "1f1b98:40", 0},
            {"BLOODGEARSCDJAPAN", "Infinite Money", "1f1ee7:00", 0},
            {"BLOODIAJAPAN", "Disable Countdown", "1f162c:09+1f162d:09+1f162e:09", 0},
            {"BLOODYWOLF", "Infinite Energy (Deactivate to continue to next leve", "1f0d05:06", 0},
            {"BLOODYWOLF", "Infinite Grenades", "1f0d1a:62", 0},
            {"BLOODYWOLFUSA", "Infinite Energy", "1f0505:03", 0},
            {"BLOODYWOLFUSA", "Infinite Fuel", "1f0516:06", 0},
            {"BLOODYWOLFUSA", "Infinite Grenades", "1f051a:20", 0},
            {"BODYCONQUESTIIJAPANUNL", "Infinite Gold", "1f08ff:ff+1f0900:ff", 0},
            {"BODYCONQUESTIIJAPANUNL", "Infinite HP", "1f08fe:ff", 0},
            {"BOMBERMAN", "Infinite Lives", "1f0c38:09", 0},
            {"BOMBERMAN", "Infinite Time (Seconds)", "1f158e:3d", 0},
            {"BOMBERMAN93", "Infinite Time (Seconds)", "1f08b6:3d", 0},
            {"BOMBERMAN93SPECIALEDITIONJAPAN", "Infinite Time", "1f00bd:59", 0},
            {"BOMBERMAN93USA", "Freeze Time", "1f00b6:3b", 0},
            {"BOMBERMAN93USA", "Infinite Lives", "1f189f:02", 0},
            {"BOMBERMAN93USA", "Invincibility", "1f0c01:b7+1f0c35:86", 0},
            {"BOMBERMAN94", "Infinite Lives", "1f1f04:09", 0},
            {"BOMBERMAN94JAPAN", "Infinite Lives", "1f1704:03", 0},
            {"BOMBERMAN94JAPAN", "Infinite Time", "1f1b8b:59", 0},
            {"BOMBERMANPANICBOMBERSCDJAPAN", "Both Players Have Red Bombs", "1f0098:00", 0},
            {"BOMBERMANUSA", "Infinite Lives", "1f0065:00", 0},
            {"BOMBERMANUSA", "Infinite Lives", "1f0d8e:09", 0},
            {"BOMBERMANUSA", "Infinite Time", "1f0d84:04+1f0d8e:00", 0},
            {"BOMBERMANUSA", "Invincible", "1f043a:00", 0},
            {"BOMBERMANUSERSBATTLEJAPAN", "Infinite Time", "1f0d6f:3b", 0},
            {"BONK3BONKSBIGADVENTURE", "Infinite Energy (Deactivate to continue to next leve", "1f138f:10", 0},
            {"BONK3BONKSBIGADVENTUREUSA", "Infinite Energy", "1f0b8f:0f", 0},
            {"BONK3BONKSBIGADVENTUREUSA", "Infinite Lives", "1f0b8d:02", 0},
            {"BONK3BONKSBIGADVENTUREUSA", "Invincibility", "1f09b6:01", 0},
            {"BONKIIIBONKSBIGADVENTURESCDJAPAN", "Infinite Health (Both Players)", "1f05c6:20", 0},
            {"BONKIIIBONKSBIGADVENTURESCDJAPAN", "Infinite Lives (Both Players)", "1f05a7:09", 0},
            {"BONKIIIBONKSBIGADVENTURESCDJAPAN", "Infinite Time", "1f0b10:30", 0},
            {"BONKIIIBONKSBIGADVENTURESCDJAPAN", "Player 1 Invincibility", "1f0c93:20", 0},
            {"BONKIIIBONKSBIGADVENTURESCDJAPAN", "Player 2 Invincibility", "1f0c94:20", 0},
            {"BONKIIIBONKSBIGADVENTURESCDUSA", "Infinite Energy (Both Players)", "1f05c6:20", 0},
            {"BONKIIIBONKSBIGADVENTURESCDUSA", "Infinite Smiley Faces (Pause Screen)", "1f05c2:10", 0},
            {"BONKIIIBONKSBIGADVENTURESCDUSA", "Infinite Time", "1f0b10:30", 0},
            {"BONKIIIBONKSBIGADVENTURESCDUSA", "P1 Invincible", "1f0c93:20", 0},
            {"BONKIIIBONKSBIGADVENTURESCDUSA", "P2 Invincible", "1f0c94:20", 0},
            {"BONKSADVENTUREUSA", "Big Meat Bonk", "1f0dba:02", 0},
            {"BONKSADVENTUREUSA", "Infinite Energy", "1f0db4:0f", 0},
            {"BONKSADVENTUREUSA", "Infinite Lives", "1f0db1:02", 0},
            {"BONKSADVENTUREUSA", "Invincibility", "1f0c03:01", 0},
            {"BONKSADVENTUREUSA", "Max Jump Height", "1f0db6:63", 0},
            {"BONKSADVENTUREUSA", "Max Speed", "1f0db7:07", 0},
            {"BONKSREVENGEUSA", "Infinite Energy", "1f0e87:0f", 0},
            {"BONKSREVENGEUSA", "Infinite Lives", "1f0a1a:02", 0},
            {"BONKSREVENGEUSA", "Infinite Time in Bonus Rounds", "1f1602:45", 0},
            {"BONKSREVENGEUSA", "Invincibility", "1f0e9a:01", 0},
            {"BONZEADVENTURE", "Infinite Lives", "1f1959:05", 0},
            {"BOUKENDANSHAKUDONTHELOSTSUNHEARTJAPAN", "Infinite Energy", "1f0717:08", 0},
            {"BOUKENDANSHAKUDONTHELOSTSUNHEARTJAPAN", "Infinite Lives", "1f070f:03", 0},
            {"BOUKENDANSHAKUDONTHELOSTSUNHEARTJAPAN", "Invincibility", "1f0718:27", 0},
            {"BOUKENDANSHAKUDONTHELOSTSUNHEARTJAPAN", "Kill Bosses With 1 Hit", "1f0833:00", 0},
            {"BOXYBOYUSA", "Instant Win", "1f0032:01+1f0055:01", 0},
            {"BRANDISHACDSCDJAPAN", "Stats Current Life", "1f0303:15+1f0304:15", 0},
            {"BRANDISHACDSCDJAPAN", "Stats Current Magic", "1f0305:15+1f0306:15", 0},
            {"BRANDISHACDSCDJAPAN", "Stats Max Life", "1f02ff:15+1f0300:15", 0},
            {"BRANDISHACDSCDJAPAN", "Stats Max Magic", "1f0301:15+1f0302:15", 0},
            {"BRAVOMANUSA", "Infinite Energy", "1f0257:20", 0},
            {"BRAVOMANUSA", "Invincibilitiy", "1f0256:01", 0},
            {"BROWNINGSCDJAPAN", "Infinite Energy", "1f0308:08", 0},
            {"BULLFIGHTRINGNOHASHAJAPAN", "CPU/Player 2 No POW", "1f0926:00", 0},
            {"BULLFIGHTRINGNOHASHAJAPAN", "CPU/Player 2 No SPD", "1f092a:00", 0},
            {"BULLFIGHTRINGNOHASHAJAPAN", "CPU/Player 2 No STA", "1f0928:00", 0},
            {"BULLFIGHTRINGNOHASHAJAPAN", "CPU/Player 2 No TEC", "1f092c:00", 0},
            {"BULLFIGHTRINGNOHASHAJAPAN", "Player 1 1-Hit for Knockdown", "1f0792:00", 0},
            {"BULLFIGHTRINGNOHASHAJAPAN", "Player 1 1-Hit for TKO", "1f02b5:03", 0},
            {"BULLFIGHTRINGNOHASHAJAPAN", "Player 1 Infinite Energy", "1f07a1:48", 0},
            {"BULLFIGHTRINGNOHASHAJAPAN", "Player 1 Max POW", "1f0925:63", 0},
            {"BULLFIGHTRINGNOHASHAJAPAN", "Player 1 Max SPD", "1f0929:63", 0},
            {"BULLFIGHTRINGNOHASHAJAPAN", "Player 1 Max STA", "1f0927:63", 0},
            {"BULLFIGHTRINGNOHASHAJAPAN", "Player 1 Max TEC", "1f092b:63", 0},
            {"BURAIHACHIGYOKUNOYUUSHIDENSETSUCDJAPAN", "C1 Stats Current Health", "1f160f:25+1f1610:25", 0},
            {"BURAIHACHIGYOKUNOYUUSHIDENSETSUCDJAPAN", "C1 Stats Current Magic", "1f1611:25+1f1612:25", 0},
            {"BURAIHACHIGYOKUNOYUUSHIDENSETSUCDJAPAN", "Infinite Gold", "1f12c2:25+1f12c3:25", 0},
            {"BURNINGANGELSJAPAN", "Infinite Energy", "1f07e8:63", 0},
            {"BURNINGANGELSJAPAN", "Invincibility", "1f0733:02", 0},
            {"BURNINGANGELSJAPAN", "Player 1 Have (M) Missile", "1f07ec:01", 0},
            {"BURNINGANGELSJAPAN", "Player 1 Max (P) Upgrades", "1f07ea:02", 0},
            {"BUSOUKEIJICYBERCROSSJAPAN", "Freeze Time", "1f0e82:89", 0},
            {"BUSOUKEIJICYBERCROSSJAPAN", "Infinite Energy", "1f1366:71", 0},
            {"BUSTERBROSCDJAPAN", "All Bubbles Are Small", "1f0efb:00+1f0efc:00+1f0efd:00+1f0efe:00+1f0eff:00", 0},
            {"BUSTERBROSCDJAPAN", "Enemies Are Frozen", "1f0078:00", 0},
            {"BUSTERBROSCDJAPAN", "Infinite Lives", "1f003f:05", 0},
            {"BUSTERBROSCDUSA", "All Bubbles Are Small", "1f0efb:00+1f0efc:00+1f0efd:00+1f0efe:00+1f0eff:00", 0},
            {"BUSTERBROSCDUSA", "Enemies Are Frozen", "1f0078:00", 0},
            {"BUSTERBROSCDUSA", "Infinite Lives", "1f003f:05", 0},
            {"CADASHUSA", "Infinite Antidote", "1f1c05:08", 0},
            {"CADASHUSA", "Infinite Energy", "1f1bf7:ff", 0},
            {"CADASHUSA", "Infinite Gold", "1f1c01:0f+1f1c02:27", 0},
            {"CADASHUSA", "Infinite Herbs", "1f1bcb:08", 0},
            {"CADASHUSA", "Invincibility (must be hit once, room per room basis", "1f0a04:14", 0},
            {"CADASHUSA", "Player 1 Level 20", "1f1beb:14", 0},
            {"CDDENJINROCKABILLYTENGOKUSCDJAPAN", "Infinite Lives", "1f065a:10", 0},
            {"CDDENJINROCKABILLYTENGOKUSCDJAPAN", "invincibility", "1f0b9d:20", 0},
            {"CHAMPIONSFOREVERBOXINGUSA", "Infinite Time", "1f0245:02+1f0246:05+1f0247:09", 0},
            {"CHAMPIONSFOREVERBOXINGUSA", "P1 Infinite Stamina", "1f0258:48", 0},
            {"CHAMPIONSFOREVERBOXINGUSA", "P1 Infinite Strength", "1f0254:48", 0},
            {"CHAMPIONSFOREVERBOXINGUSA", "P1 Knockdown for TKO", "1f05ac:03", 0},
            {"CHAMPIONSFOREVERBOXINGUSA", "P2 No Stamina", "1f025a:00", 0},
            {"CHAMPIONSFOREVERBOXINGUSA", "P2 No Strength", "1f0256:00", 0},
            {"CHAMPIONSHIPRALLYSCDJAPAN", "Always Low Time", "1f06d5:00", 0},
            {"CHAMPIONWRESTLINGJAPAN", "Infinite Energy", "1f020c:80", 0},
            {"CHAMPIONWRESTLINGJAPAN", "Infinite Time", "1f0752:05+1f0753:00+1f0754:00", 0},
            {"CHASEHQJ", "Time Left", "1f0853:14", 0},
            {"CHASEHQUSA", "Boss Has No Energy", "1f07d2:14", 0},
            {"CHASEHQUSA", "Infinite Time", "1f0053:50", 0},
            {"CHASEHQUSA", "Infinite Turbo", "1f07a7:03", 0},
            {"CHASEHQUSA", "Max Speed", "1f00a3:ff", 0},
            {"CHEWMANFU", "Diamonds set to whatever you want up to 21", "1f110e:15", 0},
            {"CHEWMANFU", "Infinite Lives", "1f1112:09", 0},
            {"CHEWMANFUUSA", "Infinite Lives", "1f0912:02", 0},
            {"CHEWMANFUUSA", "Infinite Time", "1f088b:93+1f088c:09", 0},
            {"CHEWMANFUUSA", "Invincibility", "1f00db:20", 0},
            {"CHIKICHIKIBOYSSCDJAPAN", "P1 Infinite Health", "1f0472:32", 0},
            {"CHIKICHIKIBOYSSCDJAPAN", "P1 Invincible", "1f0096:20", 0},
            {"CHIKICHIKIBOYSSCDJAPAN", "P2 Infinite Health", "1f04b2:32", 0},
            {"CHIKICHIKIBOYSSCDJAPAN", "P2 Invincible", "1f0098:20", 0},
            {"CHINAWARRIOR", "Infinite Energy", "1f13c3:05", 0},
            {"CHINAWARRIORUSA", "Infinite Energy", "1f0bc3:0a", 0},
            {"CHINAWARRIORUSA", "Infinite Lives", "1f0be4:03", 0},
            {"CHOUANIKISCDJAPAN", "Infinite Bombs", "1f000e:09", 0},
            {"CHOUANIKISCDJAPAN", "Infinite Lives", "1f0002:09", 0},
            {"CHOUJIKUUYOUSAIMACROSS2036SCDJAPAN", "Invincibility", "1f1829:10", 0},
            {"CHOUZETSURINJINBRAVOMANJAPAN", "Infinite Health", "1f0257:14", 0},
            {"CHOUZETSURINJINBRAVOMANJAPAN", "Invincibility", "1f0258:01", 0},
            {"CHOUZETSURINJINBRAVOMANJAPAN", "Invulnerability", "1f0256:37", 0},
            {"CIRCUSLIDOJAPAN", "Infinite Lives", "1f0083:02", 0},
            {"CITYHUNTER", "Infinite Power", "1f139c:10", 0},
            {"CITYHUNTERJAPAN", "Infinite Energy", "1f0b9c:16", 0},
            {"CITYHUNTERJAPAN", "Invulnerability", "1f0b9e:b7", 0},
            {"CITYHUNTERJTENG", "Infinite Health", "1f0b9c:16", 0},
            {"CITYHUNTERJTENG", "Invincibility", "1f0b9e:b7", 0},
            {"COLUMNSJAPAN", "Max Jewels Collected", "1f034b:ff+1f034c:63", 0},
            {"CORYOONCHILDOFDRAGONJAPAN", "Infinite Energy", "1f00c7:c7", 0},
            {"CORYOONCHILDOFDRAGONJAPAN", "Infinite Lives", "1f1e23:05", 0},
            {"CORYOONCHILDOFDRAGONJAPAN", "Invincibility", "1f151e:02", 0},
            {"COSMICFANTASYBOUKENSHOUNENYUUCDJAPAN", "Infinite Gold", "1f11e8:25+1f11e9:25", 0},
            {"COSMICFANTASYBOUKENSHOUNENYUUCDJAPAN", "Stats Current HP", "1f1200:25", 0},
            {"COSMICFANTASYBOUKENSHOUNENYUUCDJAPAN", "Stats Current MP", "1f1202:25", 0},
            {"COSMICFANTASYBOUKENSHOUNENYUUCDJAPAN", "Stats Max HP", "1f1204:25", 0},
            {"COSMICFANTASYBOUKENSHOUNENYUUCDJAPAN", "Stats Max MP", "1f1206:25", 0},
            {"COSMICFANTASYIICDUSA", "Infinite Gold", "1f041c:15+1f041d:15+1f041e:15", 0},
            {"COSMICFANTASYIICDUSA", "Stats Current HP", "1f031e:20", 0},
            {"COSMICFANTASYIICDUSA", "Stats Current MP", "1f030b:20", 0},
            {"COSMICFANTASYIICDUSA", "Stats Max Agility", "1f030f:20", 0},
            {"COSMICFANTASYIICDUSA", "Stats Max Attack", "1f0313:20", 0},
            {"COSMICFANTASYIICDUSA", "Stats Max Defense", "1f0315:20", 0},
            {"COSMICFANTASYIICDUSA", "Stats Max HP", "1f0309:20", 0},
            {"COSMICFANTASYIICDUSA", "Stats Max MP", "1f030b:20", 0},
            {"COSMICFANTASYIICDUSA", "Stats Max Power", "1f030d:20", 0},
            {"COSMICFANTASYIICDUSA", "Stats Max Wisdom", "1f0311:20", 0},
            {"COSMICFANTASYIIIBOUKENSHOUNENREISCDJAPAN", "Infinite Gold", "1f0485:15+1f0486:15+1f0487:15", 0},
            {"COSMICFANTASYIIIBOUKENSHOUNENREISCDJAPAN", "Infinite HP", "1f0319:25+1f06e4:25+1f0742:25", 0},
            {"COSMICFANTASYIIIBOUKENSHOUNENREISCDJAPAN", "Infinite MP", "1f031b:25+1f06e6:25+1f0744:25", 0},
            {"COTTONFANTASTICNIGHTDREAMSSCDUSA", "Invincible", "1f1261:20", 0},
            {"CRATERMAZEUSA", "Infinite Lives", "1f1aff:05", 0},
            {"CRATERMAZEUSA", "Infinite Time", "1f1af8:3b", 0},
            {"CRATERMAZEUSA", "Invincibility", "1f0053:04", 0},
            {"CRATERMAZEUSA", "One Object To Get Key", "1f1b0c:01", 0},
            {"CRAZYJAPPYPLATFORMER", "Infinite Energy (16)", "1f0828:10", 0},
            {"CROSSWIBERCYBERCOMBATPOLICEJAPAN", "Infinite Energy", "1f1117:27", 0},
            {"CROSSWIBERCYBERCOMBATPOLICEJAPAN", "Invincibility", "1f06e4:01", 0},
            {"CYBERCOREUSA", "Infinite Lives", "1f0069:02", 0},
            {"CYBERCOREUSA", "Infinite Shields", "1f112c:03", 0},
            {"CYBERDODGEJAPAN", "CPU/P2 Char 1 1-Hit Kill", "1f0607:00", 0},
            {"CYBERDODGEJAPAN", "CPU/P2 Char 2 1-Hit Kill", "1f0608:00", 0},
            {"CYBERDODGEJAPAN", "CPU/P2 Char 3 1-Hit Kill", "1f0609:00", 0},
            {"CYBERDODGEJAPAN", "CPU/P2 Char 4 1-Hit Kill", "1f060a:00", 0},
            {"CYBERDODGEJAPAN", "P1 Char 1 Infinite Health", "1f060f:18", 0},
            {"CYBERDODGEJAPAN", "P1 Char 2 Infinite Health", "1f061f:18", 0},
            {"CYBERDODGEJAPAN", "P1 Char 3 Infinite Health", "1f062f:18", 0},
            {"CYBERDODGEJAPAN", "P1 Char 4 Infinite Health", "1f063f:18", 0},
            {"CYBERKNIGHTJAPAN", "Infinite Stat Points (Disable once stats are maxed)", "1f0ddd:06", 0},
            {"DAIMAKAIMURAJAPAN", "Always Have Gold Armor", "1f0b58:01+1f0b5a:03", 0},
            {"DAIMAKAIMURAJAPAN", "Infinite Credits", "1f0cd4:09", 0},
            {"DAIMAKAIMURAJAPAN", "Infinite Lives", "1f0b5b:03", 0},
            {"DAIMAKAIMURAJAPAN", "Infinite Lives", "1f0b5b:05", 0},
            {"DAIMAKAIMURAJAPAN", "Infinite Time", "1f0cda:99+1f0cdb:09", 0},
            {"DAIMAKAIMURAJAPAN", "Invincible", "1f0ae8:14", 0},
            {"DAIMAKAIMURAJAPAN", "Never Lose Armor", "1f0b58:01+1f0b5a:02", 0},
            {"DAISENPUUCUSTOMCDJAPAN", "Infinite Bombs", "1f08b1:02", 0},
            {"DAISENPUUCUSTOMCDJAPAN", "Infinite Credits", "1f08a0:09", 0},
            {"DAISENPUUCUSTOMCDJAPAN", "Infinite Lives", "1f08a4:02", 0},
            {"DAISENPUUCUSTOMCDJAPAN", "Max Upgraded Guns", "1f08b2:03", 0},
            {"DAISENPUUJAPAN", "Infinite Bombs", "1f0a21:02", 0},
            {"DAISENPUUJAPAN", "Infinite Lives", "1f02a4:02", 0},
            {"DAISENPUUJAPAN", "Invincibility", "1f0380:03+1f061d:27", 0},
            {"DARIUSALPHAJAPANSGENHANCED", "Infinite Lives", "1f09ca:04", 0},
            {"DARIUSALPHAJAPANSGENHANCED", "Invincibility", "1f09b7:36", 0},
            {"DARIUSPLUSJAPANSGENHANCED", "Infinite Lives", "1f09c6:04", 0},
            {"DARIUSPLUSJAPANSGENHANCED", "Invincibility", "1f09b3:36", 0},
            {"DARIUSPLUSJAPANSGENHANCED", "Max Bomb", "1f09bc:23", 0},
            {"DARIUSPLUSJAPANSGENHANCED", "Max Miss", "1f09be:23", 0},
            {"DARKWINGDUCKUSA", "Infinite Ammo", "1f1fb6:09", 0},
            {"DARKWINGDUCKUSA", "Infinite Lives", "1f02ff:02", 0},
            {"DEADMOON", "Infinite Bombs", "1f0822:09", 0},
            {"DEADMOON", "Infinite Lives", "1f0821:09", 0},
            {"DEADMOONGETSUSEKAINOAKUMUJAPAN", "Infinite Bombs", "1f0022:03", 0},
            {"DEADMOONGETSUSEKAINOAKUMUJAPAN", "Infinite Lives", "1f0021:02", 0},
            {"DEADMOONGETSUSEKAINOAKUMUJAPAN", "Invincibility", "1f08f6:03", 0},
            {"DEADMOONUSA", "Infinite Bombs", "1f0022:03", 0},
            {"DEADMOONUSA", "Infinite Lives", "1f0021:02", 0},
            {"DEADMOONUSA", "Invincibility", "1f08f6:03", 0},
            {"DEDENNODENSCDJAPAN", "Disable Timer", "1f1bb7:00", 0},
            {"DEDENNODENSCDJAPAN", "Infinite Time", "1f1bb8:00+1f1bb9:03", 0},
            {"DEDENNODENSCDJAPAN", "P1 Max Bomb Upgrade", "1f1bce:10", 0},
            {"DEDENNODENSCDJAPAN", "P1 Max Flame Upgrade", "1f1bdd:03", 0},
            {"DEEPBLUEUSA", "Infinite Energy", "1f0049:ff", 0},
            {"DETANATWINBEE", "Infinite Lives", "1f0887:09", 0},
            {"DETANATWINBEEJAPAN", "P1 Infinite Lives", "1f0087:09", 0},
            {"DETANATWINBEEJAPAN", "P1 Invincible", "1f180d:14", 0},
            {"DETANATWINBEEJAPAN", "P2 Infinite Lives", "1f0088:09", 0},
            {"DETANATWINBEEJAPAN", "P2 Invincible", "1f180e:14", 0},
            {"DEVILCRUSHNAXATPINBALLJAPAN", "Infinite Balls", "1f0d52:64", 0},
            {"DEVILSCRUSHUSA", "Infinite Balls", "1f0d52:03", 0},
            {"DIEHARD", "Weapon Ammo Amount", "1f1e58:ff", 0},
            {"DIEHARDJAPAN", "Infinite Ammo", "1f1658:64", 0},
            {"DIEHARDJAPAN", "Infinite Continues", "1f060a:09", 0},
            {"DIEHARDJAPAN", "Infinite Energy", "1f0421:23", 0},
            {"DIEHARDJAPAN", "Infinite Time", "1f1656:59", 0},
            {"DIGITALCHAMPJAPAN", "Infinite Energy", "1f020e:56", 0},
            {"DONDOKODONJAPAN", "Infinite Credits", "1f0021:09", 0},
            {"DONDOKODONJAPAN", "Infinite Lives", "1f1955:03", 0},
            {"DONDOKODONJAPAN", "Invincibility", "1f0528:01", 0},
            {"DORAEMONMEIKYUUDAISAKUSENJAPAN", "Infinite Lives", "1f1aff:05", 0},
            {"DORAEMONMEIKYUUDAISAKUSENJAPAN", "Infinite Time", "1f1af8:59", 0},
            {"DORAEMONMEIKYUUDAISAKUSENJAPAN", "Invincibility", "1f0053:04", 0},
            {"DORAEMONMEIKYUUDAISAKUSENJAPAN", "One Object Get Key", "1f1b0c:01", 0},
            {"DORAEMONNOBITANODORABIANNIGHTJAPAN", "Infinite Energy", "1f08d9:04", 0},
            {"DORAEMONNOBITANODORABIANNIGHTJAPAN", "Infinite Lives", "1f09dc:02", 0},
            {"DORAEMONNOBITANODORABIANNIGHTJAPAN", "Invincibility", "1f0099:02", 0},
            {"DORAEMONNOBITANODORABIANNIGHTSCDJAPAN", "Infinite Barrier Shield", "1f0dd9:20", 0},
            {"DORAEMONNOBITANODORABIANNIGHTSCDJAPAN", "Infinite Health", "1f08d9:04", 0},
            {"DORAEMONNOBITANODORABIANNIGHTSCDJAPAN", "Infinite Lives", "1f09dc:09", 0},
            {"DORAEMONNOBITANODORABIANNIGHTSCDJAPAN", "Invincible (Disable Stun)", "1f0099:20", 0},
            {"DOUBLEDRAGONIITHEREVENGESCDJAPAN", "Infinite Time", "1f16b0:99", 0},
            {"DOUBLEDRAGONIITHEREVENGESCDJAPAN", "Invincibility", "1f1347:46", 0},
            {"DOUBLEDRAGONIITHEREVENGESCDJAPAN", "P1 Infinite Health", "1f1351:40", 0},
            {"DOUBLEDUNGEONSUSA", "Free Inn Visits", "1f0364:00", 0},
            {"DOUBLEDUNGEONSUSA", "Infinite Gold", "1f0313:ff+1f0314:ff", 0},
            {"DOUBLEDUNGEONSUSA", "Max Level Up", "1f0315:ff+1f0316:ff", 0},
            {"DOUBLEDUNGEONSUSA", "Stat Current HP", "1f0309:00+1f030a:04", 0},
            {"DOUBLEDUNGEONSUSA", "Stat Max HP", "1f030b:00+1f030c:04", 0},
            {"DOWNLOAD", "Infinite Weapon Ammo", "1f0dfa:62", 0},
            {"DOWNLOADIISCDJAPAN", "Have Max Weapon Upgrades", "1f005b:03", 0},
            {"DOWNLOADIISCDJAPAN", "Infinite Lives", "1f0059:05", 0},
            {"DOWNLOADIISCDJAPAN", "Infinite Shield", "1f005d:05", 0},
            {"DOWNLOADIISCDJAPAN", "Invincibility (Die Once to Activate)", "1f1715:05", 0},
            {"DOWNLOADJAPAN", "Infinite Energy", "1f05e8:03", 0},
            {"DOWNLOADJAPAN", "Infinite Special Weapon", "1f05fa:99", 0},
            {"DOWNLOADJAPAN", "Invincibility", "1f05e7:9b", 0},
            {"DOWNLOADJAPAN", "Max Weapon Upgrade", "1f05e9:04", 0},
            {"DOWNTOWNNEKKETSUMONOGATARISCDJAPAN", "P1 Infinite Health", "1f09c2:63+1f09db:63", 0},
            {"DOWNTOWNNEKKETSUMONOGATARISCDJAPAN", "P1 Infinite Money", "1f09ca:15+1f09cc:15", 0},
            {"DOWNTOWNNEKKETSUMONOGATARISCDJAPAN", "P2 Infinite Health", "1f09c3:63+1f09dc:63", 0},
            {"DOWNTOWNNEKKETSUMONOGATARISCDJAPAN", "P2 Infinite Money", "1f09cd:15+1f09cf:15", 0},
            {"DRAGONEGGJAPAN", "Easy boss Kill", "1f0367:00", 0},
            {"DRAGONEGGJAPAN", "Have 4 Cure Jars", "1f16d1:04", 0},
            {"DRAGONEGGJAPAN", "Have Barrier", "1f16cd:01", 0},
            {"DRAGONEGGJAPAN", "Have Skull", "1f16d2:01", 0},
            {"DRAGONEGGJAPAN", "Infinite Energy", "1f0365:04", 0},
            {"DRAGONEGGJAPAN", "Infinite Gold", "1f1665:ff", 0},
            {"DRAGONEGGJAPAN", "Infinite Lives", "1f18b8:03", 0},
            {"DRAGONEGGJAPAN", "Max Dragon Up", "1f16cf:02", 0},
            {"DRAGONEGGJAPAN", "Max Life Up", "1f16d0:02", 0},
            {"DRAGONEGGJAPAN", "Max Strength Up", "1f16ce:02", 0},
            {"DRAGONHALFSCDJAPAN", "Infinite Moves", "1f1f14:14", 0},
            {"DRAGONKNIGHTGRAFITTISCDJAPAN", "Infinite Money", "1f16e1:25+1f16e2:25", 0},
            {"DRAGONKNIGHTGRAFITTISCDJAPAN", "Quick Level Up", "1f16e5:25", 0},
            {"DRAGONKNIGHTGRAFITTISCDJAPAN", "Stats Current HP", "1f16f9:25", 0},
            {"DRAGONKNIGHTGRAFITTISCDJAPAN", "Stats Current MP", "1f16fb:25", 0},
            {"DRAGONKNIGHTGRAFITTISCDJAPAN", "Stats Max Defense", "1f16ed:25", 0},
            {"DRAGONKNIGHTGRAFITTISCDJAPAN", "Stats Max HP", "1f16e3:25", 0},
            {"DRAGONKNIGHTGRAFITTISCDJAPAN", "Stats Max MP", "1f16e7:25", 0},
            {"DRAGONKNIGHTGRAFITTISCDJAPAN", "Stats Max Strength", "1f16eb:25", 0},
            {"DRAGONSABERAFTERSTORYOFDRAGONSPIRITJAPAN", "Infinite Credits", "1f17ff:09", 0},
            {"DRAGONSABERAFTERSTORYOFDRAGONSPIRITJAPAN", "Infinite Energy", "1f17bd:03", 0},
            {"DRAGONSABERAFTERSTORYOFDRAGONSPIRITJAPAN", "Infinite Lives", "1f17fd:03", 0},
            {"DRAGONSABERAFTERSTORYOFDRAGONSPIRITJAPAN", "Invincibility", "1f151c:02", 0},
            {"DRAGONSCURSEUSA", "Aqua Shield", "1f13f9:01", 0},
            {"DRAGONSCURSEUSA", "Crystal Armor", "1f1400:01", 0},
            {"DRAGONSCURSEUSA", "Crystal Shield", "1f13f6:01", 0},
            {"DRAGONSCURSEUSA", "Crystal Sword", "1f13ec:01", 0},
            {"DRAGONSCURSEUSA", "Dancing Shield", "1f13f8:01", 0},
            {"DRAGONSCURSEUSA", "Dragon Mail", "1f1403:01", 0},
            {"DRAGONSCURSEUSA", "Goblin Mail", "1f1401:01", 0},
            {"DRAGONSCURSEUSA", "Hades Armor", "1f1405:01", 0},
            {"DRAGONSCURSEUSA", "Heavenly Shield", "1f13fb:01", 0},
            {"DRAGONSCURSEUSA", "Infinite Energy", "1f141a:28", 0},
            {"DRAGONSCURSEUSA", "Infinite Gold", "1f1422:09", 0},
            {"DRAGONSCURSEUSA", "Ivory Armor", "1f13fd:01", 0},
            {"DRAGONSCURSEUSA", "Ivory Shield", "1f13f3:01", 0},
            {"DRAGONSCURSEUSA", "Ivory Sword", "1f13e9:01", 0},
            {"DRAGONSCURSEUSA", "Knight Shield", "1f13f7:01", 0},
            {"DRAGONSCURSEUSA", "Legendary Armor", "1f13fc:01", 0},
            {"DRAGONSCURSEUSA", "Legendary Shield", "1f13f2:01", 0},
            {"DRAGONSCURSEUSA", "Legendary Sword", "1f13e8:01", 0},
            {"DRAGONSCURSEUSA", "Lucky Sword", "1f13ef:01", 0},
            {"DRAGONSCURSEUSA", "Magical Saber", "1f13ee:01", 0},
            {"DRAGONSCURSEUSA", "Master Shield", "1f13fa:01", 0},
            {"DRAGONSCURSEUSA", "Max Gold", "1f141d:09+1f141e:09+1f141f:09+1f1420:09+1f1421:09", 0},
            {"DRAGONSCURSEUSA", "Mithril Armor", "1f13fe:01", 0},
            {"DRAGONSCURSEUSA", "Mithril Shield", "1f13f4:01", 0},
            {"DRAGONSCURSEUSA", "Mithril Sword", "1f13ea:01", 0},
            {"DRAGONSCURSEUSA", "Muramasa Blade", "1f13f0:01", 0},
            {"DRAGONSCURSEUSA", "Prince Armor", "1f1404:01", 0},
            {"DRAGONSCURSEUSA", "Samurai Armor", "1f1402:01", 0},
            {"DRAGONSCURSEUSA", "Shogun Blade", "1f13eb:01", 0},
            {"DRAGONSCURSEUSA", "Shogun Lemellar", "1f13ff:01", 0},
            {"DRAGONSCURSEUSA", "Shogun Shield", "1f13f5:01", 0},
            {"DRAGONSCURSEUSA", "Tasmanian Sword", "1f13f1:01", 0},
            {"DRAGONSCURSEUSA", "Thunder Saber", "1f13ed:01", 0},
            {"DRAGONSCURSEUSA", "Unlimited Arrows", "1f1408:63", 0},
            {"DRAGONSCURSEUSA", "Unlimited Boomerang", "1f1409:63", 0},
            {"DRAGONSCURSEUSA", "Unlimited Fireballs", "1f1406:63", 0},
            {"DRAGONSCURSEUSA", "Unlimited Lightning", "1f140a:63", 0},
            {"DRAGONSCURSEUSA", "Unlimited Whirlwind", "1f1407:63", 0},
            {"DRAGONSPIRIT", "Infinite Lives", "1f0843:09", 0},
            {"DRAGONSPIRITUSA", "Infinite Energy", "1f0044:03", 0},
            {"DRAGONSPIRITUSA", "Infinite Lives", "1f0043:02", 0},
            {"DROPOFF", "Infinite Lives", "1f14c1:03", 0},
            {"DROPOFFUSA", "Infinite Lives", "1f0246:03", 0},
            {"DROPOFFUSA", "Infinite Ups", "1f03c5:03", 0},
            {"DROPROCKHORAHORAJAPAN", "Infinite Lives", "1f0246:09", 0},
            {"DROPROCKHORAHORAJAPAN", "Infinite Ups", "1f03c5:09", 0},
            {"DUNGEONEXPLORERIISCDJAPAN", "PRO1 Stats Current HP", "1f15bd:25", 0},
            {"DUNGEONEXPLORERIISCDJAPAN", "PRO1 Stats Max Agility", "1f0ede:20", 0},
            {"DUNGEONEXPLORERIISCDJAPAN", "PRO1 Stats Max Attack", "1f0ee3:20", 0},
            {"DUNGEONEXPLORERIISCDJAPAN", "PRO1 Stats Max Intelligence", "1f0eed:20", 0},
            {"DUNGEONEXPLORERIISCDJAPAN", "PRO1 Stats Max Power", "1f0ee8:20", 0},
            {"DUNGEONEXPLORERIISCDJAPAN", "PRO2 Stats Current HP", "1f15be:25", 0},
            {"DUNGEONEXPLORERIISCDJAPAN", "PRO2 Stats Max Agility", "1f0edf:20", 0},
            {"DUNGEONEXPLORERIISCDJAPAN", "PRO2 Stats Max Attack", "1f0ee4:20", 0},
            {"DUNGEONEXPLORERIISCDJAPAN", "PRO2 Stats Max Intelligence", "1f0eee:20", 0},
            {"DUNGEONEXPLORERIISCDJAPAN", "PRO2 Stats Max Power", "1f0ee9:20", 0},
            {"DUNGEONEXPLORERIISCDJAPAN", "PRO3 Stats Current HP", "1f15bf:25", 0},
            {"DUNGEONEXPLORERIISCDJAPAN", "PRO3 Stats Max Agility", "1f0ee0:20", 0},
            {"DUNGEONEXPLORERIISCDJAPAN", "PRO3 Stats Max Attack", "1f0ee5:20", 0},
            {"DUNGEONEXPLORERIISCDJAPAN", "PRO3 Stats Max Intelligence", "1f0eef:20", 0},
            {"DUNGEONEXPLORERIISCDJAPAN", "PRO3 Stats Max Power", "1f0eea:20", 0},
            {"DUNGEONEXPLORERIISCDJAPAN", "PRO4 Stats Current HP", "1f15c0:25", 0},
            {"DUNGEONEXPLORERIISCDJAPAN", "PRO4 Stats Max Agility", "1f0ee1:20", 0},
            {"DUNGEONEXPLORERIISCDJAPAN", "PRO4 Stats Max Attack", "1f0ee6:20", 0},
            {"DUNGEONEXPLORERIISCDJAPAN", "PRO4 Stats Max Intelligence", "1f0ef0:20", 0},
            {"DUNGEONEXPLORERIISCDJAPAN", "PRO4 Stats Max Power", "1f0eeb:20", 0},
            {"DUNGEONEXPLORERIISCDJAPAN", "PRO5 Stats Current HP", "1f15c1:25", 0},
            {"DUNGEONEXPLORERIISCDJAPAN", "PRO5 Stats Max Agility", "1f0ee2:20", 0},
            {"DUNGEONEXPLORERIISCDJAPAN", "PRO5 Stats Max Attack", "1f0ee7:20", 0},
            {"DUNGEONEXPLORERIISCDJAPAN", "PRO5 Stats Max Intelligence", "1f0ef1:20", 0},
            {"DUNGEONEXPLORERIISCDJAPAN", "PRO5 Stats Max Power", "1f0eec:20", 0},
            {"DUNGEONEXPLORERIISCDUSA", "PRO1 Stats Current HP", "1f15bd:25", 0},
            {"DUNGEONEXPLORERIISCDUSA", "PRO1 Stats Max Agility", "1f0ede:20", 0},
            {"DUNGEONEXPLORERIISCDUSA", "PRO1 Stats Max Attack", "1f0ee3:20", 0},
            {"DUNGEONEXPLORERIISCDUSA", "PRO1 Stats Max Intelligence", "1f0eed:20", 0},
            {"DUNGEONEXPLORERIISCDUSA", "PRO1 Stats Max Power", "1f0ee8:20", 0},
            {"DUNGEONEXPLORERIISCDUSA", "PRO2 Stats Current HP", "1f15be:25", 0},
            {"DUNGEONEXPLORERIISCDUSA", "PRO2 Stats Max Agility", "1f0edf:20", 0},
            {"DUNGEONEXPLORERIISCDUSA", "PRO2 Stats Max Attack", "1f0ee4:20", 0},
            {"DUNGEONEXPLORERIISCDUSA", "PRO2 Stats Max Intelligence", "1f0eee:20", 0},
            {"DUNGEONEXPLORERIISCDUSA", "PRO2 Stats Max Power", "1f0ee9:20", 0},
            {"DUNGEONEXPLORERIISCDUSA", "PRO3 Stats Current HP", "1f15bf:25", 0},
            {"DUNGEONEXPLORERIISCDUSA", "PRO3 Stats Max Agility", "1f0ee0:20", 0},
            {"DUNGEONEXPLORERIISCDUSA", "PRO3 Stats Max Attack", "1f0ee5:20", 0},
            {"DUNGEONEXPLORERIISCDUSA", "PRO3 Stats Max Intelligence", "1f0eef:20", 0},
            {"DUNGEONEXPLORERIISCDUSA", "PRO3 Stats Max Power", "1f0eea:20", 0},
            {"DUNGEONEXPLORERIISCDUSA", "PRO4 Stats Current HP", "1f15c0:25", 0},
            {"DUNGEONEXPLORERIISCDUSA", "PRO4 Stats Max Agility", "1f0ee1:20", 0},
            {"DUNGEONEXPLORERIISCDUSA", "PRO4 Stats Max Attack", "1f0ee6:20", 0},
            {"DUNGEONEXPLORERIISCDUSA", "PRO4 Stats Max Intelligence", "1f0ef0:20", 0},
            {"DUNGEONEXPLORERIISCDUSA", "PRO4 Stats Max Power", "1f0eeb:20", 0},
            {"DUNGEONEXPLORERIISCDUSA", "PRO5 Stats Current HP", "1f15c1:25", 0},
            {"DUNGEONEXPLORERIISCDUSA", "PRO5 Stats Max Agility", "1f0ee2:20", 0},
            {"DUNGEONEXPLORERIISCDUSA", "PRO5 Stats Max Attack", "1f0ee7:20", 0},
            {"DUNGEONEXPLORERIISCDUSA", "PRO5 Stats Max Intelligence", "1f0ef1:20", 0},
            {"DUNGEONEXPLORERIISCDUSA", "PRO5 Stats Max Power", "1f0eec:20", 0},
            {"DUNGEONEXPLORERUSA", "Infinite Lives", "1f02d4:ff", 0},
            {"DUNGEONSDRAGONSORDEROFTHEGRIFFONUSA", "Infinite Gold", "1f08ae:ff+1f08af:ff", 0},
            {"EFERAJILIORACDJAPAN", "Infinite MP (Efera)", "1f1422:99", 0},
            {"EFERAJILIORACDJAPAN", "Max HP Modifier (Efera)", "1f1404:00", 0},
            {"EFERAJILIORACDJAPAN", "Max HP Modifier (Jiliora)", "1f1405:00", 0},
            {"EFERAJILIORACDJAPAN", "Max Money", "1f141d:25", 0},
            {"EFERAJILIORACDJAPAN", "Quick Level Up (Efera)", "1f1400:25+1f1401:25", 0},
            {"EFERAJILIORACDJAPAN", "Quick Level Up (Jiliora)", "1f1402:25+1f1403:25", 0},
            {"ENERGYJAPAN", "Infinite Health", "1f06d7:64", 0},
            {"ETERNALCITYTOSHITENSOUKEIKAKUJAPAN", "Max Shield", "1f0508:50", 0},
            {"ETERNALCITYTOSHITENSOUKEIKAKUJAPAN", "Max Weapon", "1f0532:50", 0},
            {"EXILECDUSA", "Infinite Energy", "1f0838:50", 0},
            {"EXILECDUSA", "Invincibility", "1f0bb5:01", 0},
            {"EXILECDUSA", "Lots of Money", "1f0317:96", 0},
            {"EXILECDUSA", "Quick Level Up", "1f0309:96", 0},
            {"EXILEIIJANENNOJISHOUSCDJAPAN", "Invincibility", "1f002b:00+1f0b64:20", 0},
            {"EXILEIIWICKEDPHENOMENONSCDUSA", "Invincibility", "1f0b64:10", 0},
            {"EXILEIIWICKEDPHENOMENONSCDUSA", "Quick Level Up", "1f154c:55", 0},
            {"F1DREAMJAPAN", "No G/B Damage", "1f006f:26", 0},
            {"F1DREAMJAPAN", "No Tire Damage", "1f006e:26", 0},
            {"F1DREAMJAPAN", "Unlimited Time", "1f0060:00+1f0061:00", 0},
            {"F1TRIPLEBATTLEJAPAN", "Max Speed", "1f05d3:ff+1f05d4:ff", 0},
            {"F1TRIPLEBATTLEJAPAN", "Unlimited Time", "1f07aa:00+1f07ab:00", 0},
            {"FANTASYZONE", "Infinite Lives", "1f080c:07", 0},
            {"FANTASYZONEUSA", "Have Big Wing (Activate In Shop)", "1f061d:01", 0},
            {"FANTASYZONEUSA", "Have Jet Engine (Activate In Shop)", "1f061e:01", 0},
            {"FANTASYZONEUSA", "Have Laser Beam (Activate In Shop)", "1f0623:01", 0},
            {"FANTASYZONEUSA", "Have Rocket Engine (Activate In Shop)", "1f0620:01", 0},
            {"FANTASYZONEUSA", "Have Turbo Engine (Activate In Shop)", "1f061f:01", 0},
            {"FANTASYZONEUSA", "Have Wide Beam (Activate In Shop)", "1f0622:01", 0},
            {"FANTASYZONEUSA", "Max Gold", "1f11d4:99+1f11d5:99+1f11d6:99", 0},
            {"FANTASYZONEUSA", "Unlimited Lives", "1f000c:0a", 0},
            {"FARJIUSNOJAKOUTEINEOMETALFANTASYSCDJAPAN", "1-Hit Kill Enemy 1", "1f1ee1:00", 0},
            {"FARJIUSNOJAKOUTEINEOMETALFANTASYSCDJAPAN", "1-Hit Kill Enemy 2", "1f1ee3:00", 0},
            {"FARJIUSNOJAKOUTEINEOMETALFANTASYSCDJAPAN", "C1 Quick Level Up", "1f0def:25+1f0df0:25+1f0df1:25", 0},
            {"FARJIUSNOJAKOUTEINEOMETALFANTASYSCDJAPAN", "Infinite Gold", "1f0f20:25+1f0f21:25", 0},
            {"FARJIUSNOJAKOUTEINEOMETALFANTASYSCDJAPAN", "Infinite Magic Points", "1f0ffa:25+1f0ffb:25", 0},
            {"FAUSSETEAMOURSCDJAPAN", "1-Hit Kill (Sub-Bosses)", "1f0e4d:00+1f0ef5:00", 0},
            {"FAUSSETEAMOURSCDJAPAN", "Always Have Armour (Infinite Health)", "1f0006:01", 0},
            {"FAUSSETEAMOURSCDJAPAN", "Infinite Lives", "1f0007:02", 0},
            {"FAUSSETEAMOURSCDJAPAN", "Infinite Red Crystals", "1f14af:09", 0},
            {"FAUSSETEAMOURSCDJAPAN", "Invincibility", "1f0ca9:02", 0},
            {"FAUSSETEAMOURSCDJPN", "Always Have Armour (Unlimited Health)", "1f0006:01", 0},
            {"FIENDHUNTERSCDJAPAN", "Stats Current HP", "1f1917:25", 0},
            {"FIENDHUNTERSCDJAPAN", "Stats Current Psycho Power", "1f1919:25", 0},
            {"FIENDHUNTERSCDJAPAN", "Stats Max Arrow", "1f191e:07", 0},
            {"FIENDHUNTERSCDJAPAN", "Stats Max Blade", "1f191d:07", 0},
            {"FIENDHUNTERSCDJAPAN", "Stats Max HP", "1f1918:25", 0},
            {"FIENDHUNTERSCDJAPAN", "Stats Max Power", "1f191c:07", 0},
            {"FIENDHUNTERSCDJAPAN", "Stats Max Psycho Power", "1f191a:25", 0},
            {"FIENDHUNTERSCDJAPAN", "Stats Max Spark", "1f191f:07", 0},
            {"FIENDHUNTERSCDJAPAN", "Stats Max Vitality", "1f191b:07", 0},
            {"FIGHTINGRUNJAPAN", "1-Hit Kills", "1f0ddd:01", 0},
            {"FIGHTINGRUNJAPAN", "Infinite Energy", "1f0d7d:00", 0},
            {"FIGHTINGRUNJAPAN", "Max Stats", "1f14e5:04+1f14e6:04+1f14e7:04", 0},
            {"FIGHTINGSTREETCDJAPAN", "Infinite Credits", "1f0582:09", 0},
            {"FIGHTINGSTREETCDJAPAN", "Infinite Time (disable at end of round)", "1f057b:09", 0},
            {"FIGHTINGSTREETCDJAPAN", "P1 Infinite Health", "1f0598:48+1f0599:48", 0},
            {"FIGHTINGSTREETCDUSA", "Infinite Credits", "1f0582:09", 0},
            {"FIGHTINGSTREETCDUSA", "Infinite Time (disable at end of round)", "1f057b:09", 0},
            {"FIGHTINGSTREETCDUSA", "P1 Infinite Health", "1f0598:48+1f0599:48", 0},
            {"FINALBLASTER", "Infinite Lives", "1f135f:09", 0},
            {"FINALBLASTERJAPAN", "Infinite Credits", "1f007d:05", 0},
            {"FINALBLASTERJAPAN", "Infinite Lives", "1f0b5f:02", 0},
            {"FINALBLASTERJAPAN", "Invincibility", "1f0f27:00", 0},
            {"FINALLAPTWINUSA", "Infinite Time", "1f05b0:23+1f05b1:b3", 0},
            {"FINALSOLDIER", "Infinite Lives", "1f08fc:09", 0},
            {"FINALSOLDIERJAPAN", "Infinite Lives", "1f00fc:02", 0},
            {"FINALSOLDIERJAPAN", "Invincibility", "1f00dc:02", 0},
            {"FINALSOLDIERSPECIALVERSIONJAPAN", "Infinite Lives", "1f00fc:02", 0},
            {"FINALSOLDIERSPECIALVERSIONJAPAN", "Infinite Time", "1f00f9:89", 0},
            {"FINALSOLDIERSPECIALVERSIONJAPAN", "Invincibility", "1f00dc:02", 0},
            {"FINALZONEIICDJAPAN", "Infinite Ammo/Bomb Types", "1f0b5b:99", 0},
            {"FINALZONEIICDJAPAN", "Infinite Health", "1f0760:64", 0},
            {"FINALZONEIICDJAPAN", "Invincible", "1f075c:12", 0},
            {"FINALZONEIICDUSA", "Infinite Ammo/Bomb Types", "1f0b5b:99", 0},
            {"FINALZONEIICDUSA", "Infinite Health", "1f0760:64", 0},
            {"FINALZONEIICDUSA", "Invincible", "1f075c:12", 0},
            {"FIREPROWRESTLING22NDBOUTJAPAN", "Pro mode Enabled", "1f03d1:01", 0},
            {"FIREPROWRESTLINGCOMBINATIONTAGJAPAN", "Hard mode Enabled", "1f0401:01", 0},
            {"FLASHHIDERSSCDJAPAN", "Infinite Skill Points (Scenario)", "1f0f15:99", 0},
            {"FLASHHIDERSSCDJAPAN", "Infinite Time", "1f1015:15+1f1016:15", 0},
            {"FLASHHIDERSSCDJAPAN", "P1 Infinite Health", "1f107f:12+1f108f:10+1f1091:10", 0},
            {"FLASHHIDERSSCDJAPAN", "P2 1-Hit Kill (Life Mod)", "1f1080:00+1f1090:00+1f1092:00", 0},
            {"FLASHHIDERSSCDJAPAN", "Stats Max Defense (Scenario)", "1f0f19:99", 0},
            {"FLASHHIDERSSCDJAPAN", "Stats Max Offense (Scenario)", "1f0f17:99", 0},
            {"FLASHHIDERSSCDJAPAN", "Stats Max Speed (Scenario)", "1f0f1b:99", 0},
            {"FLASHHIDERSTAIKENBANSCDJAPAN", "Infinite Stat Points", "1f0f12:99", 0},
            {"FLASHHIDERSTAIKENBANSCDJAPAN", "Infinite Time", "1f1015:15+1f1016:15", 0},
            {"FLASHHIDERSTAIKENBANSCDJAPAN", "P1 Infinite Health", "1f107f:12+1f108b:10+1f108d:10", 0},
            {"FLASHHIDERSTAIKENBANSCDJAPAN", "P1 Stats Max Defense", "1f0f16:99", 0},
            {"FLASHHIDERSTAIKENBANSCDJAPAN", "P1 Stats Max Offense", "1f0f14:99", 0},
            {"FLASHHIDERSTAIKENBANSCDJAPAN", "P1 Stats Max Speed", "1f0f18:99", 0},
            {"FLASHHIDERSTAIKENBANSCDJAPAN", "P2 1-Hit Kill (Life Mod)", "1f1080:00+1f108c:00+1f108e:00", 0},
            {"FLASHHIDERSTAIKENBANSCDJAPAN", "P2 Stats No Defense", "1f0f17:00", 0},
            {"FLASHHIDERSTAIKENBANSCDJAPAN", "P2 Stats No Offense", "1f0f15:00", 0},
            {"FLASHHIDERSTAIKENBANSCDJAPAN", "P2 Stats No Speed", "1f0f19:00", 0},
            {"FORGOTTENWORLDSSCDJAPAN", "Max Zenny (Shop)", "1f0034:15+1f0035:15", 0},
            {"FORGOTTENWORLDSSCDJAPAN", "P1 Infinite Health", "1f0032:44", 0},
            {"FORGOTTENWORLDSSCDJAPAN", "P1 Infinite Lives", "1f0036:02", 0},
            {"FORGOTTENWORLDSSCDJAPAN", "P1 Invincible", "1f0d01:20", 0},
            {"FORGOTTENWORLDSSCDUSA", "Max Zenny (Shop)", "1f0034:15+1f0035:15", 0},
            {"FORGOTTENWORLDSSCDUSA", "P1 Infinite Health", "1f0032:44", 0},
            {"FORGOTTENWORLDSSCDUSA", "P1 Infinite Lives", "1f0036:02", 0},
            {"FORGOTTENWORLDSSCDUSA", "P1 Invincible", "1f0d01:28", 0},
            {"FRAYCDXAKGAIDENSCDJAPAN", "Autofire Charged Attack", "1f003a:05+1f003b:05", 0},
            {"FUSHIGINOYUMENOALICEJAPAN", "Infinite Energy", "1f0717:07", 0},
            {"FUSHIGINOYUMENOALICEJAPAN", "Infinite Lives", "1f071a:05", 0},
            {"FUSHIGINOYUMENOALICEJAPAN", "Instant Power Charges", "1f0719:03", 0},
            {"FUSHIGINOYUMENOALICEJAPAN", "Invincibility", "1f1e00:97+1f1e01:97", 0},
            {"GAINGROUNDSXSCDJAPAN", "Automatically Beat Stages", "1f1881:00+1f1b3c:00+1f1863:00", 0},
            {"GAINGROUNDSXSCDJAPAN", "Infinite Time", "1f1810:20", 0},
            {"GAINGROUNDSXSCDJAPAN", "Invincibility", "1f182f:02", 0},
            {"GALAGA88JAPAN", "Infinite Lives", "1f008a:03", 0},
            {"GALAGA88JAPAN", "Invincibility", "1f008b:03", 0},
            {"GALAGA88JAPAN", "Perfect Bonus Round", "1f00a5:40", 0},
            {"GALAGA90", "Infinite Lives", "1f08c4:09", 0},
            {"GALAGA90USA", "Infinite Lives", "1f008a:03", 0},
            {"GALAGA90USA", "Invincibility", "1f008b:03", 0},
            {"GALAGA90USA", "Perfect Bonus Round", "1f00a5:40", 0},
            {"GALAXYDEKAGAYVANSCDJAPAN", "Infinite Lives (Both Players)", "1f06a5:04+1f0a01:04", 0},
            {"GALAXYDEKAGAYVANSCDJAPAN", "Infinite Time", "1f0708:10", 0},
            {"GALAXYDEKAGAYVANSCDJAPAN", "P1 Infinite Health", "1f0800:80+1f0a08:80", 0},
            {"GALAXYDEKAGAYVANSCDJAPAN", "P2 Infinite Health", "1f0801:80+1f0a28:80", 0},
            {"GAROUDENSETSUIIARATANARUTATAKAIIMPERFECTACDJAPAN", "Infinite Time", "1f0f0c:90", 0},
            {"GAROUDENSETSUIIARATANARUTATAKAIIMPERFECTACDJAPAN", "P1 Infinite Health", "1f0f08:96", 0},
            {"GAROUDENSETSUIIARATANARUTATAKAIIMPERFECTACDJAPAN", "P2 No Health", "1f0f09:00", 0},
            {"GAROUDENSETSUIIARATANARUTATAKAIIMPERFECTACDJAPAN", "Start on Next to Final Stage", "1f0edd:14", 0},
            {"GAROUDENSETSUIIARATANARUTATAKAISAMPLEDISCACDJAPAN", "Infinite Time", "1f0f84:90", 0},
            {"GAROUDENSETSUIIARATANARUTATAKAISAMPLEDISCACDJAPAN", "Infinite Timer", "1f0f85:34", 0},
            {"GAROUDENSETSUIIARATANARUTATAKAISAMPLEDISCACDJAPAN", "P1 Infinite Health", "1f0f4b:96", 0},
            {"GAROUDENSETSUIIARATANARUTATAKAISAMPLEDISCACDJAPAN", "P2 No Health", "1f0f4c:01", 0},
            {"GAROUDENSETSUSPECIALACDJAPAN", "Freeze Timer", "1f1303:09", 0},
            {"GAROUDENSETSUSPECIALACDJAPAN", "Infinite Time", "1f1302:96", 0},
            {"GAROUDENSETSUSPECIALACDJAPAN", "P1 Infinite Health", "1f1b45:96", 0},
            {"GAROUDENSETSUSPECIALACDJAPAN", "P2 No Health", "1f1b46:00", 0},
            {"GAROUDENSETSUSPECIALACDJAPAN", "Play as Ryo Sakazaki", "1f1e51:15", 0},
            {"GATEOFTHUNDERSCDJAPAN", "Have E Red Shot", "1f0687:01", 0},
            {"GATEOFTHUNDERSCDJAPAN", "Have S Green Shot", "1f0686:01", 0},
            {"GATEOFTHUNDERSCDJAPAN", "Infinite Lives", "1f0681:04", 0},
            {"GEKISHABOYJAPAN", "Infinite Pictures", "1f0062:10", 0},
            {"GENJITSUUSHINAGEDAMAJAPAN", "Invincibility", "1f0500:02+1f0d01:00", 0},
            {"GENOCIDESCDJAPAN", "Infinite Energy", "1f0680:25", 0},
            {"GENPEITOUMADENJAPAN", "Invincibility", "1f00b4:02", 0},
            {"GENPEITOUMADENKANNONIJAPAN", "Infinite Energy", "1f15c8:49", 0},
            {"GHOSTMANORUSA", "Infinite Ammo", "1f1924:14", 0},
            {"GHOSTMANORUSA", "Infinite Energy", "1f1940:18", 0},
            {"GHOSTMANORUSA", "Infinite Lives", "1f1941:03", 0},
            {"GHOSTMANORUSA", "Invincibility", "1f1934:ff", 0},
            {"GINGAFUKEIDENSETSUSAPPHIREACDJAPAN", "Infinite Credits", "1f06bd:09", 0},
            {"GODPANICSHIJOUSAIKYOUGUNDANSCDJAPAN", "Infinite Bombs", "1f0050:03", 0},
            {"GODPANICSHIJOUSAIKYOUGUNDANSCDJAPAN", "Infinite Health", "1f004f:03", 0},
            {"GODPANICSHIJOUSAIKYOUGUNDANSCDJAPAN", "Infinite Lives", "1f004a:09", 0},
            {"GODPANICSHIJOUSAIKYOUGUNDANSCDJAPAN", "Invincibility (Activate in game, NOT at title screen", "1f0c56:20", 0},
            {"GODZILLABAKUTOURETSUDENSCDJAPAN", "P1 Infinite Energy", "1f06cd:24", 0},
            {"GODZILLASCDUSA", "P1 Infinite Energy", "1f06cd:24", 0},
            {"GOKURAKUCHUUKATAISENJAPAN", "Increased Speed", "1f0e03:04", 0},
            {"GOKURAKUCHUUKATAISENJAPAN", "Infinite Credits", "1f0e0d:09", 0},
            {"GOKURAKUCHUUKATAISENJAPAN", "Infinite Lives", "1f0e0c:09", 0},
            {"GOKURAKUCHUUKATAISENJAPAN", "Invincibility", "1f0210:01", 0},
            {"GOLDENAXECDJAPAN", "Infinite Energy", "1f002b:15", 0},
            {"GOLDENAXECDJAPAN", "Infinite Lives", "1f0302:03", 0},
            {"GOLDENAXECDJAPAN", "invincibility", "1f11ad:08", 0},
            {"GOLDENAXECDJAPAN", "Magic Points Modifier", "1f002f:00", 0},
            {"GOMOLASPEEDJAPAN", "Have 2 Keys (Upon Pick-up)", "1f0217:02", 0},
            {"GOMOLASPEEDJAPAN", "Have All Food Collected", "1f11b6:00", 0},
            {"GOMOLASPEEDJAPAN", "Infinite Credits", "1f0219:09", 0},
            {"GOMOLASPEEDJAPAN", "Infinite Lives", "1f0216:03", 0},
            {"GOTZENDIENERSCDJAPAN", "Infinite Energy", "1f1831:08", 0},
            {"GRADIUS", "Infinite Lives", "1f0885:09", 0},
            {"GRADIUSIIGOFERNOYABOUSCDJAPAN", "Always Have Force Shield", "1f0eeb:04+1f00bf:02+1f0665:10", 0},
            {"GRADIUSIIGOFERNOYABOUSCDJAPAN", "Have 4 Options", "1f00bc:04", 0},
            {"GRADIUSIIGOFERNOYABOUSCDJAPAN", "Have Shield Type", "1f00c1:06", 0},
            {"GRADIUSIIGOFERNOYABOUSCDJAPAN", "Infinite Lives", "1f1ed0:02", 0},
            {"GRADIUSIIGOFERNOYABOUSCDJAPAN", "Max Speed Upgrade", "1f00c0:06", 0},
            {"GRADIUSJAPAN", "Have Power-Up Laser", "1f10b0:04", 0},
            {"GRADIUSJAPAN", "Have Power-Up Missile", "1f1124:02", 0},
            {"GRADIUSJAPAN", "Have Power-Up Speed", "1f120c:02", 0},
            {"GRADIUSJAPAN", "Infinite Lives", "1f0085:02", 0},
            {"GUNHEDHUNDSONGUNHEDTAIKAIBLAZINGLAZERS", "Infinite Lives", "1f0b7d:63", 0},
            {"GUNHEDHUNDSONGUNHEDTAIKAIBLAZINGLAZERS", "Infinite Smart Bombs", "1f0b81:63", 0},
            {"GUNHEDJAPAN", "Infinite Bombs", "1f0381:09", 0},
            {"GUNHEDJAPAN", "Infinite Lives", "1f037d:09", 0},
            {"GUNHEDJAPAN", "Invincibility", "1f0310:02", 0},
            {"GUNHEDSPECIALEDITIONJAPAN", "Infinite Bombs", "1f0381:03", 0},
            {"GUNHEDSPECIALEDITIONJAPAN", "Infinite Lives", "1f037d:02", 0},
            {"GUNHEDSPECIALEDITIONJAPAN", "Invincibility", "1f0310:02", 0},
            {"HANATAAKADAKAJAPAN", "Infinite Energy", "1f0705:01", 0},
            {"HANATAAKADAKAJAPAN", "Infinite Lives", "1f042d:03", 0},
            {"HANATAAKADAKAJAPAN", "Invincibility", "1f0cf5:40", 0},
            {"HANIIINTHESKYJAPAN", "Infinite Energy", "1f067b:27", 0},
            {"HANIIONTHEROADJAPAN", "Infinite Lives", "1f1e08:04", 0},
            {"HANIIONTHEROADJAPAN", "Infinite Time", "1f1e10:59", 0},
            {"HAWKF123SCDJAPAN", "Infinite Energy Field PowerUp", "1f1eef:09", 0},
            {"HAWKF123SCDJAPAN", "Infinite Force Field PowerUp", "1f1eec:09", 0},
            {"HAWKF123SCDJAPAN", "Infinite Lives", "1f1ec7:03", 0},
            {"HAWKF123SCDJAPAN", "Infinite Missile PowerUp", "1f1eed:09", 0},
            {"HAWKF123SCDJAPAN", "Infinite Multi-Bomb PowerUp", "1f1eee:09", 0},
            {"HAWKF123SCDJAPAN", "Invincibility", "1f18e4:05", 0},
            {"HEAVYUNIT", "Infinite Lives", "1f0808:09", 0},
            {"HEAVYUNITJAPAN", "Infinite Lives", "1f0008:03", 0},
            {"HEAVYUNITJAPAN", "Invincibility", "1f0212:00", 0},
            {"HELLFIRESTHEANOTHERSTORYCDJAPAN", "Infinite Lives", "1f04a5:04", 0},
            {"HELLFIRESTHEANOTHERSTORYCDJAPAN", "Invincibility", "1f0f69:06", 0},
            {"HITTHEICEVHLTHEOFFICIALVIDEOHOCKEYLEAGUEJAPAN", "CPU Never Scores", "1f0bef:00", 0},
            {"HITTHEICEVHLTHEOFFICIALVIDEOHOCKEYLEAGUEUSA", "CPU Never Scores", "1f0bef:00", 0},
            {"HYPERDYNESIDEARMSSPECIALCDJAPAN", "Auto Fire Full Laser (Before Christ Mode)", "1f0056:64", 0},
            {"HYPERDYNESIDEARMSSPECIALCDJAPAN", "Infinite Lives (Before Christ Mode)", "1f004d:02", 0},
            {"HYPERDYNESIDEARMSSPECIALCDJAPAN", "Infinite Lives (Standard Mode)", "1f005c:05", 0},
            {"HYPERDYNESIDEARMSSPECIALCDJAPAN", "Invincibility (Before Christ Mode)", "1f00af:02", 0},
            {"HYPERDYNESIDEARMSSPECIALCDJAPAN", "Invincibility (Standard Mode)", "1f00aa:02", 0},
            {"IDOLHANAFUDAFANCLUBJAPAN", "Infinite Magic Power", "1f1239:09+1f123a:09+1f123b:09", 0},
            {"IDOLHANAFUDAFANCLUBJAPAN", "Infinite Time (In-Game Turn)", "1f0012:05", 0},
            {"IDOLHANAFUDAFANCLUBJAPAN", "Infinite Time (Menu)", "1f1236:0f", 0},
            {"IMAGEFIGHTJAPAN", "Infinite Lives", "1f14a2:03", 0},
            {"IMPOSSAMOLE", "Infinite Lives", "1f0822:63", 0},
            {"IMPOSSAMOLEUSA", "Infinite Energy", "1f0050:0b", 0},
            {"IMPOSSAMOLEUSA", "Infinite Lives", "1f0022:03", 0},
            {"IMPOSSAMOLEUSA", "Invincibility", "1f006e:03", 0},
            {"JACKIECHANJAPAN", "Infinite Continues", "1f0100:09", 0},
            {"JACKIECHANJAPAN", "Infinite Health", "1f00d2:3f", 0},
            {"JACKIECHANJAPAN", "Infinite Special", "1f00d3:05", 0},
            {"JACKIECHANJAPAN", "Invincibility", "1f0071:ff", 0},
            {"JACKIECHANSACTIONKUNGFUUSA", "Infinite Continues", "1f0100:09", 0},
            {"JACKIECHANSACTIONKUNGFUUSA", "Infinite Energy", "1f00d2:3f", 0},
            {"JACKIECHANSACTIONKUNGFUUSA", "Infinite Special", "1f00d3:05", 0},
            {"JACKIECHANSACTIONKUNGFUUSA", "Invincibility", "1f0071:ff", 0},
            {"JACKNICKLAUSCHAMPIONSHIPGOLFJAPAN", "Always Hole-In-One", "1f07b1:00+1f07f9:00", 0},
            {"JACKNICKLAUSTURBOGOLFCDUSA", "Always a Hole-In-One", "1f0d28:00+1f0d70:00", 0},
            {"JACKNICKLAUSTURBOGOLFUSA", "Always Hole-In-One", "1f07b1:00+1f07f9:00", 0},
            {"JASEIKENNECROMANCERJAPAN", "Infinite Gold", "1f0400:ff+1f0401:ff", 0},
            {"JASEIKENNECROMANCERJAPAN", "Stats Max AC", "1f0418:ff+1f0419:ff", 0},
            {"JASEIKENNECROMANCERJAPAN", "Stats Max AGL", "1f0412:ff+1f0413:ff", 0},
            {"JASEIKENNECROMANCERJAPAN", "Stats Max AP", "1f0416:ff+1f0417:ff", 0},
            {"JASEIKENNECROMANCERJAPAN", "Stats Max HP", "1f0408:ff+1f0409:ff", 0},
            {"JASEIKENNECROMANCERJAPAN", "Stats Max INT", "1f0414:ff+1f0415:ff", 0},
            {"JASEIKENNECROMANCERJAPAN", "Stats Max MHP", "1f040c:ff+1f040d:ff", 0},
            {"JASEIKENNECROMANCERJAPAN", "Stats Max MMP", "1f040e:ff+1f040f:ff", 0},
            {"JASEIKENNECROMANCERJAPAN", "Stats Max MP", "1f040a:ff+1f040b:ff", 0},
            {"JASEIKENNECROMANCERJAPAN", "Stats Max STR", "1f0410:ff+1f0411:ff", 0},
            {"JIGOKUMEGURIJAPAN", "Infinite Credits", "1f1b67:09", 0},
            {"JIGOKUMEGURIJAPAN", "Infinite Lives", "1f1159:02", 0},
            {"JIGOKUMEGURIJAPAN", "Invincibility", "1f1138:01", 0},
            {"JIMPOWERINMUTANTPLANETSCDJAPAN", "Infinite Bombs", "1f0d33:76", 0},
            {"JIMPOWERINMUTANTPLANETSCDJAPAN", "Infinite Keys", "1f0d31:76", 0},
            {"JIMPOWERINMUTANTPLANETSCDJAPAN", "Infinite Lives", "1f0d2f:76", 0},
            {"JIMPOWERINMUTANTPLANETSCDJAPAN", "Infinite Time", "1f0d34:74", 0},
            {"JIMPOWERINMUTANTPLANETSCDJAPAN", "Invincibility", "1f0d3f:06", 0},
            {"JINMUDENSHOUJAPAN", "Infinite Energy", "1f001d:32", 0},
            {"JINMUDENSHOUJAPAN", "Invincibility", "1f008c:55", 0},
            {"JJJEFFUSA", "Infinite Energy", "1f0a68:0a", 0},
            {"JJJEFFUSA", "Infinite Lives", "1f0a66:02", 0},
            {"JJJEFFUSA", "Invincibility", "1f0b1d:14", 0},
            {"JLEAGUEGREATESTELEVENJAPAN", "CPU/P2 Never Scores", "1f0f56:00", 0},
            {"JLEAGUEGREATESTELEVENJAPAN", "Infinite Time", "1f1016:05", 0},
            {"JUUOUKIJAPAN", "Infinite Energy", "1f0800:12", 0},
            {"JUUOUKIJAPAN", "Infinite Lives", "1f0900:03", 0},
            {"JUUOUKIJAPAN", "Invincibility (Disable after finishing stage)", "1f0a05:03", 0},
            {"JUUOUKIJAPAN", "One Orb for Beast Mode (deactivate before collecting", "1f0804:02", 0},
            {"KAIZOUCHOUJINSHUBIBINMAN2ARATANARUTEKIJAPAN", "1-Hit Boss Kill", "1f0e0d:00", 0},
            {"KAIZOUCHOUJINSHUBIBINMAN2ARATANARUTEKIJAPAN", "Infinite Energy", "1f0e0c:18", 0},
            {"KAIZOUCHOUJINSHUBIBINMAN2ARATANARUTEKIJAPAN", "Invincibility", "1f15c8:03", 0},
            {"KAIZOUCHOUJINSHUBIBINMANIIIIKAINOPRINCESSCDJAPAN", "Infinite Energy", "1f0747:05", 0},
            {"KAIZOUCHOUJINSHUBIBINMANIIIIKAINOPRINCESSCDJAPAN", "P1 Invincibility", "1f08a9:76", 0},
            {"KAIZOUCHOUJINSHUBIBINMANIIIIKAINOPRINCESSCDJAPAN", "P2 Invincibility", "1f08aa:76", 0},
            {"KAIZOUCHOUJINSHUBIBINMANJAPAN", "Infinite Energy", "1f0c40:00", 0},
            {"KAIZOUCHOUJINSHUBIBINMANJAPAN", "Infinite Gold", "1f1725:09+1f1726:09+1f1727:09", 0},
            {"KAKUTOUHAOUDENSETSUALGUNOSSCDJAPAN", "Enemy is Paralyzed", "1f18b0:03", 0},
            {"KAKUTOUHAOUDENSETSUALGUNOSSCDJAPAN", "P1 Infinite Energy", "1f1690:00", 0},
            {"KAKUTOUHAOUDENSETSUALGUNOSSCDJAPAN", "P2 No Energy", "1f1890:00", 0},
            {"KATOCHENKENCHANJAPAN", "Infinite Energy", "1f0a68:10", 0},
            {"KATOCHENKENCHANJAPAN", "Infinite Lives", "1f0a66:02", 0},
            {"KATOCHENKENCHANJAPAN", "No Enemy Push-back", "1f0b1d:02", 0},
            {"KATTOBITAKUHAIKUNJAPAN", "Infinite Time", "1f0707:99", 0},
            {"KATTOBITAKUHAIKUNJAPAN", "Max Damage", "1f0e24:64", 0},
            {"KATTOBITAKUHAIKUNJAPAN", "Max Power", "1f0057:fb", 0},
            {"KAZEKIRININJAACTIONSCDJAPAN", "Bosses Have No Energy", "1f0870:05", 0},
            {"KAZEKIRININJAACTIONSCDJAPAN", "Infinite Energy", "1f040a:07", 0},
            {"KAZEKIRININJAACTIONSCDJAPAN", "Less Enemies To Kill", "1f00b6:01", 0},
            {"KAZENODENSETSUXANADUIISCDJAPAN", "Infinite Energy Capsules", "1f0ae3:02", 0},
            {"KAZENODENSETSUXANADUIISCDJAPAN", "Infinite Potions", "1f0ae4:02", 0},
            {"KAZENODENSETSUXANADUSCDJAPAN", "Infinite Potions", "1f0ad2:02", 0},
            {"KEITHCOURAGEINALPHAZONESUSA", "Infinite Bolt Bombs", "1f00cb:63", 0},
            {"KEITHCOURAGEINALPHAZONESUSA", "Infinite Energy", "1f00c8:5f", 0},
            {"KEITHCOURAGEINALPHAZONESUSA", "Invincibility", "1f0048:02", 0},
            {"KEITHCOURAGEINALPHAZONESUSA", "Max Money", "1f00cd:27+1f00ce:63", 0},
            {"KIAIDAN00SCDJAPAN", "Infinite Energy", "1f0f56:96", 0},
            {"KICKBALLJAPAN", "CPU/P2 Never Scores", "1f0dce:00", 0},
            {"KICKBALLJAPAN", "P1 Scores x99", "1f0dcd:63", 0},
            {"KIKIKAIKAIJAPAN", "Infinite Credits", "1f1f07:09", 0},
            {"KIKIKAIKAIJAPAN", "Infinite Lives", "1f1f08:08", 0},
            {"KINGOFCASINO", "Infinite Money", "1f1280:63", 0},
            {"KLAXUSA", "Infinite Credits", "1f006b:09", 0},
            {"KLAXUSA", "Need No Klax to Finish (catch a piece to finish wave", "1f0048:00", 0},
            {"KNIGHTRIDERSPECIALJAPAN", "Infinite Energy", "1f0088:16", 0},
            {"KNIGHTRIDERSPECIALJAPAN", "Infinite Time", "1f0086:89", 0},
            {"KUNGFUTHEJAPAN", "Infinite Energy", "1f0bc3:10", 0},
            {"KUNGFUTHEJAPAN", "Infinite Lives", "1f0b34:03", 0},
            {"KYUUKYOKUTIGERJAPAN", "Infinite Bombs", "1f1671:09", 0},
            {"KYUUKYOKUTIGERJAPAN", "Infinite Credits", "1f1684:08", 0},
            {"KYUUKYOKUTIGERJAPAN", "Infinite Lives", "1f167b:04", 0},
            {"LADYSWORDRYAKUDATSUSARETA10NINNOOTOMEJAPANUNL", "Infinite Hit Points", "1f17d7:ff+1f17d8:ff", 0},
            {"LADYSWORDRYAKUDATSUSARETA10NINNOOTOMEJAPANUNL", "Stats Max Agility", "1f17dd:ff+1f17de:ff", 0},
            {"LADYSWORDRYAKUDATSUSARETA10NINNOOTOMEJAPANUNL", "Stats Max Attack", "1f17d9:ff+1f17da:ff", 0},
            {"LADYSWORDRYAKUDATSUSARETA10NINNOOTOMEJAPANUNL", "Stats Max Defense", "1f17db:ff+1f17dc:ff", 0},
            {"LADYSWORDRYAKUDATSUSARETA10NINNOOTOMEJAPANUNL", "Stats Max Hit Points", "1f17d5:ff+1f17d6:ff", 0},
            {"LASTALERTCDUSA", "Infinite Flame Thrower", "1f0413:09", 0},
            {"LASTALERTCDUSA", "Infinite Grenades", "1f0411:09", 0},
            {"LASTALERTCDUSA", "Infinite Homing Missiles", "1f0414:09", 0},
            {"LASTALERTCDUSA", "Infinite Sentry Orbs", "1f0415:09", 0},
            {"LASTALERTCDUSA", "Infinite Spikes", "1f0412:09", 0},
            {"LASTALERTCDUSA", "Infinite Time", "1f040c:09", 0},
            {"LASTALERTCDUSA", "Invincibility", "1f0400:03", 0},
            {"LASTALERTCDUSA", "Max Time", "1f040c:09+1f040d:99", 0},
            {"LASTALERTCDUSA", "Max Vitality", "1f040a:13", 0},
            {"LDISCDJAPAN", "Infinite Lives", "1f1a11:03", 0},
            {"LDISCDJPN", "Infinite Lives", "1f0a11:03", 0},
            {"LEGENDARYAXEIITHE", "Infinite Energy", "1f190e:09", 0},
            {"LEGENDARYAXEIIUSA", "Infinite Credits", "1f1d59:09", 0},
            {"LEGENDARYAXEIIUSA", "Infinite Energy", "1f110e:05", 0},
            {"LEGENDARYAXEIIUSA", "Infinite Lives", "1f110d:02", 0},
            {"LEGENDARYAXEIIUSA", "Infinite Smart Bombs", "1f1112:09", 0},
            {"LEGENDARYAXEIIUSA", "Infinite Time", "1f110c:59", 0},
            {"LEGENDARYAXEIIUSA", "Invincibility", "1f0098:14", 0},
            {"LEGENDARYAXETHEUSA", "Have Max Power Supply Upgrades", "1f0497:04", 0},
            {"LEGENDARYAXETHEUSA", "Have Max Wing Upgrades", "1f048f:02", 0},
            {"LEGENDARYAXETHEUSA", "Infinite Credits", "1f11f4:09", 0},
            {"LEGENDARYAXETHEUSA", "Infinite Energy", "1f0093:10", 0},
            {"LEGENDARYAXETHEUSA", "Infinite Lives", "1f0009:03", 0},
            {"LEGENDARYAXETHEUSA", "Invincibility", "1f00ac:14", 0},
            {"LEGENDOFHEROTONMA", "Infinite Lives", "1f1c9c:09", 0},
            {"LEGENDOFHEROTONMAUSA", "1-Hit Kill Stage 1 Boss", "1f05d2:01", 0},
            {"LEGENDOFHEROTONMAUSA", "1-Hit Kill Stage 2 Boss", "1f05c9:01", 0},
            {"LEGENDOFHEROTONMAUSA", "1-Hit Kill Stage 3 Boss", "1f05e6:01", 0},
            {"LEGENDOFHEROTONMAUSA", "1-Hit Kill Stage 4 Boss (Left)", "1f05d8:01", 0},
            {"LEGENDOFHEROTONMAUSA", "1-Hit Kill Stage 4 Boss (Right)", "1f05da:01", 0},
            {"LEGENDOFHEROTONMAUSA", "1-Hit Kill Stage 5 Boss", "1f05f6:01", 0},
            {"LEGENDOFHEROTONMAUSA", "Infinite Lives", "1f149c:0a", 0},
            {"LEGENDOFHEROTONMAUSA", "Invincibility", "1f0574:40", 0},
            {"LEGENDOFHEROTONMAUSA", "Max Weapon Upgrade", "1f1315:02", 0},
            {"LEGENDOFVALKYRIEVALKYRIENODENSETSU", "Infinite Energy", "1f08bf:08", 0},
            {"LEGENDOFVALKYRIEVALKYRIENODENSETSU", "Infinite Gold", "1f08c5:63", 0},
            {"LEGIONCDJAPAN", "Infinite Lives", "1f0531:04", 0},
            {"LEGIONCDJAPAN", "Infinite Shield", "1f0522:10", 0},
            {"LODERUNNERLOSTLABYRINTHJAPAN", "Exit Ladder Automatically Appears", "1f09af:00", 0},
            {"LODERUNNERLOSTLABYRINTHJAPAN", "Infinite Lives", "1f07bd:05", 0},
            {"LORDSOFTHUNDERSCDUSA", "\"Max Gold (Deactivate/reactivate if a shop says not ", "1f00b5:ff+1f00b6:ff", 0},
            {"LORDSOFTHUNDERSCDUSA", "Have Elixir", "1f0684:01", 0},
            {"LORDSOFTHUNDERSCDUSA", "Max Life", "1f0685:0e", 0},
            {"LORDSOFTHUNDERSCDUSA", "Max Power", "1f0687:0e", 0},
            {"LORDSOFTHUNDERSCDUSA", "Max Shield", "1f0688:03", 0},
            {"LORDSOFTHUNDERSCDUSA", "Max Time Slip (don't go above 9)", "1f0683:09", 0},
            {"MADOUOUGRANZORTJAPAN", "Infinite Lives", "1f027a:02", 0},
            {"MADOUOUGRANZORTJAPAN", "Infinite Time", "1f0275:59", 0},
            {"MADOUOUGRANZORTJAPAN", "Invincibility", "1f0381:00+1f0382:04+1f0390:02", 0},
            {"MAERCHENMAZEJAPAN", "1-Hit Boss Kill", "1f0b69:00", 0},
            {"MAERCHENMAZEJAPAN", "Infinite Lives", "1f0625:02", 0},
            {"MAERCHENMAZEJAPAN", "Invincibility", "1f0769:01+1f0815:02", 0},
            {"MAGICALCHASEJAPAN", "Infinite Health", "1f0e40:10+1f0f40:10", 0},
            {"MAGICALCHASEJAPAN", "Infinite Money", "1f1f3a:ff+1f1f3b:ff", 0},
            {"MAGICALCHASEJAPAN", "Invincibility", "1f0ec5:23", 0},
            {"MAGICALCHASEJAPAN", "Max Hearts", "1f000f:0c", 0},
            {"MAGICALCHASEUSA", "Infinite Health", "1f0e40:10+1f0f40:10", 0},
            {"MAGICALCHASEUSA", "Infinite Money", "1f1f3a:ff+1f1f3b:ff", 0},
            {"MAGICALCHASEUSA", "Invincibility", "1f0ec5:23", 0},
            {"MAGICALCHASEUSA", "Max Hearts", "1f000f:0c", 0},
            {"MAGICALFANTASYADVENTUREPOPFULMAILACDSCDJAPAN", "Mail Infinite HP", "1f0d16:98", 0},
            {"MAGICALFANTASYADVENTUREPOPFULMAILACDSCDJAPAN", "Max Apple", "1f1531:09", 0},
            {"MAGICALFANTASYADVENTUREPOPFULMAILACDSCDJAPAN", "Max Cherry", "1f1530:09", 0},
            {"MAGICALFANTASYADVENTUREPOPFULMAILACDSCDJAPAN", "Max Life Potion", "1f1533:09", 0},
            {"MAGICALFANTASYADVENTUREPOPFULMAILACDSCDJAPAN", "Max Money", "1f1503:09+1f1504:09+1f1505:09+1f1506:09+1f1507:09", 0},
            {"MAGICALFANTASYADVENTUREPOPFULMAILACDSCDJAPAN", "Max Orange", "1f152f:09", 0},
            {"MAKAIPRINCEDORABOCCHANJAPAN", "1-Hit Boss Kill", "1f0425:01", 0},
            {"MAKAIPRINCEDORABOCCHANJAPAN", "Have Double Jump", "1f0864:01", 0},
            {"MAKAIPRINCEDORABOCCHANJAPAN", "Have Upgraded Gun", "1f0870:01", 0},
            {"MAKAIPRINCEDORABOCCHANJAPAN", "Infinite Energy", "1f1841:06", 0},
            {"MAKAIPRINCEDORABOCCHANJAPAN", "Infinite Lives", "1f083f:02", 0},
            {"MAKAIPRINCEDORABOCCHANJAPAN", "Infinite Suit Health (Upon Pickup)", "1f0833:03", 0},
            {"MAKAIPRINCEDORABOCCHANJAPAN", "Max Tomatoes", "1f0838:09+1f0839:09", 0},
            {"MANIACPROWRESASUENOTATAKAIJAPAN", "CPU No Health", "1f1453:00", 0},
            {"MANIACPROWRESASUENOTATAKAIJAPAN", "Infinite Energy", "1f1332:46", 0},
            {"MANIACPROWRESASUENOTATAKAIJAPAN", "Max Training Points", "1f160e:ff+1f160f:ff", 0},
            {"MANIACPROWRESASUENOTATAKAIJAPAN", "Stats Max Arm", "1f1323:ff+1f1324:ff", 0},
            {"MANIACPROWRESASUENOTATAKAIJAPAN", "Stats Max Body", "1f1327:ff+1f1328:ff", 0},
            {"MANIACPROWRESASUENOTATAKAIJAPAN", "Stats Max Leg", "1f1325:ff+1f1326:ff", 0},
            {"MANIACPROWRESASUENOTATAKAIJAPAN", "Stats Max Speed", "1f1329:ff+1f132a:ff", 0},
            {"MARTIALCHAMPIONSCDJAPAN", "P1 Infinite Energy", "1f1ea0:36", 0},
            {"MARTIALCHAMPIONSCDJAPAN", "P1 No Energy", "1f1ea0:00", 0},
            {"MARTIALCHAMPIONSCDJAPAN", "P2 Infinite Energy", "1f1ea1:36", 0},
            {"MARTIALCHAMPIONSCDJAPAN", "P2 No Energy", "1f1ea1:00", 0},
            {"MESOPOTAMIAJAPAN", "Infinite Energy", "1f1111:03", 0},
            {"MESOPOTAMIAJAPAN", "Infinite Lives", "1f1300:04", 0},
            {"MESOPOTAMIAJAPAN", "Infinite Time", "1f1114:09", 0},
            {"METALSTOKER", "Infinite Energy", "1f0e12:04", 0},
            {"METALSTOKERJAPAN", "Infinite Energy", "1f0612:04", 0},
            {"METALSTOKERJAPAN", "Infinite Lives", "1f0614:02", 0},
            {"METEORBLASTERDXSCDUSA", "Infinite Ships", "1f15c1:10", 0},
            {"METEORBLASTERDXSCDUSA", "Invincible", "1f09d2:18", 0},
            {"MIZUBAKUDAIBOUKENJAPAN", "Infinite Energy", "1f0611:03", 0},
            {"MIZUBAKUDAIBOUKENJAPAN", "Invincibility", "1f0676:36", 0},
            {"MOMOTAROUDENSETSUTURBOJAPAN", "Infinite Money", "1f1714:ff+1f1715:ff", 0},
            {"MOMOTAROUKATSUGEKIJAPAN", "Infinite Lives", "1f1bb8:02", 0},
            {"MOMOTAROUKATSUGEKIJAPAN", "Infinite Money", "1f1b42:ff+1f1b43:ff", 0},
            {"MOMOTAROUKATSUGEKIJAPAN", "Infinite Time", "1f1c49:20", 0},
            {"MOMOTAROUKATSUGEKIJAPAN", "Invincibility", "1f199a:01", 0},
            {"MONSTERLAIRCDUSA", "P1 Infinite Lives", "1f0483:10", 0},
            {"MONSTERLAIRCDUSA", "P1 Invincible", "1f0bbf:10", 0},
            {"MONSTERLAIRCDUSA", "P1 Max Inf Vitality Time", "1f0480:60", 0},
            {"MONSTERLAIRCDUSA", "P2 Infinite Lives", "1f049c:10", 0},
            {"MONSTERLAIRCDUSA", "P2 Invincible", "1f0bc0:10", 0},
            {"MONSTERLAIRCDUSA", "P2 Max Inf Vitality Time", "1f0499:60", 0},
            {"MONSTERLAIRWONDERBOYIIICDJAPAN", "P1 Infinite Lives", "1f0483:10", 0},
            {"MONSTERLAIRWONDERBOYIIICDJAPAN", "P1 Invincible", "1f0bbf:97", 0},
            {"MONSTERLAIRWONDERBOYIIICDJAPAN", "P1 Max Inf Vitality Time", "1f0477:29", 0},
            {"MONSTERPROWRESJAPAN", "CPU/P2 No Energy", "1f0ccd:00", 0},
            {"MONSTERPROWRESJAPAN", "CPU/P2 No Stats", "1f0ccc:00+1f0cce:00+1f0ccf:00+1f0c37:00", 0},
            {"MONSTERPROWRESJAPAN", "Infinite Energy", "1f0cbd:55", 0},
            {"MONSTERPROWRESJAPAN", "Infinite Stat Points", "1f0085:32", 0},
            {"MONSTERPROWRESJAPAN", "P1 Max ST", "1f0cbc:c8", 0},
            {"MOTOROADERIIJAPAN", "Infinite Energy", "1f06f9:63", 0},
            {"MOTOROADERIIJAPAN", "Infinite Money", "1f07ba:99", 0},
            {"MOTOROADERIIJAPAN", "Kill All CPUs (2-5)", "1f06fa:99+1f06fb:99+1f06fc:99+1f06fd:99", 0},
            {"MOTOROADERUSA", "Infinite Energy", "1f0b74:28", 0},
            {"MOTOROADERUSA", "Infinite Money (Activates on Purchase)", "1f0ace:09+1f0acf:09+1f0ad0:09+1f0ad1:09", 0},
            {"MRHELINODAIBOUKENJAPAN", "Infinite Energy", "1f1004:0a", 0},
            {"MRHELINODAIBOUKENJAPAN", "Infinite Lives", "1f1003:03", 0},
            {"MRHELINODAIBOUKENJAPAN", "Infinite Time", "1f04f4:43", 0},
            {"MRHELINODAIBOUKENJAPAN", "Instantly Beat Current Stage", "1f1005:06", 0},
            {"MUGENSENSHIVALISLEGENDOFAFANTASMSOLDIERSCDJAPAN", "Infinite Energy", "1f0305:04", 0},
            {"MUGENSENSHIVALISLEGENDOFAFANTASMSOLDIERSCDJAPAN", "Infinite Lives", "1f0302:03", 0},
            {"MUGENSENSHIVALISLEGENDOFAFANTASMSOLDIERSCDJAPAN", "Infinite MP", "1f0306:08", 0},
            {"MUGENSENSHIVALISLEGENDOFAFANTASMSOLDIERSCDJAPAN", "Infinite Time", "1f001a:54", 0},
            {"MUGENSENSHIVALISLEGENDOFAFANTASMSOLDIERSCDJAPAN", "Invincibility", "1f0014:02", 0},
            {"MUGENSENSHIVALISLEGENDOFAFANTASMSOLDIERSCDJAPAN", "Sword Powered Up", "1f0303:03", 0},
            {"MUGENSENSHIVALISLEGENDOFAFANTASMSOLDIERSCDJPN", "Infinite Energy", "1f0305:04", 0},
            {"MYSTICFORMULASCDJAPAN", "Infinite Lives", "1f1256:03+1f124a:03+1f127a:03+1f1273:03+1f1272:03+1f1246:03+1f1274:03", 0},
            {"MYSTICFORMULASCDJAPAN", "Infinite Magic", "1f1296:02+1f128a:02+1f12ba:02+1f12b3:02+1f12b2:02+1f1286:02+1f12b4:02", 0},
            {"MYSTICFORMULASCDJAPAN", "Invincibility", "1f12d6:06+1f12ca:06+1f12fa:06+1f12f3:06+1f12f2:06+1f12c6:06+1f12f4:06", 0},
            {"MYSTICFORMULASCDJAPAN", "Rapid Fire", "1f1156:03+1f114a:03+1f117a:03+1f1173:03+1f1172:03+1f1146:03+1f1174:03", 0},
            {"NAXATOPENJAPAN", "Always Hole-In-One", "1f054f:01", 0},
            {"NAXATSTADIUMJAPAN", "P1 Score x99", "1f16f2:63", 0},
            {"NECROSNOYOUSAIJAPAN", "Infinite Gold", "1f0314:ff+1f0315:ff", 0},
            {"NECROSNOYOUSAIJAPAN", "Stats Current HP", "1f028c:ff", 0},
            {"NECROSNOYOUSAIJAPAN", "Stats Max HP", "1f0292:ff", 0},
            {"NECROSNOYOUSAIJAPAN", "Stats MP", "1f02f0:ff", 0},
            {"NEKKETSUKOUKOUDODGEBALLBUPCBANGAIHENJAPAN", "Enemy Has Zero Energy", "1f06e2:00+1f0634:00+1f06e6:00+1f06e8:00", 0},
            {"NEKKETSUKOUKOUDODGEBALLBUPCSOCCERHENJAPAN", "CPU Never Scores", "1f0676:00", 0},
            {"NEKKETSUKOUSHINKYOKUSOREYUKEDAIUNDOUKAISCDJAPAN", "Infinite Time", "1f097f:00+1f0980:09", 0},
            {"NEKKETSUKOUSHINKYOKUSOREYUKEDAIUNDOUKAISCDJAPAN", "P1 No Disqualify for False Start", "1f097f:00", 0},
            {"NEONECTARISSCDJAPAN", "Defeat One Unit To Win", "1f1b6e:00", 0},
            {"NEUTOPIA", "Infinite Bombs", "1f1d35:08", 0},
            {"NEUTOPIA2USA", "Have Aqua Lung", "1f1e67:01", 0},
            {"NEUTOPIA2USA", "Have Blue Medallion", "1f1e6b:01", 0},
            {"NEUTOPIA2USA", "Have Chalice of Agony", "1f1e5e:01", 0},
            {"NEUTOPIA2USA", "Have Crypt Key", "1f1e6e:01", 0},
            {"NEUTOPIA2USA", "Have Fire Staff", "1f1f59:01", 0},
            {"NEUTOPIA2USA", "Have Green Medallion", "1f1e6c:01", 0},
            {"NEUTOPIA2USA", "Have Hookshot", "1f1e61:01", 0},
            {"NEUTOPIA2USA", "Have Labyrinth Crystal Ball", "1f1e6d:01", 0},
            {"NEUTOPIA2USA", "Have Lightning Staff", "1f1e5b:01", 0},
            {"NEUTOPIA2USA", "Have Magic Hand", "1f1e68:01", 0},
            {"NEUTOPIA2USA", "Have Manipula Herb", "1f1e5f:01", 0},
            {"NEUTOPIA2USA", "Have Moonbeam Moss", "1f1e5c:01", 0},
            {"NEUTOPIA2USA", "Have Rainbow Drop", "1f1e66:01", 0},
            {"NEUTOPIA2USA", "Have Red Medallion", "1f1e6a:01", 0},
            {"NEUTOPIA2USA", "Have Wind Staff", "1f1e5a:01", 0},
            {"NEUTOPIA2USA", "Have Yellow Medallion", "1f1e69:01", 0},
            {"NEUTOPIA2USA", "Infinite Bombs", "1f1e56:14", 0},
            {"NEUTOPIA2USA", "Infinite Energy", "1f1e33:50", 0},
            {"NEUTOPIA2USA", "Infinite Medicine", "1f1e57:02", 0},
            {"NEUTOPIA2USA", "Infinite Wings of Return", "1f1e5c:01", 0},
            {"NEUTOPIA2USA", "Infinte Magic Ring", "1f1e58:01", 0},
            {"NEUTOPIA2USA", "Invincibility", "1f09cd:10", 0},
            {"NEUTOPIAJAPAN", "Have Bell of the Sky", "1f0e47:01", 0},
            {"NEUTOPIAJAPAN", "Have Fire Staff", "1f0e46:01", 0},
            {"NEUTOPIAJAPAN", "Have Magic Ring", "1f0e4a:01", 0},
            {"NEUTOPIAJAPAN", "Have Medicine", "1f0e45:02", 0},
            {"NEUTOPIAJAPAN", "Have Moonbean Moss", "1f0e49:01", 0},
            {"NEUTOPIAJAPAN", "Have Rainbow Drop", "1f0e50:01", 0},
            {"NEUTOPIAJAPAN", "Have Strongest Armor", "1f0e4c:04", 0},
            {"NEUTOPIAJAPAN", "Have Strongest Armor", "1f0e4d:04", 0},
            {"NEUTOPIAJAPAN", "Have Strongest Boots", "1f0e4f:02", 0},
            {"NEUTOPIAJAPAN", "Have Strongest Shield", "1f0e4e:04", 0},
            {"NEUTOPIAJAPAN", "Have Wings of Return", "1f0e48:01", 0},
            {"NEUTOPIAUSA", "Have Bell of the Sky", "1f0e47:01", 0},
            {"NEUTOPIAUSA", "Have Bomb Upgrades", "1f1537:04", 0},
            {"NEUTOPIAUSA", "Have Bombs", "1f1535:00+1f1536:02", 0},
            {"NEUTOPIAUSA", "Have Fire Staff", "1f0e46:01", 0},
            {"NEUTOPIAUSA", "Have Magic Ring", "1f0e4a:01", 0},
            {"NEUTOPIAUSA", "Have Medicine", "1f0e45:02", 0},
            {"NEUTOPIAUSA", "Have Moonbeam Moss", "1f0e49:01", 0},
            {"NEUTOPIAUSA", "Have Rainbow Drop", "1f0e50:01", 0},
            {"NEUTOPIAUSA", "Have Wings of Return", "1f0e48:01", 0},
            {"NEUTOPIAUSA", "Infinite Energy", "1f14c5:40", 0},
            {"NEUTOPIAUSA", "Invincibility", "1f1481:02", 0},
            {"NEUTOPIAUSA", "Max Gold", "1f152f:09+1f1530:09+1f1531:09", 0},
            {"NEWADVENTUREISLANDUSA", "Always Have Skateboard", "1f08d3:02", 0},
            {"NEWADVENTUREISLANDUSA", "Infinite Lives", "1f02d4:02", 0},
            {"NEWADVENTUREISLANDUSA", "Infinite Vitality", "1f02d2:0c", 0},
            {"NEWADVENTUREISLANDUSA", "Invincibility", "1f08d4:1c", 0},
            {"NEWZEALANDSTORY", "Infinite Lives", "1f082c:09", 0},
            {"NEWZEALANDSTORYTHEJAPAN", "Infinite Fuel (Water)", "1f02b2:50", 0},
            {"NEWZEALANDSTORYTHEJAPAN", "Infinite Lives", "1f002c:03", 0},
            {"NEWZEALANDSTORYTHEJAPAN", "Invincibility", "1f0053:04+1f0055:02", 0},
            {"NIGHTCREATURESJAPAN", "Have Axe", "1f098d:01", 0},
            {"NIGHTCREATURESJAPAN", "Have Badger Morph", "1f0988:01", 0},
            {"NIGHTCREATURESJAPAN", "Have Bear Morph", "1f05a9:01", 0},
            {"NIGHTCREATURESJAPAN", "Have Cheese", "1f0990:01", 0},
            {"NIGHTCREATURESJAPAN", "Have Club (Mace)", "1f098a:01", 0},
            {"NIGHTCREATURESJAPAN", "Have Crossbow", "1f098e:01", 0},
            {"NIGHTCREATURESJAPAN", "Have Fish-Bone", "1f0994:09", 0},
            {"NIGHTCREATURESJAPAN", "Have Gun", "1f098f:01", 0},
            {"NIGHTCREATURESJAPAN", "Have Holy Water", "1f0992:01", 0},
            {"NIGHTCREATURESJAPAN", "Have Lantern", "1f0993:50", 0},
            {"NIGHTCREATURESJAPAN", "Have Meat", "1f0995:09", 0},
            {"NIGHTCREATURESJAPAN", "Have Owl Morph", "1f0989:01", 0},
            {"NIGHTCREATURESJAPAN", "Have Sword", "1f098c:01", 0},
            {"NIGHTCREATURESJAPAN", "Have Throwing Spear", "1f098b:01", 0},
            {"NIGHTCREATURESJAPAN", "Infinite Health", "1f0422:80", 0},
            {"NIGHTCREATURESJAPAN", "Invincibility", "1f043d:1e", 0},
            {"NIGHTCREATURESUSA", "Have Axe", "1f098d:01", 0},
            {"NIGHTCREATURESUSA", "Have Badger Morph", "1f0988:01", 0},
            {"NIGHTCREATURESUSA", "Have Bear Morph", "1f0991:01", 0},
            {"NIGHTCREATURESUSA", "Have Cheese", "1f0990:01", 0},
            {"NIGHTCREATURESUSA", "Have Club (Mace)", "1f098a:01", 0},
            {"NIGHTCREATURESUSA", "Have Crossbow", "1f098e:01", 0},
            {"NIGHTCREATURESUSA", "Have Fish-bone", "1f0994:09", 0},
            {"NIGHTCREATURESUSA", "Have Gun", "1f098f:01", 0},
            {"NIGHTCREATURESUSA", "Have Holy Water", "1f0992:01", 0},
            {"NIGHTCREATURESUSA", "Have Lantern", "1f0993:09", 0},
            {"NIGHTCREATURESUSA", "Have Meat", "1f0995:09", 0},
            {"NIGHTCREATURESUSA", "Have Owl Morph", "1f0989:01", 0},
            {"NIGHTCREATURESUSA", "Have Sword", "1f098c:01", 0},
            {"NIGHTCREATURESUSA", "Have Throwing Spear", "1f098b:01", 0},
            {"NIGHTCREATURESUSA", "Infinite Energy", "1f0422:80", 0},
            {"NIGHTCREATURESUSA", "Invincibility", "1f043d:1e", 0},
            {"NIKONIKOPUNJAPAN", "Infinite Time", "1f1621:59", 0},
            {"NIKONIKOPUNJAPAN", "Invincibility", "1f0523:07", 0},
            {"NINJARYUUKENDENJAPAN", "English Text Mode", "1f1277:01", 0},
            {"NINJARYUUKENDENJAPAN", "Infinite Energy", "1f0ead:16", 0},
            {"NINJARYUUKENDENJAPAN", "Infinite Lives", "1f0eaf:02", 0},
            {"NINJARYUUKENDENJAPAN", "Infinite Ninjutsu", "1f115a:09", 0},
            {"NINJARYUUKENDENJAPAN", "Infinite Time", "1f0edb:09", 0},
            {"NINJARYUUKENDENJAPAN", "Invincibility", "1f0eae:0d", 0},
            {"NINJASPIRITSAIGONONINDOUNINJASPIRIT", "Infinite Energy", "1f1fc9:09", 0},
            {"NINJASPIRITUSA", "Infinite Energy", "1f17c9:05", 0},
            {"NINJASPIRITUSA", "Infinite Lives", "1f0b68:03", 0},
            {"NINJASPIRITUSA", "Invincibility", "1f1dee:04", 0},
            {"NINJASPIRITUSA", "Powered Up Weapons", "1f1e58:01", 0},
            {"NINJASPIRITUSA", "Spirit Doubles", "1f184c:67", 0},
            {"NINJAWARRIORSTHEJAPAN", "Infinite Energy", "1f1319:28", 0},
            {"NINJAWARRIORSTHEJAPAN", "Infinite Shurikens", "1f0e7d:30", 0},
            {"NINJAWARRIORSTHEJAPAN", "Infinite Time", "1f0fc8:59", 0},
            {"OBOCCHAMAKUNJAPAN", "Infinite Lives", "1f1e04:03", 0},
            {"OPERATIONWOLFJAPAN", "\"Infinite First Gun", "1f0942:48", 0},
            {"OPERATIONWOLFJAPAN", "Infinite Energy", "1f0924:00+1f0926:00", 0},
            {"OPERATIONWOLFJAPAN", "Infinite Grenades", "1f0944:05", 0},
            {"OPERATIONWOLFJAPAN", "Infinite Second Gun", "1f0943:48", 0},
            {"ORDYNE", "Infinite Lives", "1f0851:03", 0},
            {"ORDYNEJAPAN", "Player 1 Infinite Lives", "1f0051:05", 0},
            {"ORDYNEJAPAN", "Player 1 Invincibility", "1f00b1:14", 0},
            {"ORDYNEJAPAN", "Player 1 Maximum Crystals (Part 1)", "1f0057:09", 0},
            {"ORDYNEJAPAN", "Player 1 Maximum Crystals (Part 2)", "1f0058:09", 0},
            {"ORDYNEJAPAN", "Player 1 Maximum Crystals (Part 3)", "1f0059:09", 0},
            {"ORDYNEJAPAN", "Player 1 Maximum Crystals (Part 4)", "1f005a:09", 0},
            {"ORDYNEJAPAN", "Player 2 Infinte Lives", "1f0052:05", 0},
            {"ORDYNEJAPAN", "Player 2 Invincibility", "1f005a:14", 0},
            {"ORDYNEJAPAN", "Player 2 Max Crystals (Part 1)", "1f005b:09", 0},
            {"ORDYNEJAPAN", "Player 2 Max Crystals (Part 2)", "1f005c:09", 0},
            {"ORDYNEJAPAN", "Player 2 Max Crystals (Part 3)", "1f005d:09", 0},
            {"ORDYNEJAPAN", "Player 2 Max Crystals (Part 4)", "1f005e:09", 0},
            {"ORDYNEUSA", "P1 Infinite Crystals", "1f0057:09+1f0058:09+1f0059:09+1f005a:09", 0},
            {"ORDYNEUSA", "P1 Infinite Lives", "1f0051:05", 0},
            {"ORDYNEUSA", "P1 Invincibility", "1f00b1:14", 0},
            {"ORDYNEUSA", "P2 Infinite Crystals", "1f005b:09+1f005c:09+1f005d:09+1f0053:09", 0},
            {"ORDYNEUSA", "P2 Infinite Lives", "1f0052:05", 0},
            {"ORDYNEUSA", "P2 Invincibility", "1f00b2:14", 0},
            {"OUTLIVEJAPAN", "Infinite Credits", "1f0651:ff+1f0652:ff", 0},
            {"OUTRUNJAPAN", "Infinite Time", "1f002b:75", 0},
            {"OUTRUNJAPAN", "Input Test Shown on Title Screen", "1f0091:02", 0},
            {"OVERRIDEJAPAN", "Infinite Energy", "1f0056:24", 0},
            {"OVERRIDEJAPAN", "Infinite Lives", "1f0057:02", 0},
            {"OVERRIDEJAPAN", "Invincibility", "1f0bc0:01", 0},
            {"P47THEFREEDOMFIGHTERJAPAN", "Infinite Lives", "1f0530:09", 0},
            {"P47THEFREEDOMFIGHTERJAPAN", "Invincibility", "1f052d:21", 0},
            {"PACHIOKUNWARAUUCHUUSCDJAPAN", "Automatically Win Pinball Minigame", "1f0014:55+1f0011:00+1f0012:00", 0},
            {"PACLANDJAPAN", "Infinite Lives", "1f0167:05", 0},
            {"PACLANDJAPAN", "Infinite Time (Part 1)", "1f0549:74", 0},
            {"PACLANDJAPAN", "Infinite Time (Part 2)", "1f0193:09", 0},
            {"PACLANDUSA", "Infinite Lives", "1f0167:05", 0},
            {"PACLANDUSA", "Infinite Time", "1f0549:74+1f0193:09", 0},
            {"PARANOIAJAPAN", "Infinite Lives", "1f134c:0a", 0},
            {"PARASOLSTARSTHESTORYOFBUBBLEBOBBLEIIIJAPAN", "Invincibility", "1f0044:01", 0},
            {"PARASOLSTARSTHESTORYOFBUBBLEBOBBLEIIIUSA", "P1 Infinite Lives", "1f19ad:04", 0},
            {"PARASOLSTARSTHESTORYOFBUBBLEBOBBLEIIIUSA", "P1 Invincible", "1f13ad:14", 0},
            {"PARASOLSTARSTHESTORYOFBUBBLEBOBBLEIIIUSA", "P2 Infinite Lives", "1f19b0:04", 0},
            {"PARASOLSTARSTHESTORYOFBUBBLEBOBBLEIIIUSA", "P2 Invincible", "1f13b5:14", 0},
            {"PARODIUSDASHINWAKARAOWARAIEJAPAN", "P1 Infinite Lives", "1f0087:05", 0},
            {"PARODIUSDASHINWAKARAOWARAIEJAPAN", "P2 Infinite Lives", "1f0088:05", 0},
            {"PCDENJINPUNKICCYBORGSJAPAN", "Infinite Lives", "1f00b2:0a", 0},
            {"PCDENJINPUNKICCYBORGSJAPAN", "invincibility", "1f1a87:14", 0},
            {"PCGENJIN2PITHECANTHROPUSCOMPUTERURUSJAPAN", "99 Smileys", "1f0ec6:63", 0},
            {"PCGENJIN2PITHECANTHROPUSCOMPUTERURUSJAPAN", "Infinite Health", "1f0e86:0f", 0},
            {"PCGENJIN2PITHECANTHROPUSCOMPUTERURUSJAPAN", "Infinite Lives", "1f0a1a:09", 0},
            {"PCGENJIN2PITHECANTHROPUSCOMPUTERURUSJAPAN", "Invincibility", "1f0e99:14", 0},
            {"PCGENJIN3PITHECANTHROPUSCOMPUTERURUSJAPAN", "Infinite Health (Both Players)", "1f0b8d:14", 0},
            {"PCGENJIN3PITHECANTHROPUSCOMPUTERURUSJAPAN", "Infinte Lives (Both Players)", "1f0b8b:09", 0},
            {"PCGENJIN3PITHECANTHROPUSCOMPUTERURUSJAPAN", "P1 Invincible", "1f09b6:14", 0},
            {"PCGENJIN3PITHECANTHROPUSCOMPUTERURUSJAPAN", "P2 Invincible", "1f09b7:14", 0},
            {"PCGENJINPITHECANTHROPUSCOMPUTERURUSJAPAN", "Infinite Health", "1f0db2:0f", 0},
            {"PCGENJINPITHECANTHROPUSCOMPUTERURUSJAPAN", "Infinite Lives", "1f0daf:09", 0},
            {"PCGENJINPITHECANTHROPUSCOMPUTERURUSJAPAN", "Invincibility", "1f0c03:4c", 0},
            {"PHOTOGRAPHBOY", "Required Amount", "1f0862:03", 0},
            {"POWERELEVENJAPAN", "CPU Never Scores", "1f175d:00", 0},
            {"POWERELEVENJAPAN", "Low Time", "1f18e1:01", 0},
            {"POWERELEVENJAPAN", "P1 Scores x99", "1f175c:00", 0},
            {"POWERGATEJAPAN", "Infinite Lives", "1f1c6c:09", 0},
            {"POWERLEAGUEJAPAN", "CPU Never Scores (Pennant Mode)", "1f034a:00", 0},
            {"POWERLEAGUEJAPAN", "P1 Scores x99", "1f0349:63", 0},
            {"PRINCEOFPERSIASCDUSA", "Unlimited Health (disable if you fall into spikes/pi", "1f0736:04", 0},
            {"PRINCESSMINERVASCDJAPAN", "C1 Infinite Energy", "1f1163:50", 0},
            {"PRINCESSMINERVASCDJAPAN", "C2 Infinite Energy", "1f1165:50", 0},
            {"PRINCESSMINERVASCDJAPAN", "C3 Infinite Energy", "1f1167:50", 0},
            {"PROYAKYUUWORLDSTADIUM91JAPAN", "CPU/P2 Never Scores", "1f0119:00", 0},
            {"PROYAKYUUWORLDSTADIUM91JAPAN", "P1 Scores x99", "1f0118:63", 0},
            {"PROYAKYUUWORLDSTADIUMJAPAN", "CPU/P2 Never Scores", "1f0119:00", 0},
            {"PROYAKYUUWORLDSTADIUMJAPAN", "P1 Scores x99", "1f0118:63", 0},
            {"PSYCHICSTORMSCDJAPAN", "Infinite Transformation Time", "1f1313:91", 0},
            {"PSYCHICSTORMSCDJAPAN", "Infinite Transformations", "1f14df:03", 0},
            {"PSYCHICSTORMSCDJAPAN", "P1 Infinite Energy", "1f0c1e:55", 0},
            {"PSYCHICSTORMSCDJAPAN", "P2 Infinite Energy", "1f0c1f:55", 0},
            {"PSYCHOCHASER", "Infinite Lives", "1f0842:09", 0},
            {"PSYCHOCHASERJAPAN", "1-Hit Boss Kill", "1f0a58:00", 0},
            {"PSYCHOCHASERJAPAN", "Infinite Lives", "1f0041:09", 0},
            {"PSYCHOCHASERJAPAN", "Invincibility", "1f0a20:6d", 0},
            {"PSYCHOSIS", "Infinite Lives", "1f1b4c:09", 0},
            {"PSYCHOSISUSA", "Infinite Lives", "1f134c:03", 0},
            {"PSYCHOSISUSA", "Invincibility", "1f0cf7:10", 0},
            {"PUZZNICJAPAN", "Infinite Retry", "1f0443:02", 0},
            {"PUZZNICJAPAN", "Infinite Timer", "1f0431:59", 0},
            {"RABIOLEPUS", "Infinite Lives", "1f0987:09", 0},
            {"RABIOLEPUS", "Infinite Missiles", "1f0989:09", 0},
            {"RABIOLEPUS", "Infinite Shield", "1f0985:03", 0},
            {"RABIOLEPUSSPECIALJAPAN", "Infinite Credits", "1f0183:09", 0},
            {"RABIOLEPUSSPECIALJAPAN", "Infinite Lives", "1f0187:09", 0},
            {"RABIOLEPUSSPECIALJAPAN", "Infinite Missiles", "1f0189:09", 0},
            {"RABIOLEPUSSPECIALJAPAN", "Infinite Shield", "1f0185:03", 0},
            {"RABIOLEPUSSPECIALJAPAN", "Invincibility", "1f005b:85", 0},
            {"RACINGDAMASHIIJAPAN", "Always 1st Place", "1f1516:01+1f151e:02", 0},
            {"RACINGDAMASHIIJAPAN", "P1 Low Lap Time", "1f110a:00", 0},
            {"RAIDEN", "Infinite Bombs", "1f1cc5:09", 0},
            {"RAIDEN", "Infinite Lives", "1f1c61:09", 0},
            {"RAIDENUSA", "Have 5-Way Shot", "1f14e2:05", 0},
            {"RAIDENUSA", "Have Max (M) Power Up", "1f14e8:04", 0},
            {"RAIDENUSA", "Infinite Bombs", "1f14c5:09", 0},
            {"RAIDENUSA", "Infinite Continues", "1f14d6:09", 0},
            {"RAIDENUSA", "Infinite Lives", "1f14cf:0a", 0},
            {"RAIDENUSA", "Invincibility", "1f05c6:01", 0},
            {"RANMAONEHALFCDJAPAN", "Infinite Energy", "1f0725:63", 0},
            {"RASTANSAGAIIJAPAN", "Infinite Energy", "1f0219:0a", 0},
            {"RASTANSAGAIIJAPAN", "Infinite Time", "1f10ef:09+1f10f0:09+1f10f1:09", 0},
            {"RASTANSAGAIIJAPAN", "Invincibility", "1f121a:14", 0},
            {"RAYXANBERIICDJAPAN", "Infinite Lives", "1f000b:02", 0},
            {"RAYXANBERIICDJAPAN", "Invincible", "1f085a:21+1f085e:02", 0},
            {"REDALERTCDJAPAN", "1-Hit Boss Kill", "1f06cf:00", 0},
            {"REDALERTCDJAPAN", "Disable Timer", "1f040e:40", 0},
            {"REDALERTCDJAPAN", "Infinite Flame Thrower", "1f0413:09", 0},
            {"REDALERTCDJAPAN", "Infinite Grenades", "1f0411:09", 0},
            {"REDALERTCDJAPAN", "Infinite Rockets", "1f0414:09", 0},
            {"REDALERTCDJAPAN", "Infinite Sentry Orbs", "1f0415:09", 0},
            {"REDALERTCDJAPAN", "Infinite Spikes", "1f0412:09", 0},
            {"REDALERTCDJAPAN", "Infinite Time", "1f040c:05+1f040d:00", 0},
            {"REDALERTCDJAPAN", "Infinite Vital", "1f040a:13+1f0d30:13", 0},
            {"REDALERTCDJAPAN", "Invincibility (disable to pick up survivors)", "1f0400:50", 0},
            {"RIOTZONESCDUSA", "Infinite Energy", "1f0993:70", 0},
            {"RIOTZONESCDUSA", "Infinite Lives", "1f0e44:05", 0},
            {"RIOTZONESCDUSA", "Infinite Time", "1f0e49:40", 0},
            {"ROCKON", "Infinite Lives", "1f0e85:09", 0},
            {"ROCKONJAPAN", "Infinite Lives", "1f0685:07", 0},
            {"RTYPECOMPLETECD", "Infinite Lives", "1f0942:03", 0},
            {"RTYPECOMPLETECDSCDJAPAN", "Infinite Lives", "1f02fc:03", 0},
            {"RTYPECOMPLETECDSCDJAPAN", "Invincibility", "1f159d:05+1f1575:05+1f1576:05+1f1577:05+1f1578:05", 0},
            {"RTYPEIIJAPAN", "Auto Fire (Charged Shot)", "1f0150:80", 0},
            {"RTYPEIIJAPAN", "Infinite Credits", "1f1445:09", 0},
            {"RTYPEIIJAPAN", "Infinite Lives", "1f1444:09", 0},
            {"RTYPEIJAPAN", "Auto Fire (Charged Shot)", "1f0150:80", 0},
            {"RTYPEIJAPAN", "Infinite Credits", "1f1477:09", 0},
            {"RTYPEIJAPAN", "Infinite Lives", "1f1476:09", 0},
            {"RTYPEIJAPAN", "Invulnerability", "1f0d76:01", 0},
            {"RTYPEUSA", "\"Invincibility versus Enemies (non-blinking)", "1f0ac4:00", 0},
            {"RTYPEUSA", "Auto Fire (Charged Shot)", "1f016f:80", 0},
            {"RTYPEUSA", "Infinite Credits", "1f0143:09", 0},
            {"RTYPEUSA", "Infinite Lives", "1f0142:09", 0},
            {"RTYPEUSA", "Invulnerability", "1f0d81:7b", 0},
            {"SALAMANDERJAPAN", "Infinite Credits", "1f010d:09", 0},
            {"SALAMANDERJAPAN", "Infinite Lives", "1f0085:09", 0},
            {"SALAMANDERJAPAN", "Invincibility", "1f0b0c:01", 0},
            {"SAMURAIGHOSTUSA", "Infinite Health", "1f15c8:31+1f15c9:31", 0},
            {"SAMURAIGHOSTUSA", "Invincibility", "1f00a3:17", 0},
            {"SCI", "Turbo", "1f1198:09", 0},
            {"SEIREISENSHISPRIGGANCDJAPAN", "Infinite Lives", "1f0ce0:05", 0},
            {"SEIREISENSHISPRIGGANCDJAPAN", "Invincibility", "1f13c0:04", 0},
            {"SEIREISENSHISPRIGGANCDJPN", "Infinite Lives", "1f0ce0:05", 0},
            {"SHADOWOFTHEBEASTSCDUSA", "Infinite Health", "1f0d89:15", 0},
            {"SHADOWOFTHEBEASTSCDUSA", "Invincibility", "1f0d20:59", 0},
            {"SHAPESHIFTERSCDUSA", "Infinite Gold", "1f0316:15+1f0317:15", 0},
            {"SHAPESHIFTERSCDUSA", "Infinite Health", "1f0313:32", 0},
            {"SHAPESHIFTERSCDUSA", "Infinite Jewels", "1f0318:15", 0},
            {"SHAPESHIFTERSCDUSA", "Infinite Lives", "1f0312:15", 0},
            {"SHINMEGAMITENSEISCDJAPAN", "Infinite Initial Ability Points", "1f0660:18", 0},
            {"SHINOBIJAPAN", "Infinite Lives", "1f07e5:06", 0},
            {"SHINOBIJAPAN", "Instant boss Kill (turn off once boss is defeated)", "1f07eb:00", 0},
            {"SHINOBIJAPAN", "No Enemy Spawns (turn off before you reach bosses)", "1f079f:01", 0},
            {"SHINOBIJAPAN", "No Rescues Needed", "1f082c:00", 0},
            {"SHINOBIJAPAN", "Start on Final Boss", "1f07e2:03+1f07e3:03", 0},
            {"SHIRYOUSENSENWAROFTHEDEADJAPAN", "Infinite PF (Health)", "1f0037:ff", 0},
            {"SHOCKMANUSA", "Bosses Die Automatically (turn off once boss is dead", "1f0e0d:00", 0},
            {"SHOCKMANUSA", "Charged Shots", "1f1e8a:01", 0},
            {"SHOCKMANUSA", "Infinite Health", "1f0e0c:14", 0},
            {"SHOCKMANUSA", "Invincibility", "1f1b48:2d", 0},
            {"SIDEARMSHYPERDYNE", "Infinite Lives", "1f086c:63", 0},
            {"SIDEARMSHYPERDYNEJAPAN", "Infinite Credits", "1f0070:09", 0},
            {"SIDEARMSHYPERDYNEJAPAN", "Infinite Lives", "1f006c:90", 0},
            {"SIDEARMSHYPERDYNEJAPAN", "Invincibility", "1f0625:14", 0},
            {"SIDEARMSHYPERDYNEJAPAN", "Max Gun Upgrade", "1f0636:03", 0},
            {"SIDEARMSMAGEACHIP", "Infinite Lives", "1f086c:09", 0},
            {"SIDEARMSUSA", "Infinite Credits", "1f0070:09", 0},
            {"SIDEARMSUSA", "Infinite Lives", "1f006c:90", 0},
            {"SIDEARMSUSA", "Invincibility", "1f0625:14", 0},
            {"SIDEARMSUSA", "Max Gun Upgrade", "1f0636:03", 0},
            {"SILENTDEBUGGERS", "Infinite 2nd Weapon", "1f0a1d:ff", 0},
            {"SILENTDEBUGGERSJAPAN", "Unlimited Battery (Part 1)", "1f0083:30", 0},
            {"SILENTDEBUGGERSJAPAN", "Unlimited Battery (Part 2)", "1f0084:30", 0},
            {"SILENTDEBUGGERSJAPAN", "Unlimited Motor Cannon Ammo", "1f021a:89", 0},
            {"SILENTDEBUGGERSUSA", "Infinite Battery", "1f0083:30+1f0084:30", 0},
            {"SILENTDEBUGGERSUSA", "Infinite Motor Cannon Ammo", "1f021a:89", 0},
            {"SINISTRONUSA", "Infinite Lives", "1f19f2:0a", 0},
            {"SKWEEKJAPAN", "Infinite Time", "1f07ac:99", 0},
            {"SKWEEKJAPAN", "Need 1 Tile to Complete Round", "1f1110:00+1f1111:00", 0},
            {"SOLDIERBLADE", "Infinite Lives", "1f1eaa:09", 0},
            {"SOLDIERBLADEJAPAN", "Invincibility", "1f009d:16", 0},
            {"SOLDIERBLADESPECIALVERSIONJAPAN", "Invincibility", "1f009d:16", 0},
            {"SOLDIERBLADEUSA", "Infinite Special Bar", "1f16ab:ff", 0},
            {"SOLDIERBLADEUSA", "Invincibility", "1f009d:16", 0},
            {"SOLDIERBLADEUSA", "Max Weapon Upgrades", "1f1685:03", 0},
            {"SOMERASSAULT", "Infinite Energy", "1f1911:03", 0},
            {"SOMERASSAULTUSA", "Infinite Health", "1f1111:03", 0},
            {"SOMERASSAULTUSA", "Infinite Time", "1f1112:09+1f1113:09+1f1114:09", 0},
            {"SOMERASSAULTUSA", "Invincibility", "1f082a:14", 0},
            {"SONSONIIJAPAN", "Infinite Health", "1f02b8:0e", 0},
            {"SONSONIIJAPAN", "Infinite Zenny", "1f020e:09+1f020f:09+1f0210:09+1f0211:09+1f0212:09", 0},
            {"SONSONIIJAPAN", "Invincibility", "1f02c8:14", 0},
            {"SPACEFANTASYZONEPROTOTYPEBACKUPCDSCDJPN", "Infinite Health", "1f001e:08", 0},
            {"SPACEFANTASYZONEPROTOTYPEBACKUPCDSCDJPN", "Max Cash", "1f0028:09", 0},
            {"SPACEFANTASYZONEPROTOTYPECDSCDJAPAN", "Infinite Health", "1f001e:18", 0},
            {"SPACEFANTASYZONEPROTOTYPECDSCDJAPAN", "Invincibility", "1f0016:01", 0},
            {"SPACEFANTASYZONEPROTOTYPECDSCDJAPAN", "Maximum Cash", "1f0028:09", 0},
            {"SPACEHARRIERJAPAN", "Infinite Health", "1f000d:05", 0},
            {"SPACEHARRIERJAPAN", "Invincibility", "1f000e:16", 0},
            {"SPACEHARRIERUSA", "Infinite Lives", "1f000d:05", 0},
            {"SPACEHARRIERUSA", "Invincibility", "1f000e:16", 0},
            {"SPACEINVADERSFUKKATSUNOHIJAPAN", "Automatically Beat a Level (Space Invaders + Mode)", "1f00df:00", 0},
            {"SPLASHLAKECDUSA", "Infinite Health", "1f176b:03", 0},
            {"SPLASHLAKECDUSA", "Infinite Lives", "1f176d:09", 0},
            {"SPLASHLAKECDUSA", "Infinite Time", "1f1770:09", 0},
            {"SPLASHLAKECDUSA", "Instant Complete (E# Mod)", "1f176e:00", 0},
            {"SPLATTERHOUSE", "Infinite Energy", "1f124d:05", 0},
            {"SPLATTERHOUSE", "Shotgun Ammo (Must get the gun first)", "1f1252:08", 0},
            {"SPLATTERHOUSEJAPAN", "Infinite Hearts USA", "1f0a4d:05", 0},
            {"SPLATTERHOUSEJAPAN", "Infinite Lives USA", "1f0df4:05", 0},
            {"SPLATTERHOUSEJAPAN", "Infinite Shotgun USA", "1f0a52:08", 0},
            {"SPLATTERHOUSEJAPAN", "Invincibility", "1f0255:14", 0},
            {"SPLATTERHOUSEJAPAN", "Have Stage Weapon", "1f0c4b:05", 0},
            {"SPLATTERHOUSEJAPAN", "1-Hit Kill Double Chainsaw Boss", "1f0a5c:00", 0},
            {"SPLATTERHOUSEJAPAN", "1-Hit Kill Flying Masks Boss", "1f0a61:00", 0},
            {"SPLATTERHOUSEJAPAN", "1-Hit Kill Your Woman Boss", "1f0a5e:00", 0},
            {"SPLATTERHOUSEJAPAN", "1-Hit Kill Tree Root Boss", "1f0a5a:00", 0},
            {"SPLATTERHOUSEJAPAN", "1-Hit Kill Final Boss", "1f0a5d:00", 0},
            {"SPLATTERHOUSEJAPAN", "Enable Hard Mode USA", "1f1062:01", 0},
            {"SPLATTERHOUSEJAPAN", "Start on Final Stage", "1f002e:17", 0},
            {"SPLATTERHOUSEJAPAN", "Infinite Energy ALT", "1f124d:05", 0},
            {"SPLATTERHOUSEJAPAN", "Shotgun Ammo ALT", "1f1252:08", 0},
            {"SPLATTERHOUSEUSA", "1-Hit Boss Kill (Double Chainsaw)", "1f0a5c:00", 0},
            {"SPLATTERHOUSEUSA", "1-Hit Boss Kill (Final Boss)", "1f0a5d:00", 0},
            {"SPLATTERHOUSEUSA", "1-Hit Boss Kill (Flying Masks)", "1f0a61:00", 0},
            {"SPLATTERHOUSEUSA", "1-Hit Boss Kill (Shitty Tree Root)", "1f0a5a:00", 0},
            {"SPLATTERHOUSEUSA", "1-Hit Boss Kill (Your Woman)", "1f0a5e:00", 0},
            {"SPLATTERHOUSEUSA", "Enable Hard Mode", "1f1062:01", 0},
            {"SPLATTERHOUSEUSA", "Have Stage Weapon", "1f0c4b:05", 0},
            {"SPLATTERHOUSEUSA", "Infinite Hearts", "1f0a4d:05", 0},
            {"SPLATTERHOUSEUSA", "Infinite Lives", "1f0df4:05", 0},
            {"SPLATTERHOUSEUSA", "Infinite Shotgun Shots", "1f0a52:08", 0},
            {"SPLATTERHOUSEUSA", "Invincible", "1f0255:14", 0},
            {"SPRIGGANMARKIIRETERRAFORMPROJECTIMPERFECTSCDJAPAN", "Instant Energy", "1f005c:57", 0},
            {"STARPARODIASCDJAPAN", "Always Have Shield", "1f1f23:01", 0},
            {"STARPARODIASCDJAPAN", "Infinite Lives", "1f1f1b:02", 0},
            {"STARTLINGODYSSEYIIMAKYOUSENSOUSCDJAPAN", "Character 1 Maximum HP (Part 2)", "1f0e67:03", 0},
            {"STARTLINGODYSSEYIIMAKYOUSENSOUSCDJAPAN", "Character 1 Maximum HP (Part 4)", "1f0e69:03", 0},
            {"STARTLINGODYSSEYIIMAKYOUSENSOUSCDJAPAN", "Character 1 Maximum MP (Part 2)", "1f0e6b:03", 0},
            {"STARTLINGODYSSEYIIMAKYOUSENSOUSCDJAPAN", "Character 1 Maximum MP (Part 4)", "1f0e6d:03", 0},
            {"STARTLINGODYSSEYIIMAKYOUSENSOUSCDJAPAN", "Character 2 Maximum HP (Part 2)", "1f0e7e:03", 0},
            {"STARTLINGODYSSEYIIMAKYOUSENSOUSCDJAPAN", "Character 2 Maximum HP (Part 4)", "1f0e80:03", 0},
            {"STARTLINGODYSSEYIIMAKYOUSENSOUSCDJAPAN", "Character 3 Maximum HP (Part 2)", "1f0e95:03", 0},
            {"STARTLINGODYSSEYIIMAKYOUSENSOUSCDJAPAN", "Character 3 Maximum HP (Part 4)", "1f0e97:03", 0},
            {"STREETFIGHTERIICHAMPIONEDITIONJAPAN", "Infinite Time", "1f0dbc:99", 0},
            {"STREETFIGHTERIICHAMPIONEDITIONJAPAN", "P1 Bonus Stage 2 Perfect", "1f17c8:20", 0},
            {"STREETFIGHTERIICHAMPIONEDITIONJAPAN", "P1 Can Do Most Moves in Mid-Air", "1f1634:00", 0},
            {"STREETFIGHTERIICHAMPIONEDITIONJAPAN", "P1 Infinite Health", "1f1410:b0+1f1424:b0", 0},
            {"STREETFIGHTERIICHAMPIONEDITIONJAPAN", "P1 Instant Win (P2 Life Mod)", "1f1411:ff+1f1425:26", 0},
            {"STREETFIGHTERIICHAMPIONEDITIONJAPAN", "P1 Unlimited Energy", "1f1410:b0+1f177a:b0", 0},
            {"STREETFIGHTERIICHAMPIONEDITIONJAPAN", "P2 Can Do Most Moves in Mid-Air", "1f1635:00", 0},
            {"STREETFIGHTERIICHAMPIONEDITIONJAPAN", "P2 Unlimited Energy", "1f1411:b0+1f177b:b0", 0},
            {"STRIDERHIRYUUACDJAPAN", "Infinite Energy", "1f00c8:03", 0},
            {"STRIDERHIRYUUACDJAPAN", "Invincibility", "1f12d1:05", 0},
            {"STRIPFIGHTERIIJAPANUNL", "Infinite Time", "1f037c:63", 0},
            {"STRIPFIGHTERIIJAPANUNL", "P1 Infinite Health", "1f0f39:00+1f0f3b:00", 0},
            {"STRIPFIGHTERIIJAPANUNL", "P1 Instant Win (P2 Life Mod)", "1f0f3a:60+1f0f3c:60", 0},
            {"STRIPFIGHTERIIJAPANUNL", "Show Lots of Naked Chicks", "1f1009:03", 0},
            {"SUMMERCARNIVAL92ALZADICKCDJAPAN", "Invincibility", "1f0406:02", 0},
            {"SUMMERCARNIVAL93NEXZRSPECIALSCDJAPAN", "Invincibility", "1f0067:01", 0},
            {"SUPERDARIUSCDJAPAN", "Infinite Lives", "1f0bc8:04", 0},
            {"SUPERDARIUSCDJAPAN", "Invincibility", "1f0bb5:04", 0},
            {"SUPERDARIUSCDJAPAN", "Max Armor", "1f0bc5:16", 0},
            {"SUPERDARIUSCDJAPAN", "Max Bomb", "1f0bc0:16", 0},
            {"SUPERDARIUSCDJAPAN", "Max Shot", "1f0bbe:16", 0},
            {"SUPERDARIUSIISCDJAPAN", "Infinite Lives", "1f0bf0:05", 0},
            {"SUPERDARIUSIISCDJAPAN", "Invincibility", "1f0c03:02", 0},
            {"SUPERMETALCRUSHERJAPAN", "CPU No CG", "1f0722:00", 0},
            {"SUPERMETALCRUSHERJAPAN", "CPU No FL", "1f0721:00", 0},
            {"SUPERMETALCRUSHERJAPAN", "CPU No HP", "1f0720:00", 0},
            {"SUPERMETALCRUSHERJAPAN", "CPU Partner No CG (Super Battle)", "1f0732:00", 0},
            {"SUPERMETALCRUSHERJAPAN", "CPU Partner No FL (Super Battle)", "1f0731:00", 0},
            {"SUPERMETALCRUSHERJAPAN", "CPU Partner No HP (Super Battle)", "1f0730:00", 0},
            {"SUPERMETALCRUSHERJAPAN", "Infinite Adjustment Points", "1f189e:ff", 0},
            {"SUPERMETALCRUSHERJAPAN", "P1 Infinite CG", "1f0702:ff", 0},
            {"SUPERMETALCRUSHERJAPAN", "P1 Infinite FL", "1f0701:ff", 0},
            {"SUPERMETALCRUSHERJAPAN", "P1 Infinite HP", "1f0700:ff", 0},
            {"SUPERMETALCRUSHERJAPAN", "P1 Partner CG (Super Battle)", "1f0712:ff", 0},
            {"SUPERMETALCRUSHERJAPAN", "P1 Partner FL (Super Battle)", "1f0711:ff", 0},
            {"SUPERMETALCRUSHERJAPAN", "P1 Partner HP (Super Battle)", "1f0710:ff", 0},
            {"SUPERMETALCRUSHERJAPAN", "Stat Max Attack Range", "1f18ad:20", 0},
            {"SUPERMETALCRUSHERJAPAN", "Stat Max Charge", "1f18af:20", 0},
            {"SUPERMETALCRUSHERJAPAN", "Stat Max Destructive", "1f18ac:20", 0},
            {"SUPERMETALCRUSHERJAPAN", "Stat Max Dexterity", "1f18a6:20", 0},
            {"SUPERMETALCRUSHERJAPAN", "Stat Max Durability", "1f18a7:20", 0},
            {"SUPERMETALCRUSHERJAPAN", "Stat Max Ferocity", "1f18a4:20", 0},
            {"SUPERMETALCRUSHERJAPAN", "Stat Max IQ", "1f18a1:20", 0},
            {"SUPERMETALCRUSHERJAPAN", "Stat Max Nature", "1f18a3:20", 0},
            {"SUPERMETALCRUSHERJAPAN", "Stat Max Scanner", "1f18ae:20", 0},
            {"SUPERMETALCRUSHERJAPAN", "Stat Max Shield", "1f18a8:20", 0},
            {"SUPERMETALCRUSHERJAPAN", "Stat Max Speed", "1f18a5:20", 0},
            {"SUPERMETALCRUSHERJAPAN", "Stat Max Tank", "1f18aa:20", 0},
            {"SUPERMETALCRUSHERJAPAN", "Stat Max Target", "1f18ab:20", 0},
            {"SUPERMETALCRUSHERJAPAN", "Stat Max Thinking", "1f18a2:20", 0},
            {"SUPERMETALCRUSHERJAPAN", "Stat Max Torque", "1f18a9:20", 0},
            {"SUPERMETALCRUSHERJAPAN", "Unlock Super Battle & 2x2 Practice Modes", "1f1880:01", 0},
            {"SUPERRAIDENSCDJAPAN", "Infinite Bombs", "1f19d4:09", 0},
            {"SUPERRAIDENSCDJAPAN", "Infinite Lives", "1f19de:03", 0},
            {"SUPERSTARSOLDIER", "Infinite Lives", "1f086f:03", 0},
            {"SUPERSTARSOLDIERJAPAN", "Infinte Lives", "1f006f:09", 0},
            {"SUPERSTARSOLDIERJAPAN", "Invincibility (Cannot Pick-Up Upgrades)", "1f006c:14", 0},
            {"SUPERSTARSOLDIERUSA", "Infinite Lives", "1f006f:09", 0},
            {"SUPERSTARSOLDIERUSA", "Invincibility (Cannot Pick Up Upgrades While Active)", "1f006c:14", 0},
            {"SUPERVOLLEYBALLUSA", "CPU Never Scores", "1f132c:00", 0},
            {"SUPERVOLLEYBALLUSA", "P1 Scores x20", "1f132b:14", 0},
            {"SUSANOOUDENSETSUJAPAN", "Infinite Energy", "1f03d2:ff", 0},
            {"SUSANOOUDENSETSUJAPAN", "Infinite Gold", "1f0280:ff+1f0281:ff", 0},
            {"SUSANOOUDENSETSUJAPAN", "Max EXP", "1f0282:ff+1f0283:ff", 0},
            {"SUSANOOUDENSETSUJAPAN", "Max HP", "1f03ea:ff", 0},
            {"SUSANOOUDENSETSUJAPAN", "Max Will", "1f041a:ff", 0},
            {"SYDMEADSTERRAFORMINGCDSCDUSA", "Infinite Lives", "1f0366:03", 0},
            {"SYDMEADSTERRAFORMINGCDSCDUSA", "Infinite Lives", "1f0a11:03", 0},
            {"SYDMEADSTERRAFORMINGCDSCDUSA", "Invincible (Cheat)", "1f0076:32", 0},
            {"SYLPHIASCDJAPAN", "Infinite Energy", "1f167e:02", 0},
            {"TAKAHASHIMEIJINNOSHINBOUKENJIMAJAPAN", "Infinite Energy/Time", "1f02d2:0c", 0},
            {"TAKAHASHIMEIJINNOSHINBOUKENJIMAJAPAN", "Infinite Lives", "1f02d4:09+1f0748:09", 0},
            {"TAKEDASHINGENJAPAN", "1-Hit Boss Kill", "1f0758:00", 0},
            {"TAKEDASHINGENJAPAN", "Infinite Energy", "1f0021:50", 0},
            {"TAKEDASHINGENJAPAN", "Invincibility", "1f0832:14", 0},
            {"TAKINITTOTHEHOOPUSA", "CPU Never Scores", "1f0ef8:00+1f0ef9:00", 0},
            {"TALESPINUSA", "Infinite Energy", "1f17df:05", 0},
            {"TALESPINUSA", "Infinite Lives", "1f17de:09", 0},
            {"TALESPINUSA", "Invincibility", "1f17db:14", 0},
            {"TATSUJIN", "Infinite Bombs", "1f0856:03", 0},
            {"TATSUJIN", "Infinite Lives", "1f0854:03", 0},
            {"TATSUJINJAPAN", "Infinite Bombs (Activate in Game, NOT title screen)", "1f0056:09", 0},
            {"TATSUJINJAPAN", "Infinite Credits", "1f0050:09", 0},
            {"TATSUJINJAPAN", "Infinite Lives", "1f0054:09", 0},
            {"TATSUNOKOFIGHTERJAPAN", "Infinite Health", "1f1c85:50", 0},
            {"TATSUNOKOFIGHTERJAPAN", "Invincibility", "1f0048:14", 0},
            {"TATSUNOKOFIGHTERJAPAN", "Max Gold", "1f1c8a:63+1f1c8b:63", 0},
            {"TENCHIWOKURAUSCDJAPAN", "Infinite HP", "1f1002:25", 0},
            {"TENCHIWOKURAUSCDJAPAN", "Max Exp", "1f0076:15+1f0077:15+1f0078:15", 0},
            {"TENCHIWOKURAUSCDJAPAN", "Max Power", "1f0071:96", 0},
            {"TENSEIRYUUSAINTDRAGON", "Infinite Lives", "1f1acc:03", 0},
            {"TENSEIRYUUSAINTDRAGONJAPAN", "Infinite Lives", "1f12cc:05", 0},
            {"TERRACRESTAIIMANDOLERNOGYAKUSHUUJAPAN", "Infinite F", "1f128a:03", 0},
            {"TERRACRESTAIIMANDOLERNOGYAKUSHUUJAPAN", "Infinite Lives", "1f1289:09", 0},
            {"TERRACRESTAIIMANDOLERNOGYAKUSHUUJAPAN", "Invincibility", "1f1370:76", 0},
            {"TERRACRESTAIIMANDORAANOGYAKUSHUU", "Infinite Lives", "1f1a89:03", 0},
            {"THUNDERBLADE", "Infinite Lives", "1f0838:03", 0},
            {"THUNDERBLADEJAPAN", "Infinite Lives", "1f0038:05", 0},
            {"TIGERROADTORAENOMICHI", "Infinite Energy", "1f08d9:10", 0},
            {"TIGERROADTORAENOMICHI", "Infinite Lives", "1f14f7:03", 0},
            {"TIGERROADUSA", "Infinite Energy", "1f00d9:10", 0},
            {"TIGERROADUSA", "Infinite Lives", "1f0cf7:02", 0},
            {"TIGERROADUSA", "Invincibility", "1f004a:01", 0},
            {"TIGERSHARK", "Infinite Lives", "1f0aa4:03", 0},
            {"TIGERSHARK", "Infinite Support Firepower", "1f1221:03", 0},
            {"TIMEBALL", "Infinite Time", "1f1e2c:1e", 0},
            {"TIMECRUISE", "Infinite Balls", "1f0e30:03", 0},
            {"TIMECRUISEIIJAPAN", "Infinite Balls", "1f0630:0a", 0},
            {"TIMECRUISEUSA", "Ball Parameter Menu (Options Menu)", "1f0737:0e", 0},
            {"TIMECRUISEUSA", "Infinite Balls", "1f0630:0a", 0},
            {"TIMECRUISEUSA", "Move Ball Anywhere", "1f0005:01", 0},
            {"TITANJAPAN", "Infinite Time", "1f0040:09+1f003f:99", 0},
            {"TOILETKIDS", "Infinite Lives", "1f088f:03", 0},
            {"TOILETKIDSJAPAN", "Infinite Continues", "1f0001:03", 0},
            {"TOILETKIDSJAPAN", "Infinite Energy", "1f008f:63", 0},
            {"TOILETKIDSJAPAN", "Infinite Poo", "1f008e:63", 0},
            {"TORAENOMICHIJAPAN", "Infinite Energy", "1f00d9:10", 0},
            {"TORAENOMICHIJAPAN", "Infinite Lives", "1f0cf7:09", 0},
            {"TOWEROFDRUAGATHEJAPAN", "Current HP (do not use with save states)", "1f008f:ff", 0},
            {"TOWEROFDRUAGATHEJAPAN", "Have Ankh", "1f1d30:04", 0},
            {"TOWEROFDRUAGATHEJAPAN", "Have Aquamarine Necklace", "1f1d2d:01", 0},
            {"TOWEROFDRUAGATHEJAPAN", "Have Blue Ring", "1f1d2f:01", 0},
            {"TOWEROFDRUAGATHEJAPAN", "Have Book of Keys", "1f1d27:01", 0},
            {"TOWEROFDRUAGATHEJAPAN", "Have Book of Light", "1f1d26:01", 0},
            {"TOWEROFDRUAGATHEJAPAN", "Have Candle", "1f1d25:02", 0},
            {"TOWEROFDRUAGATHEJAPAN", "Have Emerald Necklace", "1f1d2b:01", 0},
            {"TOWEROFDRUAGATHEJAPAN", "Have Floor Key (Deactivate to move on to the next le", "1f0058:01", 0},
            {"TOWEROFDRUAGATHEJAPAN", "Have Gold Chime", "1f1d2a:01", 0},
            {"TOWEROFDRUAGATHEJAPAN", "Have Gold Mirror", "1f1d33:01", 0},
            {"TOWEROFDRUAGATHEJAPAN", "Have Map Viewer", "1f1d28:01", 0},
            {"TOWEROFDRUAGATHEJAPAN", "Have Matches", "1f1d24:02", 0},
            {"TOWEROFDRUAGATHEJAPAN", "Have Mirror", "1f1d32:01", 0},
            {"TOWEROFDRUAGATHEJAPAN", "Have Red Mace", "1f1d31:01", 0},
            {"TOWEROFDRUAGATHEJAPAN", "Have Red Ring", "1f1d2e:01", 0},
            {"TOWEROFDRUAGATHEJAPAN", "Have Ruby Necklace", "1f1d2c:01", 0},
            {"TOWEROFDRUAGATHEJAPAN", "Have Silver Chime", "1f1d29:01", 0},
            {"TOWEROFDRUAGATHEJAPAN", "Invincibility", "1f0086:00", 0},
            {"TOWEROFDRUAGATHEJAPAN", "Max HP (do not use with save states)", "1f008e:ff", 0},
            {"TOYSHOPBOYSJAPAN", "Infinite Lives", "1f0beb:63", 0},
            {"TOYSHOPBOYSJAPAN", "Max Power", "1f0e3a:04", 0},
            {"TOYSHOPBOYSJAPAN", "Max Speed", "1f0e3b:04", 0},
            {"TRICKYJAPAN", "Infinite Time", "1f0b9e:05", 0},
            {"TRICKYJAPAN", "Press Select to Complete Level (MINDSIZE)", "1f0bd7:01", 0},
            {"TRICKYJAPAN", "Unlock All Normal Levels (EARTHIAN)", "1f0bd6:01", 0},
            {"TRICKYJAPAN", "Unlock All Special Levels (MILKYWAY)", "1f0ba6:01", 0},
            {"TRICKYKICKUSA", "Infinite Time", "1f0b9e:05", 0},
            {"TRICKYKICKUSA", "Press Select to Complete Level (MINDSIZE)", "1f0bd7:01", 0},
            {"TRICKYKICKUSA", "Unlock All Normal Levels (EARTHIAN)", "1f0bd6:01", 0},
            {"TRICKYKICKUSA", "Unlock All Special Levels (MILKYWAY)", "1f0ba6:01", 0},
            {"TURRICAN", "Infinite Crystals", "1f145c:63", 0},
            {"TURRICAN", "Infinite Lives", "1f1450:63", 0},
            {"TURRICAN", "Unlimited Time", "1f1458:2d", 0},
            {"TURRICANUSA", "Infinite Energy", "1f03d8:2f+1f03d9:5e+1f0c58:16", 0},
            {"TURRICANUSA", "Infinite Grenades", "1f0c60:99", 0},
            {"TURRICANUSA", "Infinite Lives", "1f0c50:99", 0},
            {"TURRICANUSA", "Infinite Power Line", "1f0c68:99", 0},
            {"TURRICANUSA", "Infinte Mines", "1f0c5c:99", 0},
            {"USAPROBASKETBALLJAPAN", "CPU Never Scores", "1f0ef8:00+1f0ef9:00", 0},
            {"VALISIICDUSA", "Infinite Health", "1f091e:73", 0},
            {"VALISIICDUSA", "Unlimited Health", "1f091e:04", 0},
            {"VALISIIICDUSA", "Infinite Energy", "1f038d:24", 0},
            {"VALISIIICDUSA", "Infinite Lives", "1f0393:02", 0},
            {"VALISIIICDUSA", "Infinite Magic", "1f038e:24", 0},
            {"VALISIIICDUSA", "Infinite Time", "1f104d:80", 0},
            {"VALISIIICDUSA", "Invincibility", "1f04eb:02", 0},
            {"VALISIIICDUSA", "Max Sword Beam", "1f0390:67+1f0391:67", 0},
            {"VALISIVTHEFANTASMSOLDIERCDJAPAN", "Automatically Skip Levels", "1f057d:82", 0},
            {"VALISIVTHEFANTASMSOLDIERCDJAPAN", "Infinite Energy", "1f0395:06", 0},
            {"VALISIVTHEFANTASMSOLDIERCDJAPAN", "Infinite Time", "1f0300:01", 0},
            {"VALISIVTHEFANTASMSOLDIERCDJAPAN", "Max Power Bar", "1f0397:12", 0},
            {"VALISIVTHEFANTASMSOLDIERCDJAPAN", "No Enemies/Objects", "1f0980:03", 0},
            {"VALKYRIENODENSETSUJAPAN", "Infinite Energy", "1f00bf:0e", 0},
            {"VALKYRIENODENSETSUJAPAN", "Infinite Gold", "1f00c4:ff+1f00c5:ff", 0},
            {"VALKYRIENODENSETSUJAPAN", "Invincibility", "1f09d8:14", 0},
            {"VEIGUESTACTICALGLADIATORJAPAN", "Infinite Shield/Health (Part 1)", "1f00b8:ff", 0},
            {"VEIGUESTACTICALGLADIATORJAPAN", "Infinite Venier (Part 1)", "1f00b5:ff", 0},
            {"VEIGUESTACTICALGLADIATORJAPAN", "Infinite Venier (Part 2)", "1f00b6:ff", 0},
            {"VEIGUESTACTICALGLADIATORUSA", "Infinite SLD (Shield/Health)", "1f00b8:ff+1f00b9:ff", 0},
            {"VEIGUESTACTICALGLADIATORUSA", "Infinite VNR (Venier)", "1f00b5:ff+1f00b6:ff", 0},
            {"VIGILANTEUSA", "1-Hit Boss Kill", "1f07dc:00", 0},
            {"VIGILANTEUSA", "Always Have Nunchaku", "1f0757:01", 0},
            {"VIGILANTEUSA", "Infinite Energy (turn off at end of level)", "1f07c9:70", 0},
            {"VIGILANTEUSA", "Infinite Lives", "1f0755:03", 0},
            {"VIGILANTEUSA", "Infinite Time (turn off at end of level)", "1f070f:9a", 0},
            {"VIOLENTSOLDIERJAPAN", "Infinite Lives", "1f19f3:0a", 0},
            {"VIOLENTSOLDIERJAPAN", "Invincibility", "1f09a8:00", 0},
            {"VIOLENTSOLDIERJAPAN", "Max Speed", "1f19f6:03", 0},
            {"VIOLENTSOLDIERJAPAN", "Max Upgrades", "1f19f7:02", 0},
            {"VOLFIEDJAPAN", "Infinite Lives", "1f1877:06", 0},
            {"WINDSOFTHUNDERSCDJAPAN", "Max Gold", "1f00b5:25+1f00b6:25", 0},
            {"WINDSOFTHUNDERSCDJAPAN", "Max Life", "1f0685:14", 0},
            {"WINDSOFTHUNDERSCDJAPAN", "Max Power", "1f0687:14", 0},
            {"WONDERMOMOJAPAN", "Default Momo outfit", "1f040c:00", 0},
            {"WONDERMOMOJAPAN", "Disable enemy collision", "1f041b:3c", 0},
            {"WONDERMOMOJAPAN", "Infinite health", "1f0220:7f", 0},
            {"WONDERMOMOJAPAN", "Infinite wonder", "1f0221:7f", 0},
            {"WONDERMOMOJAPAN", "No photographers", "1f05f0:00", 0},
            {"WONDERMOMOJAPAN", "One hit kills bosses", "1f04a7:17", 0},
            {"WONDERMOMOJAPAN", "Photographer stops and takes quick photos", "1f05f0:02", 0},
            {"WONDERMOMOJAPAN", "Photographer stops and takes stunning photos", "1f05f0:03", 0},
            {"WONDERMOMOJAPAN", "Spawn a photographer that sprints by", "1f05f0:04", 0},
            {"WONDERMOMOJAPAN", "Spawn a photographer that walks by", "1f05f0:01", 0},
            {"WONDERMOMOJAPAN", "Wonder Momo outfit", "1f040c:01", 0},
            {"WORLDHEROESIIACDJAPAN", "Infinite Time (Player Select)", "1f1f16:1e", 0},
            {"WORLDHEROESIIACDJAPAN", "Infinite Time + Bonus (Normal)", "1f0c08:99", 0},
            {"WORLDHEROESIIACDJAPAN", "No Time (Death Match)", "1f0c09:00", 0},
            {"WORLDHEROESIIACDJAPAN", "P1 Infinite Health", "1f180c:76+1f180d:76", 0},
            {"WORLDHEROESIIACDJAPAN", "P1 Instant Win (P2 Life Mod)", "1f190c:ff+1f190d:ff", 0},
            {"WRESTLINGUNIVERSEFIREPROJOSHIDOMECHOUJOTAISENWOWOWVSJWPACDJAPAN", "Instant 3 Count (Both Players)", "1f00b7:04", 0},
            {"WRINGTHEDOUBLERINGSJAPAN", "Infinite Lives", "1f15fe:09", 0},
            {"XAKIIISCDJAPAN", "Infinite Energy", "1f0f06:17", 0},
            {"XAKIIISCDJAPAN", "Infinite Gold", "1f0f18:25+1f0f19:25", 0},
            {"XAKIIISCDJAPAN", "Max Cash", "1f0f19:50", 0},
            {"XAKIIISCDJAPAN", "Quick Level Up", "1f0f1b:25", 0},
            {"XAKIIISCDJAPAN", "Stats Current Life", "1f0f06:25+1f0f07:38", 0},
            {"XAKIIISCDJAPAN", "Stats Max Armor", "1f0f12:25+1f0f13:38", 0},
            {"XAKIIISCDJAPAN", "Stats Max Defense", "1f0f10:25+1f0f11:38", 0},
            {"XAKIIISCDJAPAN", "Stats Max Life", "1f0f08:25+1f0f09:38", 0},
            {"XAKIIISCDJAPAN", "Stats Max Shield", "1f0f16:25+1f0f17:38", 0},
            {"XAKIIISCDJAPAN", "Stats Max Strength", "1f0f0e:25+1f0f0f:38", 0},
            {"XAKIIISCDJAPAN", "Stats Max Sword", "1f0f12:25+1f0f13:38", 0},
            {"XAKIIITHEETERNALRECURRENCESCDJAPAN", "Invincibility", "1f005f:00", 0},
            {"XAKIIITHEETERNALRECURRENCESCDJAPAN", "Max Money", "1f0303:55", 0},
            {"YOUKAIDOUCHUUKIJAPAN", "Infinite Energy", "1f0028:16", 0},
            {"YOUKAIDOUCHUUKIJAPAN", "Invincibility", "1f125b:09", 0},
            {"YOUKAIDOUCHUUKIJAPAN", "Lots of Cash", "1f123b:09", 0},
            {"YSBOOKIIICDUSA", "Have All Equipment", "1f0abf:25+1f0ac0:25+1f0ac1:25", 0},
            {"YSBOOKIIICDUSA", "Infinite Gold", "1f0c41:25+1f0c42:25", 0},
            {"YSBOOKIIICDUSA", "Infinite Health", "1f0c43:25", 0},
            {"YSBOOKIIICDUSA", "Max Defense", "1f0c47:25", 0},
            {"YSBOOKIIICDUSA", "Max HP", "1f0c48:25", 0},
            {"YSBOOKIIICDUSA", "Max Strength", "1f0c46:25", 0},
            {"YSIIIWANDERERSFROMYSCDUSA", "Have All Equipment", "1f0bdd:25+1f0bde:25+1f0bdf:25+1f0be0:25+1f0be1:25", 0},
            {"YSIIIWANDERERSFROMYSCDUSA", "Infinite Gold", "1f0d16:25+1f0d17:25", 0},
            {"YSIIIWANDERERSFROMYSCDUSA", "Infinite Health", "1f0d18:25", 0},
            {"YSIIIWANDERERSFROMYSCDUSA", "Infinite Ring", "1f0d23:25", 0},
            {"YSIIIWANDERERSFROMYSCDUSA", "Max Defense", "1f0d1d:25", 0},
            {"YSIIIWANDERERSFROMYSCDUSA", "Max Strength", "1f0d1e:25", 0},
            {"YUYUHAKUSHOSCDJAPAN", "Easy Enemy Kill", "1f100b:00", 0},
            {"YUYUHAKUSHOSCDJAPAN", "Infinite Balance Points (Disable once maxed to conti", "1f0637:99", 0},
            {"YUYUHAKUSHOSCDJAPAN", "Infinite Health", "1f1007:11", 0},
            {"YUYUHAKUSHOSCDJAPAN", "Infinite Spirit Shots", "1f1006:05", 0},
            {"ZERO4CHAMPJAPAN", "50 Stars in Turbo Go! Go!", "1f0645:50", 0},
            {"ZEROCHAMPJAPANV15", "50 Stars in Turbo Go! Go!", "1f0645:32", 0},
            {"ZEROWINGCDJAPAN", "Infinite Lives", "1f08a3:04", 0},
            {"ZIPANGJAPAN", "Infinite Elephants", "1f00ab:09", 0},
            {"ZIPANGJAPAN", "Infinite Life", "1f009f:99", 0},
            {"ZIPANGJAPAN", "Invincibility", "1f0604:00", 0},
          };
          #define PCE_CHEAT_DB_COUNT (sizeof(pce_cheat_db)/sizeof(pce_cheat_db[0]))
          #define PCE_CHEAT_RAM_BYTES 8192u
          #define PCE_CHEAT_MAX_GAME 64
          #define PCE_EXTERNAL_CHT_MAX_BYTES 16384u
          static PCECheat external_cheat_db[PCE_CHEAT_MAX_GAME];
          static char external_cheat_desc[PCE_CHEAT_MAX_GAME][96];
          static char external_cheat_code[PCE_CHEAT_MAX_GAME][64];
          static char external_cht_buffer[PCE_EXTERNAL_CHT_MAX_BYTES];
          static int external_cht_loaded = 0;
          /* V10.2: expose external CHT lookup failures directly in the cheat menu. */
          static char external_cht_debug[96] = "NOT CHECKED";
          static int external_cht_last_result = 0;
          static int active_cheat_indices[PCE_CHEAT_MAX_GAME];
          static unsigned int active_cheat_count = 0;
          #define PCE_CHEAT_MENU_ITEMS ((int)active_cheat_count + 2)
          static int cheat_menu_selected = 0;
          static void state_set_message(const char *message);
          static int parse_pce_ram_cheat_part(const char *code, size_t *offset_out, uint8_t *value_out);
          static PCECheat *get_active_cheat(unsigned int slot) {
            int index;
            if(slot>=active_cheat_count) return NULL;
            index=active_cheat_indices[slot];
            if(index >= (int)PCE_CHEAT_DB_COUNT) {
              index -= (int)PCE_CHEAT_DB_COUNT;
              if(index<0 || index>=PCE_CHEAT_MAX_GAME) return NULL;
              return &external_cheat_db[index];
            }
            if(index<0 || index>=(int)PCE_CHEAT_DB_COUNT) return NULL;
            return &pce_cheat_db[index];
          }

          static const char chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-/:._()[]";
static const unsigned long long glyphs[] = {
            0x004631fc62eULL,0x003e317c62fULL,0x0078210843eULL,0x003e318c62fULL,0x007c217843fULL,
            0x0004217843fULL,0x003a31e843eULL,0x004631fc631ULL,0x007c842109fULL,0x0019294211cULL,
            0x00452519531ULL,0x007c2108421ULL,0x004631ad771ULL,0x004631cd671ULL,0x003a318c62eULL,
            0x0004217c62fULL,0x0059358c62eULL,0x0045257c62fULL,0x003e107043eULL,0x0010842109fULL,
            0x003a318c631ULL,0x0011518c631ULL,0x004775ac631ULL,0x00462a22a31ULL,0x00108422a31ULL,
            0x007c222221fULL,0x007a3e83800ULL,0x003e319b421ULL,0x003a210f800ULL,0x007a31cda10ULL,
            0x00383f8b800ULL,0x00084238a4cULL,0x003a1e8c7c0ULL,0x0046319b421ULL,0x00388421804ULL,
            0x00192843008ULL,0x0024a32a421ULL,0x00388421086ULL,0x0056b5aac00ULL,0x0046319b400ULL,
            0x003a318b800ULL,0x00042f8c5e0ULL,0x00421e8c7c0ULL,0x0004219b400ULL,0x003e0e0f800ULL,
            0x00324211c42ULL,0x005b318c400ULL,0x0011518c400ULL,0x002ab58c400ULL,0x00454454400ULL,
            0x003a1e8c620ULL,0x007c4447c00ULL,0x003a33ae62eULL,0x003884210c4ULL,0x007c444422eULL,
            0x003e107420fULL,0x00211f4a988ULL,0x003e107843fULL,0x003a317842eULL,0x0008422221fULL,
            0x003a317462eULL,0x003a10f462eULL,0x000000f8000ULL,0x00042222210ULL,0x00008401080ULL,
            0x0018c000000ULL,0x00000000000ULL,0x0030821088cULL,0x00188842086ULL,0x0038421084eULL,
            0x0039084210eULL
          };
          static void label(int x,int y,int scale,const char *s,uint64_t color) {
            int i,r,c,j;
            for(i=0;s[i];i++) {
              char ch=s[i];
              unsigned long long bits=0;
              for(j=0;chars[j];j++) if(chars[j]==ch) {bits=glyphs[j];break;}
              for(r=0;r<7;r++) for(c=0;c<5;c++) if(bits&(1ULL << (r*5+c))) {
                float xx=(float)(x+(i*6+c)*scale), yy=(float)(y+r*scale);
                gsKit_prim_sprite(gs,xx,yy,xx+scale,yy+scale,1,color);
              }
            }
          }
          static void title_screen(const char *subtitle) {
            uint64_t bg=GS_SETREG_RGBAQ(12,20,35,0x80,0);
            uint64_t white=GS_SETREG_RGBAQ(230,240,245,0x80,0);
            uint64_t aqua=GS_SETREG_RGBAQ(50,210,175,0x80,0);
            gsKit_clear(gs,bg);
            draw_background();
            label(45,48,3,"PCE FAST PS2",white);
            label(45,99,2,subtitle,aqua);
            label(548,466,1,background_loaded?"BG PNG OK":"BG DEFAULT",aqua);
          }
          static void refresh_screen(void) { gsKit_queue_exec(gs); gsKit_sync_flip(gs); }
          static void pad_scan(void) {
            int s, n;
            buttons_prev=buttons_now;
            pad_read_ok=0;
            pad_read_len=0;
            if(!pad_ready) {
              pad_state_value=-1; pad_raw_buttons=0xffffu;
              buttons_now=0; buttons_edge=0; return;
            }
            s=padGetState(0,0);
            pad_state_value=s;
            if(s!=PAD_STATE_STABLE && s!=PAD_STATE_FINDCTP1) {
              pad_raw_buttons=0xffffu;
              buttons_now=0; buttons_edge=0; return;
            }
            n=(int)padRead(0,0,&pad_info);
            pad_read_len=n;
            if(n<=0) {
              pad_raw_buttons=0xffffu;
              buttons_now=0; buttons_edge=0; return;
            }
            pad_read_ok=1;
            pad_raw_buttons=(unsigned int)pad_info.btns & 0xffffu;
            buttons_now=(~pad_raw_buttons) & 0xffffu;
            buttons_edge=buttons_now & ~buttons_prev;
          }
          /* Browser-only hold-repeat: immediate first move, then 15 frames delay,
             repeat every 4 frames, accelerating to every 2 frames after 45 frames. */
          static int nav_repeat(unsigned int button) {
            static unsigned int up_frames=0, down_frames=0;
            unsigned int *frames = (button==PAD_UP) ? &up_frames : &down_frames;
            if(!(buttons_now & button)) { *frames=0; return 0; }
            if(buttons_edge & button) { *frames=0; return 1; }
            ++(*frames);
            if(*frames < 15u) return 0;
            if(*frames < 45u) return (((*frames-15u)%4u)==0u);
            return (((*frames-45u)%2u)==0u);
          }
          static int load_mod(void *address,unsigned int len) {
            int result=0, id=SifExecModuleBuffer(address,len,0,NULL,&result);
            return (id<0)?id:((result<0)?result:0);
          }
          static void usb_progress(const char *stage) {
            title_screen("V12 EXFAT AUDIO");
            label(52,210,2,stage,GS_SETREG_RGBAQ(50,210,175,0x80,0));
            refresh_screen();
          }
          static int usb_init(void) {
            int r;
            if(usb_initialized)return 0;
            usb_progress("INIT SIF / IOP");
            SifLoadFileInit(); SifInitIopHeap(); sbv_patch_enable_lmb(); iop_prepared=1;
            usb_progress("LOAD IOMANX");
            r=load_mod(iomanx_irx,size_iomanx_irx); if(r<0)return r;
            usb_progress("LOAD FILEXIO");
            r=load_mod(filexio_irx,size_filexio_irx); if(r<0)return r;
            usb_progress("INIT FILEXIO");
            r=fileXioInit(); if(r<0)return r;
            usb_progress("LOAD EXFAT USBD");
            r=load_mod(usbd_irx,size_usbd_irx); if(r<0)return r;
            usb_progress("LOAD EXFAT HDFSD");
            r=load_mod(usbhdfsd_irx,size_usbhdfsd_irx); if(r<0)return r;
            usb_initialized=1;
            load_background();
            usb_progress("EXFAT DRIVERS READY");
            return 0;
          }
          static int audio_init(unsigned requested_rate) {
            int r;
            struct audsrv_fmt_t fmt;
            if(audio_ready) return 0;
            if(!iop_prepared) {
              SifLoadFileInit(); SifInitIopHeap(); sbv_patch_enable_lmb(); iop_prepared=1;
            }
            if(!audio_module_loaded) {
              /* LIBSD is the PS2 IOP sound driver required by audsrv. */
              (void)SifLoadModule("rom0:LIBSD",0,NULL);
              r=load_mod(audsrv_irx,size_audsrv_irx);
              if(r<0) { audio_error=r; return r; }
              audio_module_loaded=1;
            }
            if(!audio_rpc_ready) {
              r=audsrv_init();
              if(r<0) { audio_error=r; return r; }
              audio_rpc_ready=1;
            }
            fmt.freq=(int)(requested_rate ? requested_rate : 44100);
            fmt.bits=16; fmt.channels=2;
            r=audsrv_set_format(&fmt);
            if(r<0 && fmt.freq!=44100) { fmt.freq=44100; r=audsrv_set_format(&fmt); }
            if(r<0 && fmt.freq!=22050) { fmt.freq=22050; r=audsrv_set_format(&fmt); }
            if(r<0) { audio_error=r; return r; }
            r=audsrv_set_volume(90);
            if(r<0) { audio_error=r; return r; }
            audio_rate=(unsigned)fmt.freq;
            audio_ready=1; audio_error=0;
            return 0;
          }
          static unsigned next_pow2(unsigned v) {
            unsigned n=1;
            while(n<v && n<TEX_SIZE)n<<=1;
            return n;
          }
          static int has_extension_ci(const char *name, const char *extension) {
            const char *dot;
            size_t n;
            if(!name || !extension) return 0;
            dot=strrchr(name,'.');
            if(!dot) return 0;
            n=strlen(extension);
            if(strlen(dot)!=n) return 0;
            while(*extension) {
              if(tolower((unsigned char)*dot++) != tolower((unsigned char)*extension++))
                return 0;
            }
            return 1;
          }
          static int is_pce(const char *name) { return has_extension_ci(name,".pce"); }
          static int is_zip(const char *name) { return has_extension_ci(name,".zip"); }
          static int is_zip_temp_rom(const char *name) {
            static const char prefix[] = "PCEFAST_ZIP_TMP";
            size_t i;
            if(!name) return 0;
            for(i=0; prefix[i]; ++i) {
              if(!name[i] || tolower((unsigned char)name[i]) != tolower((unsigned char)prefix[i])) return 0;
            }
            return 1;
          }
          static int cmp_entry(const void *pa,const void *pb) {
            const Entry *a=(const Entry *)pa,*b=(const Entry *)pb;
            if(a->dir != b->dir) return b->dir-a->dir;
            {
              int i;
              for(i=0;i<256;i++) {
                int ca=tolower((unsigned char)a->name[i]);
                int cb=tolower((unsigned char)b->name[i]);
                if(ca!=cb)return ca-cb;
                if(!ca)return 0;
              }
              return 0;
            }
          }
          static int scan_dir(void) {
            int d=fileXioDopen(folder),r;
            nentries=0; selected=0;
            if(d<0) return d;
            for(;;) {
              memset(&dirent_buf,0,sizeof(dirent_buf));
              r=fileXioDread(d,&dirent_buf);
              if(r<=0)break;
              dirent_buf.name[sizeof(dirent_buf.name)-1]=0;
              if(!strcmp(dirent_buf.name,".")||!strcmp(dirent_buf.name,".."))continue;
              /* ZIP extraction creates these temporary .PCE files; never show them as games. */
              if(is_zip_temp_rom(dirent_buf.name)) continue;
              if(FIO_S_ISDIR(dirent_buf.stat.mode) &&
                 (tolower((unsigned char)dirent_buf.name[0])=='i') &&
                 (tolower((unsigned char)dirent_buf.name[1])=='m') &&
                 (tolower((unsigned char)dirent_buf.name[2])=='a') &&
                 (tolower((unsigned char)dirent_buf.name[3])=='g') &&
                 (tolower((unsigned char)dirent_buf.name[4])=='e') &&
                 (tolower((unsigned char)dirent_buf.name[5])=='s') &&
                 dirent_buf.name[6]=='\0') continue;
              if(!FIO_S_ISDIR(dirent_buf.stat.mode) && !is_pce(dirent_buf.name) && !is_zip(dirent_buf.name))continue;
              if(nentries>=MAX_FILES)continue;
              strncpy(entries[nentries].name,dirent_buf.name,sizeof(entries[0].name)-1);
              entries[nentries].name[sizeof(entries[0].name)-1]=0;
              entries[nentries].dir=FIO_S_ISDIR(dirent_buf.stat.mode)?1:0;
              ++nentries;
            }
            fileXioDclose(d);
            qsort(entries,nentries,sizeof(entries[0]),cmp_entry);
            return r<0?r:0;
          }
          static void enter_parent(void) {
            size_t n=strlen(folder), root=!strncmp(folder,"mass0:/",7)?7:6;
            if(n<=root) {screen=0;return;}
            if(folder[n-1]=='/')--n;
            while(n>root&&folder[n-1]!='/')--n;
            folder[n]=0;
            status_code=scan_dir();
          }

/* --- 200x200 PNG game-cover support (RGB, RGBA, or indexed PNG; 8-bit, non-interlaced). --- */
static uint32_t png_be32(const unsigned char *p) {
  return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) |
         ((uint32_t)p[2] << 8) | (uint32_t)p[3];
}
static int png_paeth(int a, int b, int c) {
  int p=a+b-c, pa=abs(p-a), pb=abs(p-b), pc=abs(p-c);
  if(pa<=pb && pa<=pc) return a;
  if(pb<=pc) return b;
  return c;
}
static int read_cover_file(const char *path, unsigned char **out, size_t *out_size) {
  int fd,n;
  size_t size,off=0;
  unsigned char *data;
  if(!path || !out || !out_size) return -1;
  *out=NULL; *out_size=0;
  memset(&cover_stat_buf,0,sizeof(cover_stat_buf));
  if(fileXioGetStat(path,&cover_stat_buf)<0) return -1;
  if(cover_stat_buf.hisize || !cover_stat_buf.size ||
     cover_stat_buf.size>COVER_PNG_MAX_BYTES) return -2;
  size=(size_t)cover_stat_buf.size;
  data=(unsigned char *)malloc(size);
  if(!data) return -3;
  fd=fileXioOpen(path,FIO_O_RDONLY);
  if(fd<0) { free(data); return -4; }
  if(fileXioLseek(fd,0,FIO_SEEK_SET)!=0) {
    fileXioClose(fd); free(data); return -5;
  }
  while(off<size) {
    int want=(int)(size-off);
    if(want>(int)sizeof(readbuf)) want=(int)sizeof(readbuf);
    n=fileXioRead(fd,readbuf,want);
    if(n<=0 || n>want) {
      fileXioClose(fd); free(data); return -6;
    }
    memcpy(data+off,readbuf,(size_t)n);
    off+=(size_t)n;
  }
  if(fileXioClose(fd)<0) { free(data); return -7; }
  *out=data; *out_size=size;
  return 0;
}
static int decode_cover_png_200(const unsigned char *png, size_t png_size) {
  static const unsigned char signature[8]={137,80,78,71,13,10,26,10};
  unsigned char palette[768], palette_alpha[256];
  unsigned int palette_entries=0, palette_alpha_count=0;
  unsigned int width=0,height=0,bit_depth=0,color_type=0;
  unsigned int bytes_per_pixel=0;
  int got_ihdr=0,got_iend=0,ok=0;
  size_t pos=8,idat_size=0,row_bytes,raw_size,decoded_size;
  unsigned char *idat=NULL,*raw=NULL,*decoded=NULL;
  if(!png || png_size<8 || memcmp(png,signature,8)!=0) return 0;
  memset(palette,0,sizeof(palette));
  memset(palette_alpha,255,sizeof(palette_alpha));
  idat=(unsigned char *)malloc(png_size);
  if(!idat) return 0;
  while(pos<=png_size && png_size-pos>=12) {
    uint32_t length=png_be32(png+pos);
    const unsigned char *type=png+pos+4;
    const unsigned char *data=png+pos+8;
    uint32_t expected_crc,actual_crc;
    size_t chunk_total;
    if((size_t)length>png_size-pos-12u) goto done;
    chunk_total=12u+(size_t)length;
    expected_crc=png_be32(data+length);
    actual_crc=(uint32_t)crc32(0L,Z_NULL,0);
    actual_crc=(uint32_t)crc32(actual_crc,(const Bytef *)type,(uInt)(4u+length));
    if(actual_crc!=expected_crc) goto done;
    if(memcmp(type,"IHDR",4)==0) {
      if(got_ihdr || length!=13u || pos!=8u) goto done;
      width=png_be32(data); height=png_be32(data+4);
      bit_depth=data[8]; color_type=data[9];
      if(data[10]!=0 || data[11]!=0 || data[12]!=0) goto done;
      if(width!=200u || height!=200u || bit_depth!=8u) goto done;
      if(color_type!=0u && color_type!=2u && color_type!=3u &&
         color_type!=4u && color_type!=6u) goto done;
      if(color_type==2u) bytes_per_pixel=3u;
      else if(color_type==4u) bytes_per_pixel=2u;
      else if(color_type==6u) bytes_per_pixel=4u;
      else bytes_per_pixel=1u;
      got_ihdr=1;
    } else if(memcmp(type,"PLTE",4)==0) {
      if(!length || length>sizeof(palette) || (length%3u)!=0) goto done;
      memcpy(palette,data,length);
      palette_entries=(unsigned int)(length/3u);
    } else if(memcmp(type,"tRNS",4)==0) {
      if(length>sizeof(palette_alpha)) length=sizeof(palette_alpha);
      memcpy(palette_alpha,data,length);
      palette_alpha_count=(unsigned int)length;
    } else if(memcmp(type,"IDAT",4)==0) {
      if(!got_ihdr || (size_t)length>png_size-idat_size) goto done;
      memcpy(idat+idat_size,data,(size_t)length);
      idat_size+=(size_t)length;
    } else if(memcmp(type,"IEND",4)==0) {
      if(length!=0u) goto done;
      got_iend=1;
      pos+=chunk_total;
      break;
    }
    pos+=chunk_total;
  }
  if(!got_ihdr || !got_iend || !idat_size ||
     (color_type==3u && !palette_entries)) goto done;
  row_bytes=(size_t)width*bytes_per_pixel;
  raw_size=(row_bytes+1u)*(size_t)height;
  decoded_size=row_bytes*(size_t)height;
  raw=(unsigned char *)malloc(raw_size);
  decoded=(unsigned char *)malloc(decoded_size);
  if(!raw || !decoded) goto done;
  {
    uLongf output_size=(uLongf)raw_size;
    int zr=uncompress((Bytef *)raw,&output_size,(const Bytef *)idat,(uLong)idat_size);
    if(zr!=Z_OK || output_size!=(uLongf)raw_size) goto done;
  }
  {
    unsigned int y,x;
    for(y=0;y<height;y++) {
      const unsigned char *src=raw+(size_t)y*(row_bytes+1u)+1u;
      unsigned char filter=raw[(size_t)y*(row_bytes+1u)];
      unsigned char *dst=decoded+(size_t)y*row_bytes;
      const unsigned char *prev=y?decoded+(size_t)(y-1u)*row_bytes:NULL;
      if(filter>4u) goto done;
      for(x=0;x<row_bytes;x++) {
        int left=x>=bytes_per_pixel?dst[x-bytes_per_pixel]:0;
        int up=prev?prev[x]:0;
        int up_left=(prev && x>=bytes_per_pixel)?prev[x-bytes_per_pixel]:0;
        int predictor=0;
        if(filter==1u) predictor=left;
        else if(filter==2u) predictor=up;
        else if(filter==3u) predictor=(left+up)/2;
        else if(filter==4u) predictor=png_paeth(left,up,up_left);
        dst[x]=(unsigned char)(src[x]+predictor);
      }
    }
  }
  memset(cover_pixels,0,sizeof(cover_pixels));
  {
    unsigned int y,x;
    for(y=0;y<height;y++) {
      const unsigned char *row=decoded+(size_t)y*row_bytes;
      for(x=0;x<width;x++) {
        unsigned int r,g,b,a=255u;
        if(color_type==0u) {
          r=g=b=row[x];
        } else if(color_type==2u) {
          r=row[x*3u]; g=row[x*3u+1u]; b=row[x*3u+2u];
        } else if(color_type==4u) {
          r=g=b=row[x*2u]; a=row[x*2u+1u];
        } else if(color_type==6u) {
          r=row[x*4u]; g=row[x*4u+1u]; b=row[x*4u+2u]; a=row[x*4u+3u];
        } else {
          unsigned int index=row[x];
          if(index>=palette_entries) goto done;
          r=palette[index*3u]; g=palette[index*3u+1u]; b=palette[index*3u+2u];
          if(index<palette_alpha_count) a=palette_alpha[index];
        }
        if(a<128u) cover_pixels[(size_t)y*COVER_TEX_SIZE+x]=0;
        else cover_pixels[(size_t)y*COVER_TEX_SIZE+x]=(uint16_t)(
          0x8000u | ((r>>3)&31u) | (((g>>3)&31u)<<5) | (((b>>3)&31u)<<10));
      }
    }
  }
  ok=1;
done:
  if(idat) free(idat);
  if(raw) free(raw);
  if(decoded) free(decoded);
  return ok;
}
static int try_cover_path(const char *path) {
  unsigned char *data=NULL;
  size_t size=0;
  int r=read_cover_file(path,&data,&size);
  if(r<0) {
    if(r!=-1) cover_error=1;
    return 0;
  }
  r=decode_cover_png_200(data,size);
  free(data);
  if(!r) { cover_error=1; return 0; }
  if(!cover_tex_ready) { cover_error=1; return 0; }
  gsKit_texture_upload(gs,&cover_tex);
  cover_loaded=1;
  return 1;
}

/* Read and decode the optional 640x480 background; failure keeps the blue fallback. */
static int read_background_file(const char *path, unsigned char **out, size_t *out_size) {
  int fd,n;
  size_t size,off=0;
  unsigned char *data;
  if(!path || !out || !out_size) return -1;
  *out=NULL; *out_size=0;
  memset(&background_stat_buf,0,sizeof(background_stat_buf));
  if(fileXioGetStat(path,&background_stat_buf)<0) return -1;
  if(background_stat_buf.hisize || !background_stat_buf.size ||
     background_stat_buf.size>BACKGROUND_PNG_MAX_BYTES) return -2;
  size=(size_t)background_stat_buf.size;
  data=(unsigned char *)malloc(size);
  if(!data) return -3;
  fd=fileXioOpen(path,FIO_O_RDONLY);
  if(fd<0) { free(data); return -4; }
  if(fileXioLseek(fd,0,FIO_SEEK_SET)!=0) {
    fileXioClose(fd); free(data); return -5;
  }
  while(off<size) {
    int want=(int)(size-off);
    if(want>(int)sizeof(readbuf)) want=(int)sizeof(readbuf);
    n=fileXioRead(fd,readbuf,want);
    if(n<=0 || n>want) {
      fileXioClose(fd); free(data); return -6;
    }
    memcpy(data+off,readbuf,(size_t)n);
    off+=(size_t)n;
  }
  if(fileXioClose(fd)<0) { free(data); return -7; }
  *out=data; *out_size=size;
  return 0;
}
static int decode_background_png_640(const unsigned char *png, size_t png_size) {
  static const unsigned char signature[8]={137,80,78,71,13,10,26,10};
  unsigned char palette[768], palette_alpha[256];
  unsigned int palette_entries=0, palette_alpha_count=0;
  unsigned int width=0,height=0,bit_depth=0,color_type=0;
  unsigned int bytes_per_pixel=0;
  int got_ihdr=0,got_iend=0,ok=0;
  size_t pos=8,idat_size=0,row_bytes,raw_size,decoded_size;
  unsigned char *idat=NULL,*raw=NULL,*decoded=NULL;
  if(!png || png_size<8 || memcmp(png,signature,8)!=0) return 0;
  memset(palette,0,sizeof(palette));
  memset(palette_alpha,255,sizeof(palette_alpha));
  idat=(unsigned char *)malloc(png_size);
  if(!idat) return 0;
  while(pos<=png_size && png_size-pos>=12) {
    uint32_t length=png_be32(png+pos);
    const unsigned char *type=png+pos+4;
    const unsigned char *data=png+pos+8;
    uint32_t expected_crc,actual_crc;
    size_t chunk_total;
    if((size_t)length>png_size-pos-12u) goto done;
    chunk_total=12u+(size_t)length;
    expected_crc=png_be32(data+length);
    actual_crc=(uint32_t)crc32(0L,Z_NULL,0);
    actual_crc=(uint32_t)crc32(actual_crc,(const Bytef *)type,(uInt)(4u+length));
    if(actual_crc!=expected_crc) goto done;
    if(memcmp(type,"IHDR",4)==0) {
      if(got_ihdr || length!=13u || pos!=8u) goto done;
      width=png_be32(data); height=png_be32(data+4);
      bit_depth=data[8]; color_type=data[9];
      if(data[10]!=0 || data[11]!=0 || data[12]!=0) goto done;
      if(width!=640u || height!=480u || bit_depth!=8u) goto done;
      if(color_type!=0u && color_type!=2u && color_type!=3u &&
         color_type!=4u && color_type!=6u) goto done;
      if(color_type==2u) bytes_per_pixel=3u;
      else if(color_type==4u) bytes_per_pixel=2u;
      else if(color_type==6u) bytes_per_pixel=4u;
      else bytes_per_pixel=1u;
      got_ihdr=1;
    } else if(memcmp(type,"PLTE",4)==0) {
      if(!length || length>sizeof(palette) || (length%3u)!=0) goto done;
      memcpy(palette,data,length);
      palette_entries=(unsigned int)(length/3u);
    } else if(memcmp(type,"tRNS",4)==0) {
      if(length>sizeof(palette_alpha)) length=sizeof(palette_alpha);
      memcpy(palette_alpha,data,length);
      palette_alpha_count=(unsigned int)length;
    } else if(memcmp(type,"IDAT",4)==0) {
      if(!got_ihdr || (size_t)length>png_size-idat_size) goto done;
      memcpy(idat+idat_size,data,(size_t)length);
      idat_size+=(size_t)length;
    } else if(memcmp(type,"IEND",4)==0) {
      if(length!=0u) goto done;
      got_iend=1;
      pos+=chunk_total;
      break;
    }
    pos+=chunk_total;
  }
  if(!got_ihdr || !got_iend || !idat_size ||
     (color_type==3u && !palette_entries)) goto done;
  row_bytes=(size_t)width*bytes_per_pixel;
  raw_size=(row_bytes+1u)*(size_t)height;
  decoded_size=row_bytes*(size_t)height;
  raw=(unsigned char *)malloc(raw_size);
  decoded=(unsigned char *)malloc(decoded_size);
  if(!raw || !decoded) goto done;
  {
    uLongf output_size=(uLongf)raw_size;
    int zr=uncompress((Bytef *)raw,&output_size,(const Bytef *)idat,(uLong)idat_size);
    if(zr!=Z_OK || output_size!=(uLongf)raw_size) goto done;
  }
  {
    unsigned int y,x;
    for(y=0;y<height;y++) {
      const unsigned char *src=raw+(size_t)y*(row_bytes+1u)+1u;
      unsigned char filter=raw[(size_t)y*(row_bytes+1u)];
      unsigned char *dst=decoded+(size_t)y*row_bytes;
      const unsigned char *prev=y?decoded+(size_t)(y-1u)*row_bytes:NULL;
      if(filter>4u) goto done;
      for(x=0;x<row_bytes;x++) {
        int left=x>=bytes_per_pixel?dst[x-bytes_per_pixel]:0;
        int up=prev?prev[x]:0;
        int up_left=(prev && x>=bytes_per_pixel)?prev[x-bytes_per_pixel]:0;
        int predictor=0;
        if(filter==1u) predictor=left;
        else if(filter==2u) predictor=up;
        else if(filter==3u) predictor=(left+up)/2;
        else if(filter==4u) predictor=png_paeth(left,up,up_left);
        dst[x]=(unsigned char)(src[x]+predictor);
      }
    }
  }
  memset(background_pixels,0,sizeof(background_pixels));
  {
    unsigned int y,x;
    for(y=0;y<height;y++) {
      const unsigned char *row=decoded+(size_t)y*row_bytes;
      for(x=0;x<width;x++) {
        unsigned int r,g,b,a=255u;
        if(color_type==0u) {
          r=g=b=row[x];
        } else if(color_type==2u) {
          r=row[x*3u]; g=row[x*3u+1u]; b=row[x*3u+2u];
        } else if(color_type==4u) {
          r=g=b=row[x*2u]; a=row[x*2u+1u];
        } else if(color_type==6u) {
          r=row[x*4u]; g=row[x*4u+1u]; b=row[x*4u+2u]; a=row[x*4u+3u];
        } else {
          unsigned int index=row[x];
          if(index>=palette_entries) goto done;
          r=palette[index*3u]; g=palette[index*3u+1u]; b=palette[index*3u+2u];
          if(index<palette_alpha_count) a=palette_alpha[index];
        }
        if(a<128u) background_pixels[(size_t)y*BACKGROUND_TEX_W+x]=0;
        else background_pixels[(size_t)y*BACKGROUND_TEX_W+x]=(uint16_t)(
          0x8000u | ((r>>3)&31u) | (((g>>3)&31u)<<5) | (((b>>3)&31u)<<10));
      }
    }
  }
  ok=1;
done:
  if(idat) free(idat);
  if(raw) free(raw);
  if(decoded) free(decoded);
  return ok;
}
static int try_background_path(const char *path) {
  unsigned char *data=NULL;
  size_t size=0;
  int r;
  if(!background_tex_ready) { background_error=1; return 0; }
  r=read_background_file(path,&data,&size);
  if(r<0) {
    if(r!=-1) background_error=1;
    return 0;
  }
  r=decode_background_png_640(data,size);
  free(data);
  if(!r) { background_error=1; return 0; }
  gsKit_texture_upload(gs,&background_tex);
  background_loaded=1;
  background_error=0;
  return 1;
}
static void load_background(void) {
  if(background_checked) return;
  background_checked=1;
  background_loaded=0;
  background_error=0;
  if(try_background_path("mass:/PCEFAST/background.png")) return;
  if(try_background_path("mass0:/PCEFAST/background.png")) return;
}
static void draw_background(void) {
  if(background_loaded && background_tex_ready) {
    gsKit_prim_sprite_texture(gs,&background_tex,
      0.0f,0.0f,0.0f,0.0f,640.0f,480.0f,640.0f,480.0f,1,
      GS_SETREG_RGBAQ(0x80,0x80,0x80,0x80,0));
  }
}

static void normalize_cover_key(const char *input, char *out, size_t cap) {
  char temp[256];
  const char *name, *p;
  char *dot;
  size_t n, used=0;
  if(!out || !cap) return;
  out[0]='\0';
  if(!input) return;
  name=strrchr(input,'/');
  name=name?name+1:input;
  strncpy(temp,name,sizeof(temp)-1);
  temp[sizeof(temp)-1]='\0';
  dot=strrchr(temp,'.');
  if(dot) *dot='\0';
  while(temp[0] && isspace((unsigned char)temp[0]))
    memmove(temp,temp+1,strlen(temp));
  n=strlen(temp);
  while(n && isspace((unsigned char)temp[n-1])) temp[--n]='\0';
  /* ROM dumps often have a leading "R " marker that cover filenames omit. */
  if((temp[0]=='R' || temp[0]=='r') &&
     (temp[1]==' ' || temp[1]=='_' || temp[1]=='\t')) {
    memmove(temp,temp+2,strlen(temp+2)+1);
  }
  for(p=temp; *p && used+1<cap; ++p) {
    unsigned char ch=(unsigned char)*p;
    /* Ignore separators so spaces, underscores and hyphens all match. */
    if(isalnum(ch)) out[used++]=(char)toupper(ch);
  }
  out[used]='\0';
}
static int try_cover_in_dir(const char *dir,const char *base) {
  int d,r;
  iox_dirent_t image_entry __attribute__((aligned(64)));
  char wanted[256],candidate[256],path[MAX_PATH],matched[256];
  int n;
  matched[0]='\0';
  normalize_cover_key(base,wanted,sizeof(wanted));
  if(!wanted[0]) {
    strncpy(cover_debug,"EMPTY COVER KEY",sizeof(cover_debug)-1);
    cover_debug[sizeof(cover_debug)-1]='\0';
    return 0;
  }
  d=fileXioDopen(dir);
  if(d<0) {
    snprintf(cover_debug,sizeof(cover_debug),"DIR OPEN FAIL");
    return 0;
  }
  for(;;) {
    memset(&image_entry,0,sizeof(image_entry));
    r=fileXioDread(d,&image_entry);
    if(r<=0) break;
    if(FIO_S_ISDIR(image_entry.stat.mode)) continue;
    if(!has_extension_ci(image_entry.name,".png")) continue;
    normalize_cover_key(image_entry.name,candidate,sizeof(candidate));
    if(candidate[0] && strcmp(wanted,candidate)==0) {
      strncpy(matched,image_entry.name,sizeof(matched)-1);
      matched[sizeof(matched)-1]='\0';
      break;
    }
  }
  fileXioDclose(d);
  if(!matched[0]) {
    snprintf(cover_debug,sizeof(cover_debug),"NO MATCH: %.60s",wanted);
    return 0;
  }
  n=snprintf(path,sizeof(path),"%s%s",dir,matched);
  if(n<0 || n>=(int)sizeof(path)) {
    strncpy(cover_debug,"COVER PATH TOO LONG",sizeof(cover_debug)-1);
    cover_debug[sizeof(cover_debug)-1]='\0';
    return 0;
  }
  if(try_cover_path(path)) {
    snprintf(cover_debug,sizeof(cover_debug),"PNG FOUND");
    return 1;
  }
  cover_error=1;
  snprintf(cover_debug,sizeof(cover_debug),"PNG INVALID/UNSUPPORTED");
  return 0;
}
static int load_selected_cover(void) {
  char base[256],root_dir[MAX_PATH],local_dir[MAX_PATH];
  const char *name,*slash,*dot,*root;
  size_t n;
  if(nentries<=0 || selected<0 || selected>=nentries || entries[selected].dir) return 0;
  if(!is_pce(entries[selected].name) && !is_zip(entries[selected].name)) return 0;
  name=entries[selected].name;
  slash=strrchr(name,'/');
  if(slash) name=slash+1;
  strncpy(base,name,sizeof(base)-1);
  base[sizeof(base)-1]='\0';
  dot=strrchr(base,'.');
  if(dot) *((char *)dot)='\0';
  n=strlen(base);
  while(n && (base[n-1]==' ' || base[n-1]=='.')) base[--n]='\0';
  if(!n) return 0;
  root=!strncmp(folder,"mass0:/",7)?"mass0:/":"mass:/";
  {
    int nr=snprintf(root_dir,sizeof(root_dir),"%simages/",root);
    int nl=snprintf(local_dir,sizeof(local_dir),"%simages/",folder);
    if(nr<0 || nr>=(int)sizeof(root_dir) ||
       nl<0 || nl>=(int)sizeof(local_dir)) return 0;
  }
  if(try_cover_in_dir(root_dir,base)) return 1;
  if(strcmp(local_dir,root_dir)!=0 && try_cover_in_dir(local_dir,base)) return 1;
  return 0;
}
static void update_cover_for_selection(void) {
  char key[MAX_PATH];
  int n;
  if(nentries<=0 || selected<0 || selected>=nentries) {
    cover_key[0]='\0'; cover_loaded=0; cover_error=0;
    strncpy(cover_debug,"NO GAME SELECTED",sizeof(cover_debug)-1);
    cover_debug[sizeof(cover_debug)-1]='\0';
    return;
  }
  n=snprintf(key,sizeof(key),"%s%s",folder,entries[selected].name);
  if(n<0 || n>=(int)sizeof(key)) {
    cover_loaded=0; cover_error=1; cover_key[0]='\0'; return;
  }
  if(strcmp(key,cover_key)==0) return;
  strncpy(cover_key,key,sizeof(cover_key)-1);
  cover_key[sizeof(cover_key)-1]='\0';
  cover_loaded=0; cover_error=0;
  (void)load_selected_cover();
}
static void display_entry_title(int index,char *out,size_t cap) {
  const char *dot;
  const char *suffix=NULL;
  size_t n,i;
  char upper[256];
  if(!out || !cap) return;
  out[0]='\0';
  if(index<0 || index>=nentries) return;
  strncpy(out,entries[index].name,cap-1);
  out[cap-1]='\0';
  if(!entries[index].dir && (is_pce(out) || is_zip(out))) {
    dot=strrchr(out,'.');
    if(dot) out[(size_t)(dot-out)]='\0';
  }
  n=strlen(out);
  while(n && (out[n-1]==' ' || out[n-1]=='.')) out[--n]='\0';
  if(!entries[index].dir && (out[0]=='R' || out[0]=='r') &&
     (out[1]==' ' || out[1]=='_' || out[1]=='	'))
    memmove(out,out+2,strlen(out+2)+1);
  n=strlen(out);
  while(n && (out[n-1]==' ' || out[n-1]=='.')) out[--n]='\0';

  /* Friendly title for Splatterhouse, independent of original filename case. */
  for(i=0;i<n && i<sizeof(upper)-1;i++)
    upper[i]=(char)toupper((unsigned char)out[i]);
  upper[i]='\0';
  if(!entries[index].dir &&
     strstr(upper,"SPLATTERHOUSE") && strstr(upper,"JAPAN")) {
    strncpy(out,"Splatterhouse (Japan)",cap-1);
    out[cap-1]='\0';
  }

  /* Identify the file format in the menu without changing the actual path. */
  if(!entries[index].dir && is_pce(entries[index].name)) suffix=" [PCE]";
  else if(!entries[index].dir && is_zip(entries[index].name)) suffix=" [ZIP]";
  if(suffix && strlen(out)<cap-1)
    strncat(out,suffix,cap-strlen(out)-1);
}
static void render_cover(void) {
  uint64_t aqua=GS_SETREG_RGBAQ(50,210,175,0x80,0);
  uint64_t white=GS_SETREG_RGBAQ(230,240,245,0x80,0);
  uint64_t frame=GS_SETREG_RGBAQ(50,210,175,0x80,0);
  uint64_t background=GS_SETREG_RGBAQ(12,20,35,0x80,0);
  gsKit_prim_sprite(gs,382.0f,147.0f,598.0f,363.0f,1,frame);
  gsKit_prim_sprite(gs,386.0f,151.0f,594.0f,359.0f,1,background);
  if(cover_loaded && cover_tex_ready) {
    gsKit_prim_sprite_texture(gs,&cover_tex,
      390.0f,155.0f,0.0f,0.0f,590.0f,355.0f,200.0f,200.0f,1,
      GS_SETREG_RGBAQ(0x80,0x80,0x80,0x80,0));
  } else {
    const char *message="NO COVER";
    if(nentries>0 && selected>=0 && selected<nentries && entries[selected].dir)
      message="FOLDER";
    else if(cover_error) message="PNG ERROR";
    label(414,248,2,message,aqua);
  }
  label(382,370,1,cover_debug,aqua);
}

static void render_browser(void) {
  int first=selected-4,i;
  uint64_t white=GS_SETREG_RGBAQ(230,240,245,0x80,0);
  uint64_t aqua=GS_SETREG_RGBAQ(50,210,175,0x80,0);
  char msg[64];
  update_cover_for_selection();
  title_screen("SELECT GAME");
  if(first<0) first=0;
  if(first+9>nentries) first=nentries-9;
  if(first<0) first=0;
  for(i=first;i<nentries && i<first+9;i++) {
    display_entry_title(i,msg,sizeof(msg));
    label(24,154+(i-first)*27,2,msg,i==selected?aqua:white);
  }
  if(nentries==0) label(24,210,2,"NO PCE OR ZIP FILES",white);
  render_cover();
  if(status_code<0) {
    snprintf(msg,sizeof(msg),"LOAD ERROR %d",status_code);
    label(24,390,1,msg,aqua);
  }
  label(24,415,1,"UP/DOWN HOLD L/R +/-10 X OPEN O BACK",aqua);
}
          static int contains_ci(const char *text,const char *needle) {
            size_t n;
            if(!text || !needle) return 0;
            n=strlen(needle);
            if(!n) return 1;
            for(;*text;text++) {
              size_t i=0;
              while(i<n && text[i] &&
                    tolower((unsigned char)text[i])==tolower((unsigned char)needle[i])) i++;
              if(i==n) return 1;
            }
            return 0;
          }
          static void normalize_game_key(const char *path, char *out, size_t cap) {
            const char *base;
            const char *dot;
            size_t n=0;
            if(!out || cap==0) return;
            out[0]='\0';
            if(!path) return;
            base=strrchr(path,'/');
            base=base?base+1:path;
            dot=strrchr(base,'.');
            while(*base && (!dot || base<dot) && n+1<cap) {
              unsigned char ch=(unsigned char)*base++;
              if((ch>='A'&&ch<='Z')||(ch>='a'&&ch<='z')||(ch>='0'&&ch<='9'))
                out[n++]=(char)toupper(ch);
            }
            out[n]='\0';
          }
          static void parse_external_cht_line(char *line) {
            char *p=line,*digits,*value,*quote_end;
            char *target=NULL;
            size_t cap=0,n;
            long index;
            while(*p && isspace((unsigned char)*p)) p++;
            if(strncmp(p,"cheat",5)!=0) return;
            digits=p+5;
            if(!isdigit((unsigned char)*digits)) return;
            index=strtol(digits,&p,10);
            if(index<0 || index>=PCE_CHEAT_MAX_GAME) return;
            if(strncmp(p,"_desc",5)==0) { target=external_cheat_desc[index]; cap=sizeof(external_cheat_desc[index]); p+=5; }
            else if(strncmp(p,"_code",5)==0) { target=external_cheat_code[index]; cap=sizeof(external_cheat_code[index]); p+=5; }
            else return;
            while(*p && isspace((unsigned char)*p)) p++;
            if(*p++!='=') return;
            while(*p && isspace((unsigned char)*p)) p++;
            if(*p!='"') return;
            value=++p;
            quote_end=strchr(value,'"');
            if(!quote_end) return;
            n=(size_t)(quote_end-value);
            if(n>=cap) n=cap-1;
            memcpy(target,value,n); target[n]='\0';
          }
          static int external_code_is_valid(const char *code) {
            const char *cursor=code;
            if(!cursor || !*cursor) return 0;
            while(*cursor) {
              const char *plus=strchr(cursor,'+');
              size_t part_len=plus?(size_t)(plus-cursor):strlen(cursor);
              char part[16]; size_t offset; uint8_t value;
              if(!part_len || part_len>=sizeof(part)) return 0;
              memcpy(part,cursor,part_len); part[part_len]='\0';
              if(!parse_pce_ram_cheat_part(part,&offset,&value)) return 0;
              if(!plus) break;
              cursor=plus+1;
              if(!*cursor) return 0;
            }
            return 1;
          }
          static int read_external_cht(const char *path) {
            int fd,n;
            size_t size,off=0;
            char *line,*next;
            unsigned int i,loaded=0;
            external_cht_last_result=0;
            if(!path || !*path) { external_cht_last_result=1; return 0; }
            memset(&stat_buf,0,sizeof(stat_buf));
            if(fileXioGetStat(path,&stat_buf)<0) { external_cht_last_result=1; return 0; }
            if(stat_buf.hisize || !stat_buf.size || stat_buf.size>=sizeof(external_cht_buffer)) {
              external_cht_last_result=2; return 0;
            }
            size=(size_t)stat_buf.size;
            fd=fileXioOpen(path,FIO_O_RDONLY);
            if(fd<0) { external_cht_last_result=3; return 0; }
            if(fileXioLseek(fd,0,FIO_SEEK_SET)!=0) {
              fileXioClose(fd); external_cht_last_result=4; return 0;
            }
            while(off<size) {
              int want=(int)(size-off);
              if(want>(int)sizeof(readbuf)) want=(int)sizeof(readbuf);
              n=fileXioRead(fd,readbuf,want);
              if(n<=0 || n>want) {
                fileXioClose(fd); external_cht_last_result=5; return 0;
              }
              memcpy(external_cht_buffer+off,readbuf,(size_t)n);
              off+=(size_t)n;
            }
            if(fileXioClose(fd)<0) { external_cht_last_result=5; return 0; }
            external_cht_buffer[size]='\0';
            memset(external_cheat_desc,0,sizeof(external_cheat_desc));
            memset(external_cheat_code,0,sizeof(external_cheat_code));
            memset(external_cheat_db,0,sizeof(external_cheat_db));
            line=external_cht_buffer;
            while(line && *line) {
              next=strchr(line,'\n');
              if(next) *next='\0';
              { size_t len=strlen(line); if(len && line[len-1]=='\r') line[len-1]='\0'; }
              parse_external_cht_line(line);
              if(!next) break;
              line=next+1;
            }
            for(i=0;i<PCE_CHEAT_MAX_GAME;i++) {
              if(!external_cheat_desc[i][0] || !external_code_is_valid(external_cheat_code[i])) continue;
              external_cheat_db[i].game_key="EXTERNAL";
              external_cheat_db[i].desc=external_cheat_desc[i];
              external_cheat_db[i].code=external_cheat_code[i];
              external_cheat_db[i].enabled=0;
              loaded++;
            }
            if(loaded) {
              external_cht_loaded=1;
              external_cht_last_result=7;
            } else {
              external_cht_last_result=6;
            }
            return (int)loaded;
          }
          static int load_external_cht_file(void) {
            char candidates[5][MAX_PATH];
            const char *labels[5]={"M:PCE","M0:PCE","M:ROOT","M0:ROOT","LOCAL"};
            const char *base,*dot,*slash;
            size_t base_len,dir_len,used;
            int n,i,loaded;
            external_cht_loaded=0;
            external_cht_last_result=0;
            memset(external_cheat_desc,0,sizeof(external_cheat_desc));
            memset(external_cheat_code,0,sizeof(external_cheat_code));
            memset(external_cheat_db,0,sizeof(external_cheat_db));
            if(!game_path[0]) {
              strncpy(external_cht_debug,"EXT CHT: NO GAME PATH",sizeof(external_cht_debug)-1);
              external_cht_debug[sizeof(external_cht_debug)-1]='\0';
              return 0;
            }
            slash=strrchr(game_path,'/');
            base=slash?slash+1:game_path;
            dot=strrchr(base,'.');
            base_len=dot?(size_t)(dot-base):strlen(base);
            if(!base_len || base_len>240) {
              strncpy(external_cht_debug,"EXT CHT: BAD GAME NAME",sizeof(external_cht_debug)-1);
              external_cht_debug[sizeof(external_cht_debug)-1]='\0';
              return 0;
            }
            /* Try both PS2 USB aliases regardless of which alias opened the ROM.
               Some USB driver builds expose the same device through only one alias. */
            n=snprintf(candidates[0],sizeof(candidates[0]),"mass:/PCEFAST/cheats/%.*s.cht",(int)base_len,base);
            if(n<0 || n>=(int)sizeof(candidates[0])) candidates[0][0]='\0';
            n=snprintf(candidates[1],sizeof(candidates[1]),"mass0:/PCEFAST/cheats/%.*s.cht",(int)base_len,base);
            if(n<0 || n>=(int)sizeof(candidates[1])) candidates[1][0]='\0';
            n=snprintf(candidates[2],sizeof(candidates[2]),"mass:/cheats/%.*s.cht",(int)base_len,base);
            if(n<0 || n>=(int)sizeof(candidates[2])) candidates[2][0]='\0';
            n=snprintf(candidates[3],sizeof(candidates[3]),"mass0:/cheats/%.*s.cht",(int)base_len,base);
            if(n<0 || n>=(int)sizeof(candidates[3])) candidates[3][0]='\0';
            candidates[4][0]='\0';
            if(slash) {
              dir_len=(size_t)(slash-game_path)+1u;
              n=snprintf(candidates[4],sizeof(candidates[4]),"%.*scheats/%.*s.cht",(int)dir_len,game_path,(int)base_len,base);
              if(n<0 || n>=(int)sizeof(candidates[4])) candidates[4][0]='\0';
            }
            strncpy(external_cht_debug,"EXT CHT:",sizeof(external_cht_debug)-1);
            external_cht_debug[sizeof(external_cht_debug)-1]='\0';
            for(i=0;i<5;i++) {
              const char *result;
              if(!candidates[i][0]) {
                result="NA";
              } else {
                loaded=read_external_cht(candidates[i]);
                if(loaded>0) {
                  snprintf(external_cht_debug,sizeof(external_cht_debug),"EXT CHT: OK %s %d",labels[i],loaded);
                  return 1;
                }
                switch(external_cht_last_result) {
                  case 1: result="MISS"; break;
                  case 2: result="SIZE"; break;
                  case 3: result="OPEN"; break;
                  case 4: result="SEEK"; break;
                  case 5: result="READ"; break;
                  case 6: result="BAD"; break;
                  default: result="FAIL"; break;
                }
              }
              used=strlen(external_cht_debug);
              if(used<sizeof(external_cht_debug)-1)
                snprintf(external_cht_debug+used,sizeof(external_cht_debug)-used," %s:%s",labels[i],result);
            }
            external_cht_loaded=0;
            memset(external_cheat_desc,0,sizeof(external_cheat_desc));
            memset(external_cheat_code,0,sizeof(external_cheat_code));
            memset(external_cheat_db,0,sizeof(external_cheat_db));
            return 0;
          }
          static void load_game_cheats(void) {
            unsigned int i;
            char key[MAX_PATH];
            for(i=0;i<PCE_CHEAT_DB_COUNT;i++) pce_cheat_db[i].enabled=0;
            for(i=0;i<PCE_CHEAT_MAX_GAME;i++) external_cheat_db[i].enabled=0;
            active_cheat_count=0;
            normalize_game_key(game_path,key,sizeof(key));
            if(!key[0]) { state_set_message("NO CHT FOR GAME"); return; }
            if(load_external_cht_file()) {
              for(i=0;i<PCE_CHEAT_MAX_GAME;i++) {
                if(external_cheat_desc[i][0] && external_code_is_valid(external_cheat_code[i]) &&
                   active_cheat_count<PCE_CHEAT_MAX_GAME)
                  active_cheat_indices[active_cheat_count++]=(int)PCE_CHEAT_DB_COUNT+(int)i;
              }
              if(active_cheat_count) { state_set_message("EXTERNAL CHT LOADED"); return; }
            }
            for(i=0;i<PCE_CHEAT_DB_COUNT;i++) {
              if(strcmp(key,pce_cheat_db[i].game_key)==0 && active_cheat_count<PCE_CHEAT_MAX_GAME)
                active_cheat_indices[active_cheat_count++]=(int)i;
            }
            state_set_message(active_cheat_count?"BUILT-IN CHT LOADED":"NO CHT FOR GAME");
          }
          static int parse_pce_ram_cheat_part(const char *code, size_t *offset_out, uint8_t *value_out) {
            char address_text[7];
            char value_text[3];
            char *end;
            unsigned long address, value;
            if(!code || !offset_out || !value_out || strlen(code)!=9 ||
               tolower((unsigned char)code[0])!='1' ||
               tolower((unsigned char)code[1])!='f' || code[6]!=':') return 0;
            memcpy(address_text,code,6); address_text[6]='\0';
            value_text[0]=code[7]; value_text[1]=code[8]; value_text[2]='\0';
            address=strtoul(address_text,&end,16);
            if(end==address_text || *end!='\0' || address<0x1f0000UL || address>=0x1f2000UL) return 0;
            value=strtoul(value_text,&end,16);
            if(end==value_text || *end!='\0' || value>0xffUL) return 0;
            *offset_out=(size_t)(address & 0x1fffUL);
            *value_out=(uint8_t)value;
            return *offset_out<PCE_CHEAT_RAM_BYTES;
          }
          static int any_cheats_enabled(void) {
            unsigned int i;
            for(i=0;i<active_cheat_count;i++)
              if(get_active_cheat(i) && get_active_cheat(i)->enabled) return 1;
            return 0;
          }
          /* Apply validated HuC6280 RAM writes directly. The tested PS2 build must
             not call retro_cheat_set/reset: that API path previously froze on PS2. */
          static int apply_enabled_cheats(int debug) {
            unsigned int i, applied=0;
            unsigned char *ram;
            size_t ram_size;
            (void)debug;
            if(!any_cheats_enabled()) return 1;
            if(!core_loaded) return 0;
            ram=(unsigned char *)retro_get_memory_data(RETRO_MEMORY_SYSTEM_RAM);
            if(!ram) return 0;
            ram_size=retro_get_memory_size(RETRO_MEMORY_SYSTEM_RAM);
            if(ram_size<PCE_CHEAT_RAM_BYTES) return 0;
            for(i=0;i<active_cheat_count;i++) {
              PCECheat *cheat=get_active_cheat(i);
              const char *cursor;
              if(!cheat) return 0;
              if(!cheat->enabled) continue;
              cursor=cheat->code;
              while(cursor && *cursor) {
                const char *plus=strchr(cursor,'+');
                size_t part_len=plus?(size_t)(plus-cursor):strlen(cursor);
                char part[16];
                size_t offset;
                uint8_t value;
                if(part_len>=sizeof(part)) return 0;
                memcpy(part,cursor,part_len); part[part_len]='\0';
                if(!parse_pce_ram_cheat_part(part,&offset,&value) || offset>=ram_size) return 0;
                ram[offset]=value;
                applied++;
                if(!plus) break;
                cursor=plus+1;
              }
            }
            (void)applied;
            return 1;
          }
          static void disable_all_cheats(void) {
            unsigned int i;
            for(i=0;i<PCE_CHEAT_DB_COUNT;i++) pce_cheat_db[i].enabled=0;
            for(i=0;i<PCE_CHEAT_MAX_GAME;i++) external_cheat_db[i].enabled=0;
            state_set_message("ALL CHEATS OFF");
          }
          static void unload_game(void) {
            unsigned int i;
            video_frame_updated=0;
            if(core_loaded) {
              retro_unload_game();
              core_loaded=0;
            }
            if(zip_temp_path[0]) {
              (void)fileXioRemove(zip_temp_path);
              zip_temp_path[0]='\0';
            }
            for(i=0;i<PCE_CHEAT_DB_COUNT;i++) pce_cheat_db[i].enabled=0;
            for(i=0;i<PCE_CHEAT_MAX_GAME;i++) external_cheat_db[i].enabled=0;
            active_cheat_count=0;
            external_cht_loaded=0;
            if(game_data) {free(game_data);game_data=NULL;}
            game_size=0;
            video_received=0;
          }
          static uint16_t zip_u16(const unsigned char *p) {
            return (uint16_t)((uint16_t)p[0] | ((uint16_t)p[1] << 8));
          }
          static uint32_t zip_u32(const unsigned char *p) {
            return (uint32_t)p[0] | ((uint32_t)p[1] << 8) |
                   ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
          }
          static int zip_member_is_pce(const unsigned char *name, size_t n) {
            if(!name || n<4) return 0;
            return name[n-4]=='.' &&
              tolower((unsigned char)name[n-3])=='p' &&
              tolower((unsigned char)name[n-2])=='c' &&
              tolower((unsigned char)name[n-1])=='e';
          }
          /* Supports standard single-disk ZIP files with one .pce member, using
             stored (method 0) or raw DEFLATE (method 8). ZIP64/encrypted entries
             and multi-volume archives are deliberately rejected with an error code. */
          static int extract_pce_from_zip(const unsigned char *zip, size_t zip_size) {
            size_t min_eocd, eocd, cd_off, cd_size, cd_end, pos;
            uint16_t entries, i;
            if(!zip || zip_size<22) return -200;
            min_eocd=zip_size>65557u ? zip_size-65557u : 0u;
            eocd=zip_size-22u;
            for(;;) {
              if(zip_u32(zip+eocd)==0x06054b50u) break;
              if(eocd==min_eocd) return -201;
              --eocd;
            }
            if(eocd+22u>zip_size || eocd+22u+(size_t)zip_u16(zip+eocd+20u)>zip_size)
              return -202;
            if(zip_u16(zip+eocd+4u)!=0 || zip_u16(zip+eocd+6u)!=0 ||
               zip_u16(zip+eocd+8u)!=zip_u16(zip+eocd+10u)) return -203;
            entries=zip_u16(zip+eocd+10u);
            cd_size=(size_t)zip_u32(zip+eocd+12u);
            cd_off=(size_t)zip_u32(zip+eocd+16u);
            if(entries==0xffffu || cd_size==0xffffffffu || cd_off==0xffffffffu)
              return -204; /* ZIP64 is not supported in this first ZIP build. */
            if(cd_off>zip_size || cd_size>zip_size-cd_off) return -205;
            cd_end=cd_off+cd_size;
            if(cd_end>eocd) return -206;
            pos=cd_off;
            for(i=0;i<entries;i++) {
              uint16_t flags, method, name_len, extra_len, comment_len, disk_start;
              uint32_t crc_expected, comp_size32, uncomp_size32, local_off32;
              size_t entry_len, local_off, data_off, comp_size, uncomp_size;
              const unsigned char *name;
              if(pos>cd_end || cd_end-pos<46u || zip_u32(zip+pos)!=0x02014b50u)
                return -207;
              flags=zip_u16(zip+pos+8u);
              method=zip_u16(zip+pos+10u);
              crc_expected=zip_u32(zip+pos+16u);
              comp_size32=zip_u32(zip+pos+20u);
              uncomp_size32=zip_u32(zip+pos+24u);
              name_len=zip_u16(zip+pos+28u);
              extra_len=zip_u16(zip+pos+30u);
              comment_len=zip_u16(zip+pos+32u);
              disk_start=zip_u16(zip+pos+34u);
              local_off32=zip_u32(zip+pos+42u);
              entry_len=46u+(size_t)name_len+(size_t)extra_len+(size_t)comment_len;
              if(entry_len>cd_end-pos) return -208;
              name=zip+pos+46u;
              pos+=entry_len;
              if(!zip_member_is_pce(name,name_len)) continue;
              if((flags&1u)!=0 || disk_start!=0) return -209;
              if(comp_size32==0xffffffffu || uncomp_size32==0xffffffffu ||
                 local_off32==0xffffffffu) return -210;
              comp_size=(size_t)comp_size32;
              uncomp_size=(size_t)uncomp_size32;
              local_off=(size_t)local_off32;
              if(!uncomp_size || uncomp_size>ROM_LIMIT || comp_size>ROM_LIMIT)
                return -211;
              if(local_off>zip_size || zip_size-local_off<30u ||
                 zip_u32(zip+local_off)!=0x04034b50u) return -212;
              data_off=local_off+30u+(size_t)zip_u16(zip+local_off+26u)+
                       (size_t)zip_u16(zip+local_off+28u);
              if(data_off>zip_size || comp_size>zip_size-data_off) return -213;
              game_data=(unsigned char *)malloc(uncomp_size);
              if(!game_data) return -214;
              if(method==0) {
                if(comp_size!=uncomp_size) { free(game_data); game_data=NULL; return -215; }
                memcpy(game_data,zip+data_off,uncomp_size);
              } else if(method==8) {
                z_stream stream;
                int zr;
                memset(&stream,0,sizeof(stream));
                stream.next_in=(Bytef *)(zip+data_off);
                stream.avail_in=(uInt)comp_size;
                stream.next_out=(Bytef *)game_data;
                stream.avail_out=(uInt)uncomp_size;
                zr=inflateInit2(&stream,-MAX_WBITS);
                if(zr!=Z_OK) { free(game_data); game_data=NULL; return -216; }
                zr=inflate(&stream,Z_FINISH);
                inflateEnd(&stream);
                if(zr!=Z_STREAM_END || stream.total_out!=(uLong)uncomp_size) {
                  free(game_data); game_data=NULL; return -217;
                }
              } else {
                free(game_data); game_data=NULL; return -218;
              }
              {
                uLong calculated_crc=crc32(0L,Z_NULL,0);
                calculated_crc=crc32(calculated_crc,(const Bytef *)game_data,(uInt)uncomp_size);
                if((uint32_t)calculated_crc!=crc_expected) {
                  free(game_data); game_data=NULL; return -219;
                }
              }
              game_size=uncomp_size;
              if(name_len>=sizeof(game_core_path)) {
                free(game_data); game_data=NULL; game_size=0; return -220;
              }
              memcpy(game_core_path,name,name_len);
              game_core_path[name_len]='\0';
              return 0;
            }
            return -221; /* ZIP opened, but no .pce cartridge was found. */
          }
          /* Beetle PCE Fast reports need_fullpath=true, so a ZIP member must be
   written to a real .PCE path before retro_load_game() can open it. */
static int write_zip_temp_rom(const char *archive_path,const unsigned char *data,size_t size) {
  char directory[MAX_PATH],candidate[MAX_PATH];
  char *slash;
  unsigned int index;
  size_t off;
  int fd,n,written;
  if(!archive_path || !data || !size || size>ROM_LIMIT) return -300;
  if(strlen(archive_path)>=sizeof(directory)) return -301;
  strcpy(directory,archive_path);
  slash=strrchr(directory,'/');
  if(!slash) return -302;
  slash[1]='\0';
  for(index=0;index<100;index++) {
    written=snprintf(candidate,sizeof(candidate),"%sPCEFAST_ZIP_TMP%02u.PCE",directory,index);
    if(written<0 || written>=(int)sizeof(candidate)) return -303;
    memset(&stat_buf,0,sizeof(stat_buf));
    if(fileXioGetStat(candidate,&stat_buf)>=0) continue;
    fd=fileXioOpen(candidate,FIO_O_WRONLY|FIO_O_CREAT|FIO_O_TRUNC);
    if(fd<0) return -304;
    off=0;
    while(off<size) {
      int want=(int)(size-off);
      if(want>(int)sizeof(readbuf)) want=(int)sizeof(readbuf);
      n=fileXioWrite(fd,(void *)(data+off),want);
      if(n<=0 || n>want) {
        fileXioClose(fd);
        fileXioRemove(candidate);
        return -305;
      }
      off+=(size_t)n;
    }
    if(fileXioClose(fd)<0) {
      fileXioRemove(candidate);
      return -306;
    }
    strncpy(zip_temp_path,candidate,sizeof(zip_temp_path)-1);
    zip_temp_path[sizeof(zip_temp_path)-1]='\0';
    return 0;
  }
  return -307;
}
static int read_full_game(const char *path) {
            int fd,n;
            size_t off=0, sz;
            unsigned char *file_data;
            memset(&stat_buf,0,sizeof(stat_buf));
            n=fileXioGetStat(path,&stat_buf);
            if(n<0)return n;
            if(stat_buf.hisize || !stat_buf.size || stat_buf.size>ROM_LIMIT)return -100;
            sz=(size_t)stat_buf.size;
            file_data=(unsigned char *)malloc(sz);
            if(!file_data)return -101;
            fd=fileXioOpen(path,FIO_O_RDONLY);
            if(fd<0){free(file_data);return fd;}
            if(fileXioLseek(fd,0,FIO_SEEK_SET)!=0) {
              fileXioClose(fd); free(file_data); return -102;
            }
            while(off<sz) {
              int want=(int)(sz-off);
              if(want>(int)sizeof(readbuf))want=(int)sizeof(readbuf);
              n=fileXioRead(fd,readbuf,want);
              if(n<=0 || n>want) {
                fileXioClose(fd); free(file_data); return n<0?n:-103;
              }
              memcpy(file_data+off,readbuf,(size_t)n);
              off+=(size_t)n;
            }
            n=fileXioClose(fd);
            if(n<0){free(file_data);return n;}
            if(is_zip(path)) {
              n=extract_pce_from_zip(file_data,sz);
              free(file_data);
              if(n<0) return n;
              return 0;
            }
            game_data=file_data;
            game_size=sz;
            strncpy(game_core_path,path,sizeof(game_core_path)-1);
            game_core_path[sizeof(game_core_path)-1]='\0';
            return 0;
          }
          static uint32_t state_hash_bytes(const unsigned char *data, size_t size) {
            uint32_t h = 2166136261u;
            size_t i;
            for(i=0;i<size;i++) { h ^= data[i]; h *= 16777619u; }
            return h;
          }
          static uint32_t state_game_hash(void) {
            const char *p = game_path;
            const char *colon = strchr(game_path, ':');
            uint32_t h = 2166136261u;
            if(colon && colon[1]=='/') p = colon + 2; /* Ignore mass:/ vs mass0:/ alias. */
            while(*p) {
              unsigned char c = (unsigned char)tolower((unsigned char)*p++);
              h ^= c; h *= 16777619u;
            }
            return h;
          }
          static void state_set_message(const char *message) {
            if(!message) message = "";
            strncpy(state_message, message, sizeof(state_message)-1);
            state_message[sizeof(state_message)-1] = 0;
            state_message_frames = state_message[0] ? 180 : 0;
          }
          static int state_make_paths(int slot, char *dir1, size_t dir1_cap,
                                      char *dir2, size_t dir2_cap,
                                      char *path, size_t path_cap) {
            const char *root;
            const char *base;
            const char *dot;
            char slug[64];
            size_t j=0;
            int n;
            if(slot<0 || slot>=PCE_STATE_SLOTS || !game_path[0]) return -1;
            root = !strncmp(game_path,"mass0:/",7) ? "mass0:/" : "mass:/";
            n=snprintf(dir1,dir1_cap,"%sPCEFAST",root);
            if(n<0 || (size_t)n>=dir1_cap) return -2;
            n=snprintf(dir2,dir2_cap,"%sPCEFAST/STATES",root);
            if(n<0 || (size_t)n>=dir2_cap) return -3;
            base=strrchr(game_path,'/'); base=base?base+1:game_path;
            dot=strrchr(base,'.');
            while(*base && base!=dot && j<sizeof(slug)-1) {
              unsigned char c=(unsigned char)*base++;
              if(isalnum(c)) slug[j++]=(char)toupper(c);
              else if(j && slug[j-1]!='_') slug[j++]='_';
            }
            while(j && slug[j-1]=='_') --j;
            if(!j) { slug[0]='G'; slug[1]='A'; slug[2]='M'; slug[3]='E'; j=4; }
            slug[j]=0;
            n=snprintf(path,path_cap,"%sPCEFAST/STATES/%s_%08X.slot%d",
                       root,slug,(unsigned int)state_game_hash(),slot+1);
            if(n<0 || (size_t)n>=path_cap) return -4;
            return 0;
          }
          static int state_ensure_directory(const char *path) {
            int d=fileXioDopen(path);
            if(d>=0) { fileXioDclose(d); return 0; }
            (void)fileXioMkdir(path,0777);
            d=fileXioDopen(path);
            if(d<0) return d;
            fileXioDclose(d);
            return 0;
          }
          static int state_ensure_directories(const char *dir1,const char *dir2) {
            if(state_ensure_directory(dir1)<0) return -1;
            if(state_ensure_directory(dir2)<0) return -2;
            return 0;
          }
          static int state_write_exact(int fd,const void *buffer,size_t size) {
            const unsigned char *p=(const unsigned char *)buffer;
            while(size) {
              int chunk=(size>(size_t)16384)?16384:(int)size;
              int n=fileXioWrite(fd,(void *)p,chunk);
              if(n<=0 || n>chunk) return -1;
              p+=(size_t)n; size-=(size_t)n;
            }
            return 0;
          }
          static int state_read_exact(int fd,void *buffer,size_t size) {
            unsigned char *p=(unsigned char *)buffer;
            while(size) {
              int chunk=(size>(size_t)16384)?16384:(int)size;
              int n=fileXioRead(fd,p,chunk);
              if(n<=0 || n>chunk) return -1;
              p+=(size_t)n; size-=(size_t)n;
            }
            return 0;
          }
          static int state_save_slot(int slot) {
            char dir1[MAX_PATH],dir2[MAX_PATH],path[MAX_PATH],tmp[MAX_PATH];
            size_t size;
            unsigned char *payload;
            PCEStateHeader header;
            int fd,r;
            if(!core_loaded) { state_set_message("NO GAME LOADED"); return -1; }
            size=retro_serialize_size();
            if(!size || size>PCE_STATE_MAX_BYTES) { state_set_message("SAVE STATE UNSUPPORTED"); return -2; }
            payload=(unsigned char *)malloc(size);
            if(!payload) { state_set_message("SAVE STATE OUT OF MEMORY"); return -3; }
            if(!retro_serialize(payload,size)) {
              free(payload); state_set_message("SAVE STATE FAILED"); return -4;
            }
            r=state_make_paths(slot,dir1,sizeof(dir1),dir2,sizeof(dir2),path,sizeof(path));
            if(r<0 || state_ensure_directories(dir1,dir2)<0) {
              free(payload); state_set_message("STATE USB DIRECTORY ERROR"); return -5;
            }
            if(snprintf(tmp,sizeof(tmp),"%s.tmp",path)<0 || strlen(path)+4>=sizeof(tmp)) {
              free(payload); state_set_message("STATE PATH TOO LONG"); return -6;
            }
            memset(&header,0,sizeof(header));
            memcpy(header.magic,"PCESTATE",8);
            header.version=PCE_STATE_VERSION;
            header.game_hash=state_game_hash();
            header.payload_size=(uint32_t)size;
            header.payload_hash=state_hash_bytes(payload,size);
            header.turbo_i_counter=turbo_i_counter;
            header.turbo_ii_counter=turbo_ii_counter;
            fd=fileXioOpen(tmp,FIO_O_WRONLY|FIO_O_CREAT|FIO_O_TRUNC);
            if(fd<0) { free(payload); state_set_message("STATE FILE OPEN ERROR"); return -7; }
            r=state_write_exact(fd,&header,sizeof(header));
            if(r==0) r=state_write_exact(fd,payload,size);
            if(fileXioClose(fd)<0) r=-1;
            free(payload);
            if(r<0) { fileXioRemove(tmp); state_set_message("STATE WRITE ERROR"); return -8; }
            (void)fileXioRemove(path);
            if(fileXioRename(tmp,path)<0) {
              fileXioRemove(tmp); state_set_message("STATE RENAME ERROR"); return -9;
            }
            state_set_message("STATE SAVED");
            return 0;
          }
          static int state_load_slot(int slot) {
            char dir1[MAX_PATH],dir2[MAX_PATH],path[MAX_PATH];
            PCEStateHeader header;
            size_t expected;
            unsigned char *payload;
            int fd,r;
            if(!core_loaded) { state_set_message("NO GAME LOADED"); return -1; }
            expected=retro_serialize_size();
            if(!expected || expected>PCE_STATE_MAX_BYTES) { state_set_message("LOAD STATE UNSUPPORTED"); return -2; }
            r=state_make_paths(slot,dir1,sizeof(dir1),dir2,sizeof(dir2),path,sizeof(path));
            if(r<0) { state_set_message("STATE PATH ERROR"); return -3; }
            memset(&stat_buf,0,sizeof(stat_buf));
            if(fileXioGetStat(path,&stat_buf)<0 || stat_buf.hisize || stat_buf.size<sizeof(header)) {
              state_set_message("STATE SLOT EMPTY"); return -4;
            }
            fd=fileXioOpen(path,FIO_O_RDONLY);
            if(fd<0) { state_set_message("STATE OPEN ERROR"); return -5; }
            r=state_read_exact(fd,&header,sizeof(header));
            if(r<0) { fileXioClose(fd); state_set_message("STATE HEADER ERROR"); return -6; }
            if(memcmp(header.magic,"PCESTATE",8)!=0 || header.version!=PCE_STATE_VERSION ||
               header.game_hash!=state_game_hash() || !header.payload_size ||
               header.payload_size>PCE_STATE_MAX_BYTES || header.payload_size!=expected ||
               (uint64_t)sizeof(header)+(uint64_t)header.payload_size!=(uint64_t)stat_buf.size) {
              fileXioClose(fd); state_set_message("STATE INCOMPATIBLE"); return -7;
            }
            payload=(unsigned char *)malloc((size_t)header.payload_size);
            if(!payload) { fileXioClose(fd); state_set_message("LOAD STATE OUT OF MEMORY"); return -8; }
            r=state_read_exact(fd,payload,(size_t)header.payload_size);
            if(fileXioClose(fd)<0) r=-1;
            if(r<0 || state_hash_bytes(payload,(size_t)header.payload_size)!=header.payload_hash) {
              free(payload); state_set_message("STATE CORRUPT"); return -9;
            }
            if(!retro_unserialize(payload,(size_t)header.payload_size)) {
              free(payload); state_set_message("STATE RESTORE FAILED"); return -10;
            }
            free(payload);
            turbo_i_counter=header.turbo_i_counter;
            turbo_ii_counter=header.turbo_ii_counter;
            turbo_i_active=0; turbo_ii_active=0; turbo_updated_this_frame=0;
            video_received=0; video_frame_updated=0;
            state_set_message("STATE LOADED");
            return 0;
          }
          static void render_state_menu(void) {
            int i;
            char item[48];
            uint64_t white=GS_SETREG_RGBAQ(230,240,245,0x80,0);
            uint64_t aqua=GS_SETREG_RGBAQ(50,210,175,0x80,0);
            title_screen("SAVE / LOAD STATE");
            label(30,119,1,"UP DOWN X SELECT O BACK",aqua);
            for(i=0;i<13;i++) {
              if(i<PCE_STATE_SLOTS) snprintf(item,sizeof(item),"SAVE SLOT %d",i+1);
              else if(i<PCE_STATE_SLOTS*2) snprintf(item,sizeof(item),"LOAD SLOT %d",i-PCE_STATE_SLOTS+1);
              else if(i==10) snprintf(item,sizeof(item),"RESUME GAME");
              else if(i==11) snprintf(item,sizeof(item),"CHEAT MENU");
              else snprintf(item,sizeof(item),"EXIT TO BROWSER");
              label(54,142+i*20,2,item,i==state_menu_selected?aqua:white);
            }
            if(state_message_frames>0 && state_message[0]) label(20,420,1,state_message,aqua);
          }
          static void state_menu_activate(void) {
            if(state_menu_selected<PCE_STATE_SLOTS) {
              (void)state_save_slot(state_menu_selected);
            } else if(state_menu_selected<PCE_STATE_SLOTS*2) {
              (void)state_load_slot(state_menu_selected-PCE_STATE_SLOTS);
            } else if(state_menu_selected==10) {
              screen=2; buttons_prev=buttons_now; buttons_edge=0;
            } else if(state_menu_selected==11) {
              screen=4; cheat_menu_selected=0;
              state_set_message(active_cheat_count?"CHTS FOUND":"NO CHT FOR GAME");
              buttons_prev=buttons_now; buttons_edge=0;
            } else {
              unload_game(); screen=1; buttons_prev=buttons_now; buttons_edge=0;
            }
          }
          static void cheat_menu_activate(void) {
            if(cheat_menu_selected<(int)active_cheat_count) {
              PCECheat *cheat=get_active_cheat((unsigned int)cheat_menu_selected);
              int was_enabled;
              if(!cheat) { state_set_message("CHEAT INDEX ERROR"); return; }
              was_enabled=cheat->enabled;
              cheat->enabled=!was_enabled;
              if(!apply_enabled_cheats(0)) {
                if(!was_enabled) cheat->enabled=0;
                state_set_message("CHEAT RAM ERROR");
                return;
              }
              state_set_message(cheat->enabled?"CHEAT ENABLED":"CHEAT DISABLED");
            } else if(cheat_menu_selected==(int)active_cheat_count) {
              disable_all_cheats();
            } else {
              screen=3; buttons_prev=buttons_now; buttons_edge=0;
            }
          }
          static void render_cheat_menu(void) {
            int i,first;
            char item[64];
            uint64_t white=GS_SETREG_RGBAQ(230,240,245,0x80,0);
            uint64_t aqua=GS_SETREG_RGBAQ(50,210,175,0x80,0);
            title_screen("GAME CHEATS");
            label(12,120,1,"UP DOWN X TOGGLE O BACK",aqua);
            if(active_cheat_count==0) label(12,136,1,"NO CHT FOR THIS GAME",aqua);
            else {
              snprintf(item,sizeof(item),"%s CHT: %u",external_cht_loaded?"EXTERNAL":"BUILT-IN",active_cheat_count);
              label(12,136,1,item,aqua);
            }
            label(12,148,1,external_cht_debug,aqua);
            first=cheat_menu_selected-4;
            if(first<0) first=0;
            if(first>PCE_CHEAT_MENU_ITEMS-9) first=PCE_CHEAT_MENU_ITEMS-9;
            if(first<0) first=0;
            for(i=first;i<PCE_CHEAT_MENU_ITEMS && i<first+9;i++) {
              if(i<(int)active_cheat_count) {
                PCECheat *cheat=get_active_cheat((unsigned int)i);
                if(!cheat) snprintf(item,sizeof(item),"CHEAT ERROR");
                else snprintf(item,sizeof(item),"%s %s",cheat->enabled?"ON":"OFF",cheat->desc);
              } else if(i==(int)active_cheat_count)
                snprintf(item,sizeof(item),"DISABLE ALL CHEATS");
              else
                snprintf(item,sizeof(item),"BACK TO STATE MENU");
              label(12,170+(i-first)*24,1,item,i==cheat_menu_selected?aqua:white);
            }
            if(state_message_frames>0 && state_message[0]) label(12,400,1,state_message,aqua);
            label(12,420,1,"X TOGGLE O BACK",aqua);
          }
          static void core_log_printf(enum retro_log_level level, const char *fmt, ...) {
  va_list ap;
  char message[160];
  va_start(ap,fmt);
  vsnprintf(message,sizeof(message),fmt,ap);
  va_end(ap);
  snprintf(core_last_log,sizeof(core_last_log),"L%d: %.150s",(int)level,message);
}
static bool core_environment(unsigned command,void *data) {
            switch(command) {
              case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT:
                pixel_format=*(const enum retro_pixel_format *)data;
                return pixel_format==RETRO_PIXEL_FORMAT_RGB565 ||
                       pixel_format==RETRO_PIXEL_FORMAT_XRGB8888 ||
                       pixel_format==RETRO_PIXEL_FORMAT_0RGB1555;
              case RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY:
                *(const char **)data="mass:/SYSTEM";return true;
              case RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY:
                *(const char **)data="mass:/SAVES";return true;
              case RETRO_ENVIRONMENT_GET_CAN_DUPE:
                *(bool *)data=true;return true;
          #ifdef RETRO_ENVIRONMENT_GET_LOG_INTERFACE
              case RETRO_ENVIRONMENT_GET_LOG_INTERFACE:
                if(data) {
                  ((struct retro_log_callback *)data)->log=core_log_printf;
                  return true;
                }
                return false;
          #endif
              case RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE:
                *(bool *)data=false;return true;
              case RETRO_ENVIRONMENT_GET_VARIABLE:
                return false; /* Let the core use its defaults. */
              case RETRO_ENVIRONMENT_SET_VARIABLES:
              case RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS:
              case RETRO_ENVIRONMENT_SET_CONTROLLER_INFO:
                return true;
          #ifdef RETRO_ENVIRONMENT_GET_AUDIO_VIDEO_ENABLE
              case RETRO_ENVIRONMENT_GET_AUDIO_VIDEO_ENABLE:
                *(int *)data=3;return true; /* Enable both video (1) and audio (2). */
          #endif
              default:return false;
            }
          }
          static void video_cb(const void *data,unsigned width,unsigned height,size_t pitch) {
            unsigned x,y,tw,th;
            if(!data || width==0 || height==0 || width>TEX_SIZE || height>TEX_SIZE)return;
            if(pixel_format==RETRO_PIXEL_FORMAT_XRGB8888) {
              if(pitch < (size_t)width * 4u)return;
            } else if(pitch < (size_t)width * 2u) return;

            frame_w=width; frame_h=height;
            tw=next_pow2(width); th=next_pow2(height);
            tex.Width=tw; tex.Height=th;

            if(pixel_format==RETRO_PIXEL_FORMAT_RGB565) {
              /* In this verified Aurora build, RGB565 is the API label only:
               * AURORA_PS2_PCE_FAST makes the source pixels native GS A1B5G5R5.
               * Copy rows directly into a PSMCT16 texture; no per-pixel conversion. */
              for(y=0;y<height;y++) {
                const uint8_t *row=(const uint8_t *)data+(size_t)y*pitch;
                memcpy(pixels16+(size_t)y*tw,row,(size_t)width*sizeof(uint16_t));
              }
            } else if(pixel_format==RETRO_PIXEL_FORMAT_XRGB8888) {
              for(y=0;y<height;y++) {
                const uint32_t *row=(const uint32_t *)((const uint8_t *)data+(size_t)y*pitch);
                uint16_t *dst=pixels16+(size_t)y*tw;
                for(x=0;x<width;x++) {
                  uint32_t p=row[x];
                  unsigned r=(p>>19)&31u, g=(p>>11)&31u, b=(p>>3)&31u;
                  dst[x]=(uint16_t)(0x8000u|r|(g<<5)|(b<<10));
                }
              }
            } else {
              /* Standard Libretro 0RGB1555 -> GS-native A1B5G5R5. */
              for(y=0;y<height;y++) {
                const uint16_t *row=(const uint16_t *)((const uint8_t *)data+(size_t)y*pitch);
                uint16_t *dst=pixels16+(size_t)y*tw;
                for(x=0;x<width;x++) {
                  uint16_t p=row[x];
                  unsigned r=(p>>10)&31u, g=(p>>5)&31u, b=p&31u;
                  dst[x]=(uint16_t)(0x8000u|r|(g<<5)|(b<<10));
                }
              }
            }
            video_received=1;
            video_frame_updated=1;
          }
          static size_t audio_many(const int16_t *samples,size_t frames) {
            size_t bytes;
            int r;
            if(!samples || frames==0 || !audio_ready) return frames;
            if(frames>(size_t)0x1fffffff) { audio_error=-900; return frames; }
            bytes=frames*2u*sizeof(int16_t);
            r=audsrv_wait_audio((int)bytes);
            if(r<0) { audio_error=r; return frames; }
            r=audsrv_play_audio((const char *)samples,(int)bytes);
            if(r<0) audio_error=r;
            return frames;
          }
          static void audio_one(int16_t left,int16_t right) {
            int16_t pair[2]; pair[0]=left; pair[1]=right;
            (void)audio_many(pair,1);
          }
          /* PS2 Cross = PCE I, Square = PCE II; Circle/Triangle are hold-to-fire Turbo I/II. */
          static uint16_t retro_joypad_mask(void) {
            unsigned int mask=0;
            if((buttons_now&PAD_SQUARE) || turbo_ii_active)
              mask |= (1u<<RETRO_DEVICE_ID_JOYPAD_B);
            if((buttons_now&PAD_CROSS) || turbo_i_active)
              mask |= (1u<<RETRO_DEVICE_ID_JOYPAD_A);
            /* Circle/Triangle are Turbo I/II; PCE buttons III/IV are not mapped. */
            if(buttons_now&PAD_SELECT)   mask |= (1u<<RETRO_DEVICE_ID_JOYPAD_SELECT);
            if(buttons_now&PAD_START)    mask |= (1u<<RETRO_DEVICE_ID_JOYPAD_START);
            if(buttons_now&PAD_UP)       mask |= (1u<<RETRO_DEVICE_ID_JOYPAD_UP);
            if(buttons_now&PAD_DOWN)     mask |= (1u<<RETRO_DEVICE_ID_JOYPAD_DOWN);
            if(buttons_now&PAD_LEFT)     mask |= (1u<<RETRO_DEVICE_ID_JOYPAD_LEFT);
            if(buttons_now&PAD_RIGHT)    mask |= (1u<<RETRO_DEVICE_ID_JOYPAD_RIGHT);
            if(buttons_now&PAD_L1)       mask |= (1u<<RETRO_DEVICE_ID_JOYPAD_L);
            if(buttons_now&PAD_R1)       mask |= (1u<<RETRO_DEVICE_ID_JOYPAD_R);
            if(buttons_now&PAD_L2)       mask |= (1u<<RETRO_DEVICE_ID_JOYPAD_L2);
            if(buttons_now&PAD_R2)       mask |= (1u<<RETRO_DEVICE_ID_JOYPAD_R2);
            if(buttons_now&PAD_L3)       mask |= (1u<<RETRO_DEVICE_ID_JOYPAD_L3);
            if(buttons_now&PAD_R3)       mask |= (1u<<RETRO_DEVICE_ID_JOYPAD_R3);
            return (uint16_t)mask;
          }
          /* Update Turbo once per emulated frame. The PS2 frontend calls this
             explicitly before retro_run(), because the tested core did not call
             the registered input_poll callback (diagnostic POLL stayed at zero).
             The guard prevents double-advancing if the core does call it later. */
          static void input_poll(void) {
          #if PCE_SHOW_DIAGNOSTICS
            input_poll_count++;
          #endif
            if(turbo_updated_this_frame)
              return;
            turbo_updated_this_frame = 1;

            if(buttons_now & PAD_CIRCLE) {
              turbo_i_active = ((turbo_i_counter % PCE_TURBO_PERIOD_FRAMES) < PCE_TURBO_ON_FRAMES);
              turbo_i_counter++;
            } else {
              turbo_i_counter = 0;
              turbo_i_active = 0;
            }
            if(buttons_now & PAD_TRIANGLE) {
              turbo_ii_active = ((turbo_ii_counter % PCE_TURBO_PERIOD_FRAMES) < PCE_TURBO_ON_FRAMES);
              turbo_ii_counter++;
            } else {
              turbo_ii_counter = 0;
              turbo_ii_active = 0;
            }
          }
          static int16_t input_state(unsigned port,unsigned device,unsigned index,unsigned id) {
            int16_t result=0;
            (void)index;
          #if PCE_SHOW_DIAGNOSTICS
            input_state_count++;
            input_last_port=(int)port;
            input_last_device=(int)device;
            input_last_id=(int)id;
            input_last_value=0;
          #endif
            /* Beetle PCE Fast may query the multitap's fifth port; this frontend exposes the one physical pad on ports 0-4. */
            if(port>4 || (device & RETRO_DEVICE_MASK)!=RETRO_DEVICE_JOYPAD)
              return 0;
            if(id==RETRO_DEVICE_ID_JOYPAD_MASK) {
              result=(int16_t)retro_joypad_mask();
          #if PCE_SHOW_DIAGNOSTICS
              input_mask_query_count++;
              input_last_value=(int)(uint16_t)result;
              input_active_mask |= (unsigned int)(uint16_t)result;
              input_a_value = !!((uint16_t)result & (1u << RETRO_DEVICE_ID_JOYPAD_A));
              input_b_value = !!((uint16_t)result & (1u << RETRO_DEVICE_ID_JOYPAD_B));
              input_a_queries++;
              input_b_queries++;
          #endif
              return result;
            }
          #if PCE_SHOW_DIAGNOSTICS
            if(id<16) input_query_mask |= (1u<<id);
          #endif
            switch(id) {
              case RETRO_DEVICE_ID_JOYPAD_UP: result=!!(buttons_now&PAD_UP); break;
              case RETRO_DEVICE_ID_JOYPAD_DOWN: result=!!(buttons_now&PAD_DOWN); break;
              case RETRO_DEVICE_ID_JOYPAD_LEFT: result=!!(buttons_now&PAD_LEFT); break;
              case RETRO_DEVICE_ID_JOYPAD_RIGHT: result=!!(buttons_now&PAD_RIGHT); break;
              case RETRO_DEVICE_ID_JOYPAD_B: result=!!((buttons_now&PAD_SQUARE) || turbo_ii_active); break;
              case RETRO_DEVICE_ID_JOYPAD_A: result=!!((buttons_now&PAD_CROSS) || turbo_i_active); break;
              case RETRO_DEVICE_ID_JOYPAD_START: result=!!(buttons_now&PAD_START); break;
              case RETRO_DEVICE_ID_JOYPAD_SELECT: result=!!(buttons_now&PAD_SELECT); break;
              case RETRO_DEVICE_ID_JOYPAD_X: result=0; break; /* PCE button III is not mapped. */
              case RETRO_DEVICE_ID_JOYPAD_Y: result=0; break; /* PCE button IV is not mapped. */
              case RETRO_DEVICE_ID_JOYPAD_L: result=!!(buttons_now&PAD_L1); break;
              case RETRO_DEVICE_ID_JOYPAD_R: result=!!(buttons_now&PAD_R1); break;
              case RETRO_DEVICE_ID_JOYPAD_L2: result=!!(buttons_now&PAD_L2); break;
              case RETRO_DEVICE_ID_JOYPAD_R2: result=!!(buttons_now&PAD_R2); break;
              case RETRO_DEVICE_ID_JOYPAD_L3: result=!!(buttons_now&PAD_L3); break;
              case RETRO_DEVICE_ID_JOYPAD_R3: result=!!(buttons_now&PAD_R3); break;
              default: result=0; break;
            }
          #if PCE_SHOW_DIAGNOSTICS
            input_last_value=result;
            if(result && id<16) input_active_mask |= (1u<<id);
            if(id==RETRO_DEVICE_ID_JOYPAD_A) { input_a_value=result; input_a_queries++; }
            if(id==RETRO_DEVICE_ID_JOYPAD_B) { input_b_value=result; input_b_queries++; }
          #endif
            return result;
          }
          static void render_load_debug(void) {
  uint64_t white=GS_SETREG_RGBAQ(230,240,245,0x80,0);
  uint64_t aqua=GS_SETREG_RGBAQ(50,210,175,0x80,0);
  char line[160];
  title_screen("PCE ZIP LOAD DIAGNOSTIC");
  snprintf(line,sizeof(line),"LOAD STATUS: %d",status_code); label(24,112,2,line,aqua);
  snprintf(line,sizeof(line),"ARCHIVE: %.62s",game_path); label(24,151,1,line,white);
  snprintf(line,sizeof(line),"ROM BYTES: %lu NEED FULLPATH: %d",last_rom_size,last_need_fullpath); label(24,181,1,line,aqua);
  snprintf(line,sizeof(line),"ROM SIG: %02X %02X %02X %02X %02X %02X %02X %02X",
    last_rom_head[0],last_rom_head[1],last_rom_head[2],last_rom_head[3],
    last_rom_head[4],last_rom_head[5],last_rom_head[6],last_rom_head[7]); label(24,211,1,line,white);
  snprintf(line,sizeof(line),"CORE EXT: %.78s",last_valid_extensions); label(24,241,1,line,white);
  snprintf(line,sizeof(line),"ZIP MEMBER: %.70s",last_rom_name); label(24,271,1,line,white);
  snprintf(line,sizeof(line),"TEMP ROM: %.70s",last_temp_path[0]?last_temp_path:"(not created)"); label(24,301,1,line,white);
  snprintf(line,sizeof(line),"CORE LOG: %.76s",core_last_log); label(24,341,1,line,aqua);
  label(24,420,1,"CIRCLE: BACK TO USB BROWSER",aqua);
}
static int begin_game(const char *path) {
  struct retro_game_info game;
  struct retro_system_info info;
  struct retro_system_av_info av;
  int r;
  last_rom_size=0;
  memset(last_rom_head,0,sizeof(last_rom_head));
  last_rom_name[0]='\0';
  last_temp_path[0]='\0';
  last_valid_extensions[0]='\0';
  last_need_fullpath=-1;
  strncpy(core_last_log,"NO CORE LOG RECEIVED",sizeof(core_last_log)-1);
  core_last_log[sizeof(core_last_log)-1]='\0';
  unload_game();
  r=read_full_game(path);
  if(r<0)return r;
  if(!core_initialized) {
    retro_set_environment(core_environment);
    retro_set_video_refresh(video_cb);
    retro_set_audio_sample(audio_one);
    retro_set_audio_sample_batch(audio_many);
    retro_set_input_poll(input_poll);
    retro_set_input_state(input_state);
    retro_init();core_initialized=1;
  }
  /* Expose the connected physical pad to the PCE core's five possible multitap ports. */
  { unsigned int port; for(port=0;port<5;port++) retro_set_controller_port_device(port,RETRO_DEVICE_JOYPAD); }
  memset(&info,0,sizeof(info));
  retro_get_system_info(&info);
  last_need_fullpath=info.need_fullpath?1:0;
  if(info.valid_extensions) {
    strncpy(last_valid_extensions,info.valid_extensions,sizeof(last_valid_extensions)-1);
    last_valid_extensions[sizeof(last_valid_extensions)-1]='\0';
  }
  last_rom_size=(unsigned long)game_size;
  if(game_data && game_size) {
    memcpy(last_rom_head,game_data,(game_size<sizeof(last_rom_head)?game_size:sizeof(last_rom_head)));
  }
  if(game_core_path[0]) {
    strncpy(last_rom_name,game_core_path,sizeof(last_rom_name)-1);
    last_rom_name[sizeof(last_rom_name)-1]='\0';
  }
  retro_get_system_av_info(&av);
  if(av.timing.sample_rate>0.0)
    (void)audio_init((unsigned)(av.timing.sample_rate+0.5));
  else
    (void)audio_init(44100);
  memset(&game,0,sizeof(game));
  if(is_zip(path) && info.need_fullpath) {
    r=write_zip_temp_rom(path,game_data,game_size);
    if(r<0) { unload_game(); return r; }
    strncpy(last_temp_path,zip_temp_path,sizeof(last_temp_path)-1);
    last_temp_path[sizeof(last_temp_path)-1]='\0';
    game.path=zip_temp_path;
    game.data=NULL;
    game.size=0;
  } else {
    game.path=game_core_path[0]?game_core_path:path;
    game.data=info.need_fullpath?NULL:game_data;
    game.size=info.need_fullpath?0:game_size;
  }
  strncpy(core_last_log,"NO CORE LOAD LOG",sizeof(core_last_log)-1);
  core_last_log[sizeof(core_last_log)-1]='\0';
  if(!retro_load_game(&game)) {unload_game();return -104;}
  core_loaded=1;
  load_game_cheats();
  return 0;
}
static void draw_game(void) {
          #if PCE_SHOW_DIAGNOSTICS
            char diag[64];
            uint64_t aqua=GS_SETREG_RGBAQ(50,210,175,0x80,0);
          #endif
            if(video_received) {
              gsKit_clear(gs,GS_SETREG_RGBAQ(0,0,0,0x80,0));
              tex.Mem=(u32 *)pixels16;
              if(video_frame_updated) {
                gsKit_texture_upload(gs,&tex);
                video_frame_updated=0;
              }
              gsKit_prim_sprite_texture(gs,&tex,
                0.0f,0.0f,0.0f,0.0f,640.0f,448.0f,
                (float)frame_w,(float)frame_h,1,
                GS_SETREG_RGBAQ(0x80,0x80,0x80,0x80,0));
          #if PCE_SHOW_DIAGNOSTICS
              if(audio_ready) label(6,6,1,"AUDIO OK",aqua);
              else { snprintf(diag,sizeof(diag),"AUDIO ERR %d",audio_error); label(6,6,1,diag,aqua); }
              label(6,16,1,pad_read_ok?"PAD READ OK":"PAD NO DATA",aqua);
              snprintf(diag,sizeof(diag),"STATE %d LEN %d",pad_state_value,pad_read_len);
              label(6,26,1,diag,aqua);
              snprintf(diag,sizeof(diag),"RAW %04X",pad_raw_buttons & 0xffffu);
              label(6,36,1,diag,aqua);
              snprintf(diag,sizeof(diag),"KEY %04X",buttons_now & 0xffffu);
              label(6,46,1,diag,aqua);
              snprintf(diag,sizeof(diag),"QRY %04X M%u",input_query_mask & 0xffffu,input_mask_query_count);
              label(6,56,1,diag,aqua);
              snprintf(diag,sizeof(diag),"ACT %04X",input_active_mask & 0xffffu);
              label(6,66,1,diag,aqua);
              snprintf(diag,sizeof(diag),"P%d D%d I%d V%d",input_last_port,input_last_device,input_last_id,input_last_value);
              label(6,76,1,diag,aqua);
              snprintf(diag,sizeof(diag),"POLL %u CALL %u",input_poll_count,input_state_count);
              label(6,86,1,diag,aqua);
              snprintf(diag,sizeof(diag),"PF %d GS-5551",pixel_format);
              label(6,96,1,diag,aqua);
              snprintf(diag,sizeof(diag),"CIR %u TRI %u",!!(buttons_now&PAD_CIRCLE),!!(buttons_now&PAD_TRIANGLE));
              label(6,106,1,diag,aqua);
              snprintf(diag,sizeof(diag),"T1 %u T2 %u",!!turbo_i_active,!!turbo_ii_active);
              label(6,116,1,diag,aqua);
              snprintf(diag,sizeof(diag),"A %u Q%u B %u Q%u",!!input_a_value,input_a_queries,!!input_b_value,input_b_queries);
              label(6,126,1,diag,aqua);
              snprintf(diag,sizeof(diag),"PHASE %u %u",turbo_i_counter%PCE_TURBO_PERIOD_FRAMES,turbo_ii_counter%PCE_TURBO_PERIOD_FRAMES);
              label(6,136,1,diag,aqua);
              label(6,146,1,is_zip(game_path)?"ZIP ROM LOADED":"PCE ROM LOADED",aqua);
          #endif
            } else title_screen("WAITING FOR VIDEO");
          }
          int main(int argc,char **argv) {
            (void)argc;(void)argv;
            gs=gsKit_init_global();
            if(!gs)return 1;
            gs->PSM=GS_PSM_CT16;
            gs->PSMZ=GS_PSMZ_16;
            gs->ZBuffering=GS_SETTING_OFF;
            dmaKit_init(D_CTRL_RELE_OFF,D_CTRL_MFD_OFF,D_CTRL_STS_UNSPEC,
                        D_CTRL_STD_OFF,D_CTRL_RCYC_8,1<<DMA_CHANNEL_GIF);
            dmaKit_chan_init(DMA_CHANNEL_GIF);
            gsKit_init_screen(gs);
            gsKit_mode_switch(gs,GS_ONESHOT);
            memset(&tex,0,sizeof(tex));
            tex.Width=TEX_SIZE;tex.Height=TEX_SIZE;tex.PSM=GS_PSM_CT16;tex.Mem=(u32 *)pixels16;
            tex.Vram=gsKit_vram_alloc(gs,gsKit_texture_size(TEX_SIZE,TEX_SIZE,GS_PSM_CT16),GSKIT_ALLOC_USERBUFFER);
            memset(&cover_tex,0,sizeof(cover_tex));
            cover_tex.Width=COVER_TEX_SIZE;
            cover_tex.Height=COVER_TEX_SIZE;
            cover_tex.PSM=GS_PSM_CT16;
            cover_tex.Mem=(u32 *)cover_pixels;
            cover_tex.Vram=gsKit_vram_alloc(gs,gsKit_texture_size(COVER_TEX_SIZE,COVER_TEX_SIZE,GS_PSM_CT16),GSKIT_ALLOC_USERBUFFER);
            cover_tex_ready=(cover_tex.Vram!=0);
            memset(&background_tex,0,sizeof(background_tex));
            background_tex.Width=BACKGROUND_TEX_W;
            background_tex.Height=BACKGROUND_TEX_H;
            background_tex.PSM=GS_PSM_CT16;
            background_tex.Mem=(u32 *)background_pixels;
            background_tex.Vram=gsKit_vram_alloc(gs,gsKit_texture_size(BACKGROUND_TEX_W,BACKGROUND_TEX_H,GS_PSM_CT16),GSKIT_ALLOC_USERBUFFER);
            background_tex_ready=(background_tex.Vram!=0);
            SifInitRpc(0);
            /* Keep the PS2 ROM module pair used by the current frontend. */
            SifLoadModule("rom0:XSIO2MAN",0,NULL);
            SifLoadModule("rom0:XPADMAN",0,NULL);
            pad_init_result=padInit(0);
            pad_open_result=0;
            if(pad_init_result==1)
              pad_open_result=padPortOpen(0,0,pad_buf);
            pad_ready=(pad_open_result!=0);
            screen=0;
            for(;;) {
              char tmp[80];
              pad_scan();
              if(screen==0) {
                title_screen("BEETLE CORE - PC ENGINE ONLY");
                label(52,210,3,"X OPEN USB ROMS",GS_SETREG_RGBAQ(230,240,245,0x80,0));
                if(status_code<0) {
                  snprintf(tmp,sizeof(tmp),"ERROR %d",status_code);
                  label(52,299,2,tmp,GS_SETREG_RGBAQ(230,240,245,0x80,0));
                }
                if(buttons_edge&PAD_CROSS) {
                  status_code=usb_init();
                  if(status_code>=0) {
                    usb_progress("SCAN MASS ROOT");
                    strcpy(folder,"mass:/");status_code=scan_dir();
                    if(status_code<0) {
                      usb_progress("SCAN MASS0 ROOT");
                      strcpy(folder,"mass0:/");status_code=scan_dir();
                    }
                    if(status_code>=0)screen=1;
                  }
                }
                refresh_screen();
              } else if(screen==1) {
                if(nentries>0) {
                  if(nav_repeat(PAD_UP)) selected=(selected+nentries-1)%nentries;
                  if(nav_repeat(PAD_DOWN)) selected=(selected+1)%nentries;
                  if(buttons_edge&PAD_LEFT) {
                    selected=(selected>=10)?(selected-10):0;
                  }
                  if(buttons_edge&PAD_RIGHT) {
                    selected=(selected+10<nentries)?(selected+10):(nentries-1);
                  }
                }
                if(buttons_edge&PAD_CIRCLE)enter_parent();
                if((buttons_edge&PAD_CROSS) && nentries>0) {
                  char next[MAX_PATH];
                  int written=snprintf(next,sizeof(next),"%s%s%s",folder,
                    entries[selected].name,entries[selected].dir?"/":"");
                  if(written<0 || written>=(int)sizeof(next)) status_code=-105;
                  else if(entries[selected].dir) {
                    strcpy(folder,next);status_code=scan_dir();
                  } else {
                    strcpy(game_path,next);
                    status_code=begin_game(game_path);
                    if(status_code>=0)screen=2;
                    else screen=5;
                  }
                }
                render_browser();refresh_screen();
              } else if(screen==5) {
                if(buttons_edge&PAD_CIRCLE) {
                  screen=1; buttons_prev=buttons_now; buttons_edge=0;
                }
                render_load_debug(); refresh_screen();
              } else if(screen==3) {
                if(buttons_edge&PAD_UP) state_menu_selected=(state_menu_selected+12)%13;
                if(buttons_edge&PAD_DOWN) state_menu_selected=(state_menu_selected+1)%13;
                if(buttons_edge&PAD_CIRCLE) {
                  screen=2; buttons_prev=buttons_now; buttons_edge=0;
                } else if(buttons_edge&PAD_CROSS) {
                  state_menu_activate();
                }
                render_state_menu(); refresh_screen();
                if(state_message_frames>0) state_message_frames--;
              } else if(screen==4) {
                if(buttons_edge&PAD_UP) cheat_menu_selected=(cheat_menu_selected+PCE_CHEAT_MENU_ITEMS-1)%PCE_CHEAT_MENU_ITEMS;
                if(buttons_edge&PAD_DOWN) cheat_menu_selected=(cheat_menu_selected+1)%PCE_CHEAT_MENU_ITEMS;
                if(buttons_edge&PAD_CIRCLE) {
                  screen=3; buttons_prev=buttons_now; buttons_edge=0;
                } else if(buttons_edge&PAD_CROSS) {
                  cheat_menu_activate();
                }
                render_cheat_menu(); refresh_screen();
                if(state_message_frames>0) state_message_frames--;
              } else {
                if((buttons_now&(PAD_L1|PAD_R1|PAD_START))==(PAD_L1|PAD_R1|PAD_START)) {
                  unload_game();screen=1;
                  buttons_prev=buttons_now;
                  continue;
                }
                /* L1 + R1 + SELECT opens Save/Load State; Turbo Circle/Triangle stay untouched. */
                if((buttons_now&(PAD_L1|PAD_R1|PAD_SELECT))==(PAD_L1|PAD_R1|PAD_SELECT)) {
                  screen=3; state_menu_selected=0;
                  state_set_message("SELECT SAVE OR LOAD SLOT");
                  buttons_prev=buttons_now; buttons_edge=0;
                  continue;
                }
                /* Debug-only counters are omitted from the performance build. */
          #if PCE_SHOW_DIAGNOSTICS
                input_active_mask=0;
                input_query_mask=0;
                input_mask_query_count=0;
                input_poll_count=0;
                input_state_count=0;
                input_last_port=-1;
                input_last_device=-1;
                input_last_id=-1;
                input_last_value=0;
                input_a_queries=0;
                input_b_queries=0;
                input_a_value=0;
                input_b_value=0;
          #endif
                /* Reset the frame guard and poll input explicitly before running
                   the core. This fixes POLL=0 while input_state is queried. */
                turbo_updated_this_frame=0;
                video_frame_updated=0;
                input_poll();
                retro_run();
                if(any_cheats_enabled()) (void)apply_enabled_cheats(0);
                draw_game();
                if(state_message_frames>0 && state_message[0]) {
                  label(12,430,1,state_message,GS_SETREG_RGBAQ(50,210,175,0x80,0));
                  state_message_frames--;
                }
                refresh_screen();
              }
            }
            return 0;
          }


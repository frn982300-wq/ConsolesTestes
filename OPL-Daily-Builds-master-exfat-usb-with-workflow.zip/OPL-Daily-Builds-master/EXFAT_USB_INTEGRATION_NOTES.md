# Experimental USB exFAT integration (BDM Assault)

This patch integrates the two BDM Assault IRX binaries supplied for this workspace into the
provided `OPL-Daily-Builds-master.zip` source tree.

## Changes
- `modules/bdm_assault/bdm_assault.irx` is the supplied `usbd.irx` file. Its internal IRX
  module name is `bdm`, and its strings include `EXFAT`, `FAT32`, and FATFS/BDM messages.
- `modules/bdm_assault/usbd_bd_assault.irx` is the supplied `usbhdfsd.irx` file. Its internal
  IRX module name is `usbd`, and its strings include the USB mass-storage driver.
- The Makefile embeds these two IRXs instead of the stock PS2SDK BDM/VFAT/USBD/USBMASS
  modules.
- `src/bdmsupport.c` loads the bundled BDM/filesystem module and the bundled USB module.
- `src/system.c` and `ee_core/src/iopmgr.c` avoid registering/loading a separate stock
  USBMASSBD module after IOP reset.

## Important limitations
- This is an **experimental source integration**, not a compiled or hardware-tested OPL ELF.
- The supplied archive is named `OPL-Daily-Builds-master.zip`; its Git history is absent, so
  this workspace cannot verify that it is exactly Daily Build 1696.
- A working PS2SDK/GSKIT toolchain is required to build OPL. Build and test on hardware before
  relying on it.
- First test with a backed-up FAT32 device, then a small exFAT MBR USB drive, then a single
  ISO larger than 4 GB. Verify game listing, launch, and USB behavior after the IOP reset.
- These are precompiled IRX binaries; this patch does not include their source code.

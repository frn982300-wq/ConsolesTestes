int oplIGRShutdown(int poff);
